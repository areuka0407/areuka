<?php

    session_start();

    use App\Core\Router;

    define("__DS", DIRECTORY_SEPARATOR );
    define("__ROOT", dirname(__DIR__));
    define("__SRC", __ROOT.__DS."src");

    require __ROOT.__DS."loader.php";
    require __ROOT.__DS."page_list.php";

    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    Router::init();