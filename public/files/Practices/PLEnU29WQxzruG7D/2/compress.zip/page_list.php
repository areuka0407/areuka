<?php

    use App\Core\Router;

    $all = [
        "/" => 'get/MainController@index',
        ':name/board/:mid' => 'get/BoardController@list'
    ];

    $logined = [];

    $notLogined = [];


    Router::register($all);
    if(isset($_SESSION['user']))
        Router::register($logined);
    else
        Router::register($notLogined);

