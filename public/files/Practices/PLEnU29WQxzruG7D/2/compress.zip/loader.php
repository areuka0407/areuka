<?php
    function loader($class){
        $prefix = "App";
        $sourceDir = "src";

        if(strncmp($prefix, $class, strlen($prefix)) !== 0){
            return;
        }

        $realName = substr($class, strlen($prefix));

        $file = __ROOT . __DS . $sourceDir . str_replace("\\", __DS, $realName). ".php";

        if(file_exists($file)){
            require $file;
        }
    }


    spl_autoload_register("loader");