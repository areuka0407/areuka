<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2019-01-12
 * Time: 오전 9:46
 */

namespace App\Core;


class Action
{
    private $url = null;
    private $controller = null;
    private $method = null;

    private $match = [];

    public function __construct($url, $controller, $method){
        $this->url = $url;
        $this->controller = $controller;
        $this->method = $method;
    }

    public function check($path){
        $reg = preg_replace("/:([^\/]+)/", "(?<$1>[^/]+)", $this->url);

        $reg = preg_replace("/\//", "\\/", $reg);

        return preg_match("/^" . $reg . "$/", $path, $this->match);
    }

    public function execute(){
        $conName = "App\\Controller\\". $this->controller;
        $con = new $conName();

        $reflection = new \ReflectionMethod($con, $this->method);
        $params = $reflection->getParameters();

        $args = [];
        foreach($params as $param){
            $name = $param->getName();
            if(!isset($this->match[$name])){
                $this->match[$name] = null;
            }

            $args[$name] = $this->match[$name];
        }

        call_user_func_array([$con, $this->method], $args);
        //Controller에 해당 Method를 Args로 실행시킴.
    }
}