<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2019-01-12
 * Time: 오전 9:44
 */

namespace App\Core;


class Router
{
    public static $GET = [];
    public static $POST = [];

    public static function init(){
        $path = isset($_GET['url']) ? $_GET['url'] : "/";

        foreach(self::${$_SERVER['REQUEST_METHOD']} as $page){
            if($page->check($path)){
                $page->execute();
                return;
            }
        }
    }

    public static function register($actions){
        foreach($actions as $url => $action){

            $urlAction = explode("/", $action);
            $classMethod = explode("@", $urlAction[1]);


            if(strtolower($urlAction[0]) === "post"){
                self::$POST[] = new Action($url, $classMethod[0], $classMethod[1]);
            } else if(strtolower($urlAction[0]) === "get"){
                self::$GET[] = new Action($url, $classMethod[0], $classMethod[1]);
            } else {
                return;
            }
        }
    }
}