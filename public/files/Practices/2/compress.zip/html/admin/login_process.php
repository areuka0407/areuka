<?php

    include "lib.php";

  $userid = $_POST['userid'];

  $password = $_POST['password'];

  

$query = "select * from managers where id = ?";

$q = $con->prepare($query);

$q->execute(array($userid));





//로그인 처리

if($q->rowCount() > 0){

    $row = $q->fetch();

    $hash = $row->password;

    if (hash("sha256", $password) !== $hash) {
    	back("비밀번호가 일치하지 않습니다.");
    	exit;
	}


    // 로그인 성공

    $_SESSION['user'] = $row;



    $sql = "SHOW FULL COLUMNS FROM managers";

    $q = $con->prepare($sql);

    $q->execute(array('remember_code'));



    $cols = $q->fetchAll(\PDO::FETCH_ASSOC);



    $find = false;

    foreach ($cols as $col){

        if ($col['Field'] === "remember_code") $find = true;

    }



    // remember_code 컬럼이 없으면...

    if ($find === false){

        $sql = "ALTER TABLE managers ADD COLUMN remember_code CHAR(255) NULL DEFAULT NULL";

        $con->query($sql);

    }





    // 관리자를 구분할 수 있는 고유의 구분 코드 생성

    do {

        $code = randString(30);

        $q = $con->prepare("SELECT * FROM managers WHERE remember_code = ?");

        $q->execute(array($code));

    } while ($q->rowCount() !== 0);





    // DB에 저장

    $q = $con->prepare("UPDATE managers SET remember_code = ? WHERE idmanagers = ?");

    $q->execute(array($code, user()->idmanagers));

    user()->remember_code = $code;



    redirect("/admin/page_select.php", "로그인 되었습니다.");

}else back("해당 유저가 존재하지 않습니다.")//로그인 실패



?>
