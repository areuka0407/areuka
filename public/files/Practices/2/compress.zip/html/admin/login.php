
<?php
require "lib.php";

if (user()) redirect("/admin/page_select.php", "이미 로그인 중입니다.");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
<title>매니저 로그인</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>   
<body>
<div class="container">
    <h1 class="text-center" style="margin-top:60px;">관리자 로그인페이지</h1>
    <div class="row">
        <div class="col-lg-12 col-md-12 text-center">
            <form name="loginForm" id="loginForm" class="text-center" action="login_process.php" method="post">
                <label>아이디</label>
                <div class="form-group">
                    <input type="text" name="userid" id="userid" class="form-control" value="" placeholder="아이디"/>
                </div>
                <div class="form-group">
                    <label>비밀번호</label>
                    <input type="password" name="password" id="password" class=" form-control" placeholder="비밀번호"/>
                </div>                                
                <button type="submit" class="btn btn-danger bt_txt bt_login"> 로그인</button>
            </form>   
        </div>
    </div>
</div> 
<script>
$(document).ready(function(){
    $('.bt_login').on('click', function(){
        if($('#userid').val()==""){
            alert('아이디를 입력해주세요.');
            $('#userid').focus();
            return false;
        }else if($('#password').val()==""){
            alert('비밀번호를 입력해주세요.');
            $('#password').focus();
            return false;
        }else{
            $('#loginForm').submit();
        }
    });
});
</script>
</body>
</html>
  