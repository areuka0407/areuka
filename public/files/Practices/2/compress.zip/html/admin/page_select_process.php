<?php
    include "lib.php";
    $select_page = $_POST['select_page'];

    if(user() != TRUE) redirect("/admin/login.php", "로그인 후 이용할 수 있습니다.");

    if(empty($select_page)) redirect("/admin/page_select.php", "페이지를 선택해 주세요.");

    $_SESSION['select_page'] = $select_page;

    redirect("/admin/page_edit.php");

?> 