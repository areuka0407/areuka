<?php

require "lib.php";

if(!user()) redirect("/admin/login", "로그인 후 이용할 수 있습니다.");



header('P3P: CP="NOI CURa ADMa DEVa TAIa OUR DELa BUS IND PHY ONL UNI COM NAV INT DEM PRE"');

header('P3P: CP="ALL CURa ADMa DEVa TAIa OUR BUS IND PHY ONL UNI PUR FIN COM NAV INT DEM CNT STA POL HEA PRE LOC OTC"');

header('P3P: CP="ALL ADM DEV PSAi COM OUR OTRo STP IND ONL"');

header('P3P: CP="CAO PSA OUR"');



?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>관리자 페이지</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script type="text/javascript">

</script>

<style type="text/css">

 

</style>

</head>

<body>

<iframe id="page-edit-area" src="/admin/connect?code=<?=user()->remember_code?>&page=<?=$_SESSION['select_page']?>" style="display:block; width:100vw; height: calc(100vw - 50px);"></iframe>

<button id="close-btn" style="position: fixed; right: 10px; bottom: 10px;" class="btn btn-primary">

    페이지 재선택

</button>

<script type="text/javascript">

    $("#close-btn").click(function(e){

        e.preventDefault();

        location.replace("/admin/page_select.php");

    });

</script>

</body> 

</html> 
