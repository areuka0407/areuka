<?php
    require "lib.php";
    if (!user()) redirect("/admin/login.php", "로그인 후 이용할 수 있습니다.");

    // 코드 삭제
    $q = $con->prepare("UPDATE managers SET remember_code = '' WHERE idmanagers = ?");
    $q->execute(array(user()->idmanagers));

    session_destroy();
    redirect("/admin/login.php", "로그아웃 되었습니다."); 