<?php

// 세션 시작

session_start();



//데이터 베이스 접속 기본정보

define('DB_HOST','localhost');

define('DB_NAME','jhr1843');

define('DB_USER','jhr1843');

define('DB_PWD','kt4656701');

$options = array( \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_OBJ,  \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION );



$con = new \PDO("mysql:host=". DB_HOST .";dbname=". DB_NAME .";charset=utf8mb4", DB_USER, DB_PWD, $options); // 데이터베이스 접속



// 페이지 이동 함수 저장

function redirect($url, $message = ""){
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">";
	echo "<script type='text/javascript'>";
    if ($message !== "") echo "alert('$message');";
    echo "location.replace('$url');";
    echo "</script>";
}



function back($message = ""){
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">";
	echo "<script type='text/javascript'>";
	if ($message !== "") echo "alert('$message');";
    echo "history.back();";
	echo "</script>";
}



function randString($length){

    $string = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";

    $result = "";

    for ($i = 0; $i < $length; $i++){

        $result .= $string[rand(0, strlen($string) - 1)];

    }

    return $result;

}



function user(){

    return isset($_SESSION['user']) ? $_SESSION['user'] : false;

}
