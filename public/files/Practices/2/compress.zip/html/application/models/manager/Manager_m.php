<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manager_m extends CI_Model {
   
    function __construct()
    {
        parent::__construct();
    }
    
    //회원가입
    function join($auth) {
        $insert_array = array(
            'id' => $auth['id'],
            'password' => password_hash($auth['password'], PASSWORD_DEFAULT), 
            'name' => $auth['name'],                            
            'last_idsite' => $auth['last_idsite'],         
        );
        $result = $this->db->insert('managers', $insert_array);
        
        if ($result)
        {
            //회원가입 정보 리턴
            return $this->db->insert_id();
        }
        else
        {
            //회원가입이 제대로 되지 않으면 false리턴
            return FALSE;
        }
        
    }

    //로그인
    function login($auth)
    {
        $this->db->select('password');
        $this->db->from('managers');
        $this->db->where('id', $auth['id']);
        $query = $this->db->get();
  
        if ($query->num_rows() > 0)
        {
            $result = $query->row();
            $hash = $result->password;
            //if (!password_verify($auth['password'], $hash))
            if ($auth['password'] != $hash)
            {
                return FALSE;
            }
            else
            {
                $user = $this->db->where('id', $auth['id'])->get('managers')->row_array();
                if ($user)
                {
                    return $user;
                }
                else
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    function modify($auth)
    {
        $modify_array = array(
            'userid' => $auth['userid'],
            'password' => password_hash($auth['password'], PASSWORD_DEFAULT),
            'email' => $auth['email'],   
            'name' => $auth['name'],                            
            'phone' => $auth['phone'],         
            'regDate' => date("Y-m-d H:i:s")
        );
        if($hospital){
            $modify_array['hospital'] = $auth['hospital'];
        }
        if($course){
            $modify_array['course'] = $auth['course'];
        }
        if($salesofficer){
            $modify_array['salesofficer'] = $auth['salesofficer'];
        }
        if($salesgroup){
            $modify_array['salesgroup'] = $auth['salesgroup'];
        }

        $this->db->where('idusers', $auth['idusers']);
        $result = $this->db->update('band_member', $modify_array);
        
        //회원 수정결과 반환
        if ($result)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        
    }

    //회원가입했는지 확인
    function user_check($_userid){
       $this->db->from('users');
       $this->db->where('id', $_userid);
       $query = $this->db->get();
       $result = $query->row();
       return $result;
       
    }
    function get_user($_idusers)
    {
        if(!empty($_idusers))
        {
            $this->db->from('users');
            $this->db->where('idusers', $_idusers);
            $query = $this->db->get();
            $result = $query->result();
            return $result;
        }
        else
        {
            return FALSE;
        }
    }
}