<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member_m extends CI_Model {
    
    function __construct()
    {
        parent::__construct();
    }
    
    //회원가입
    function join($auth) {
        $insert_array = array(
            'userid' => $auth['userid'],
            'password' => password_hash($auth['password'], PASSWORD_DEFAULT),
            'idsite' => $auth['idsite'],
            'email' => $auth['email'],
            'name' => $auth['name'],
            'firstname' => $auth['firstname'],
            'lastname' => $auth['lastname'],
            'phone' => $auth['phone'],
            'regDate' => date("Y-m-d H:i:s")
        );
        if(!empty($auth['hospital'])){
            $insert_array['hospital'] = $auth['hospital'];
        }
        if(!empty($auth['course'])){
            $insert_array['course'] = $auth['course'];
        }
        if(!empty($auth['salesofficer'])){
            $insert_array['salesofficer'] = $auth['salesofficer'];
        }
        if(!empty($auth['salesgroup'])){
            $insert_array['salesgroup'] = $auth['salesgroup'];
        }
        
        $result = $this->db->insert('users', $insert_array);
        
        if ($result)
        {
            //회원가입 정보 리턴
            return $this->db->insert_id();
        }
        else
        {
            //회원가입이 제대로 되지 않으면 false리턴
            return FALSE;
        }
        
    }
    
    //로그인
    function login($auth)
    {
       // $sql="SELECT password FROM  WHERE  =? AND  = ?";
        $this->db->from('users');
        $this->db->where('userid', $auth['userid']);
        $this->db->where('idsite', $auth['idsite']);
        $query = $this->db->get();

        if ($query->num_rows() > 0)
        {
            $result = $query->row();
            $hash = $result->password;
            
            if (!password_verify($auth['password'], $hash))
            {
                return FALSE;
            }
            else
            {
                $this->db->where('userid', $auth['userid']);
                $this->db->where('idsite', $auth['idsite']);
                $user = $this->db->get('users')->row_array();
                if ($user)
                {
                    return $user;
                }
                else
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    
    function modify($auth)
    {
        $modify_array = array(
            'password' => password_hash($auth['newpassword'], PASSWORD_DEFAULT),
            'email' => $auth['email'],
            'name' => $auth['name'],
            'firstname' => $auth['firstname'],
            'lastname' => $auth['lastname'],
            'phone' => $auth['phone'],
            //'regDate' => date("Y-m-d H:i:s")
        );
        if(!empty($auth['hospital'])){
            $modify_array['hospital'] = $auth['hospital'];
        }
        if(!empty($auth['course'])){
            $modify_array['course'] = $auth['course'];
        }
        if(!empty($auth['salesofficer'])){
            $modify_array['salesofficer'] = $auth['salesofficer'];
        }
        if(!empty($auth['salesgroup'])){
            $modify_array['salesgroup'] = $auth['salesgroup'];
        }
 
        
        $this->db->from('users');
        $this->db->where('idusers', $auth['idusers']);
        $this->db->where('idsite', $auth['idsite']);
        $query = $this->db->get();
        
        if ($query->num_rows() > 0)
        {
            //기존 비밀번호으로 회원비밀번호 확인 
            $result = $query->row();
            $hash = $result->password;
          
            if (!password_verify($auth['oldpassword'], $hash))
            {
               alert('기존 비밀번호를 잘못 입력하셨습니다.' , '/member/modify');
            }
            else 
            { 
                //맞으면 회원정보 수정
                $this->db->where('idusers', $auth['idusers']);
                $result = $this->db->update('users', $modify_array);
                //회원 수정결과 반환
                if ($this->db->affected_rows() > 0)
                {
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
        }
        
    }
    
    function counseling($data) {
        
        $counseling_data = array(
            'name' => $data['name'],
            'email' => $data['email'],
            'tel' => $data['tel'],
            'title' => $data['title'],
            'content' => $data['content'],
            'regDate' => date("Y-m-d H:i:s")
        );
        
        $result = $this->db->insert('counseling', $counseling_data);
        
        if ($result)
        {
            //상담문의
            //return $this->db->insert_id();
            return true;
        }
        else
        {
            //상담문의가 제대로 되지 않으면 false리턴
            return FALSE;
        }
        
    }
    
    //회원가입했는지 확인
    function user_check($_userid, $_idsite){
        //$sql="SELECT * FROM users WHERE idusers =? and idsite =?";
        $query = $this->db->get_where('users', array('userid'=> $_userid,'idsite' => $_idsite)); 
        $result = $query->row();
        return $result;
        
    }
    
    function get_user($_idusers)
    {
        if(!empty($_idusers))
        {
            $this->db->from('users');
            $this->db->where('idusers', $_idusers);
            $query = $this->db->get();
            $result = $query->row();
            return $result;
        }
        else
        {
            return FALSE;
        }
    }
}