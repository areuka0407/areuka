<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_m extends CI_Model {

    var $table = 'sites';
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

     //매니저 가져오기
     function get_manages(){
        $this->db->get('manages'); 
        $query = $this->db->where('idmangers', $idmangers);      
        $result = $query->row();
        return $result;
    } 

      //매니저 가져오기
      function get_companies(){
        $this->db->get('companies');    
        $result = $query->row();   
        return $result;
    } 

     //사이트 가져오기
     function get_site_config($_url){
        if($_url!=""){
            $this->db->where('relativePath', $_url);
        }
        $query = $this->db->get('sites');       
        $result = $query->result();   
        if($query->num_rows() > 0){
            $result =  $query->row();
        }
        return $result; 
    } 

    //사이트 가져오기
    function get_site($_url){
        if($_url!=""){
            $this->db->where('domain', $_url);
        }
        $query = $this->db->get('sites');
        //$result = $query->result();
        if($query->num_rows() > 0){
           $result =  $query->row();
        }
        return $result; 
    }

    function get_idsite($_path){
        if($_path!=""){
            $this->db->where('relativePath', $_path);
        }
        $query = $this->db->get('sites');
        //$result = $query->result();
        if($query->num_rows() > 0){
           $result =  $query->row();
        } else $result = null;
        return $result; 
    } 

    //메뉴 가져오기
    function get_pages($_idsite){
        $query = $this->db->get_where('pages', array('idsite' => $_idsite)); 
        $result = $query->result(); 
        return $result;
    } 

    //테마 정보 가져오기
    function get_theme($_idsite){
        $query = $this->db->get_where('sites', array('idsite' => $_idsite));
        $result = $query->row();  
        return $result;
    } 
}