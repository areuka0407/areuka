<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Replay_m extends CI_Model {

    var $table = 'vods';
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function get_list($table, $type='', $offset='', $limit='', $search_word='',$site='')
    {
        
        if ( $search_word != '' )
        {
            //검색어가 있을 경우의 처리
            $this->db->like('title', $search_word);
            $this->db->or_like('description', $search_word);
        }
        
        if ($limit != '' OR $offset != '')
        {
            
            //페이징이 있을 경우의 처리
            if($offset <= 1){
                $offset = 0;
            }else if($offset == 2){
                $offset =  5;
            }else{
                $offset = ($offset-1)*$limit;
            }
        }
        $this->db->from('vods');
        $this->db->where('idsite', $site);
        $this->db->order_by('idvods', 'DESC');
        //$this->db->limit($offset, $limit);
        $query = $this->db->get();
       
        if ($type == 'count')
        {
            //리스트를 반환하는 것이 아니라 전체 게시물의 갯수를 반환
            $result = $query->num_rows();
            //$this->db->count_all($table);
        }
        else
        {
            //게시물 리스트 반환
            $result = $query->result();
        }
        
        return $result;
    }
    
    function get_detail($_id)
    {
        $this->db->from('vods');
        $this->db->where('idvods', $_id);        
        $query = $this->db->get();
        $result = $query->row();
    	return $result;
    }

    function replayLatestPosts($_site){
        $this->load->model("front/replay_m");
        $this->db->from('vods');
        $this->db->where('idsite', $_site);
        $this->db->limit(10);
        $query = $this->db->get();        
        $result = $query->result();
        return $result;
    }
}