<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reviewing_m extends CI_Model {

    var $table = 'Board';
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function get_list($table, $type='', $offset='', $limit='', $search_word='')
    {
        $sword= ' WHERE 1=1 ';
        
        if ( $search_word != '' )
        {
            //검색어가 있을 경우의 처리
            $sword = ' WHERE po.subject like "%'.$search_word.'%" or po.contents like "%'.$search_word.'%" ';
        }
        
        $limit_query = '';
       
        if ($limit != '' OR $offset != '')
        {
            //페이징이 있을 경우의 처리
            $limit_query = ' LIMIT '.$offset.', '.$limit;
        }
        
       // $sql = "SELECT * FROM ".$table." ".$sword." AND board_pid = '0' ORDER BY board_id DESC".$limit_query;
        $sql = "SELECT * FROM Boards AS bo
                INNER JOIN  `articles` AS ar
                ON bo.idboard = ar.idboard 
                ".$sword." 
                ORDER BY bo.idboard DESC".$limit_query;
        $query = $this->db->query($sql);
        
        if ($type == 'count')
        {
            //리스트를 반환하는 것이 아니라 전체 게시물의 갯수를 반환
            $result = $query->num_rows();
            //$this->db->count_all($table);
        } 
        else
        {
            //게시물 리스트 반환
            $result = $query->result();
        }
        
        return $result;
    }
    

    /**
	 * 게시물 상세보기 가져오기
	 *
	 * @author HaeRyong Jeong <jhr1843@naver.com>
	 * @param string $table 게시판 테이블
	 * @param string $id 게시물번호
	 * @return array
	 */
    function get_view($table, $id)
    {
    	//조회수 증가
    	$sql0 = "UPDATE ".$table." SET hits=hits+1 WHERE board_id='".$id."'";
   		$this->db->query($sql0);
    	$sql = "SELECT * FROM ".$table." WHERE board_id='".$id."'";
    	//echo $sql;
    	//exit;
   		$query = $this->db->query($sql);

     	//게시물 내용 반환
	    $result = $query->row();

    	return $result;
    }
}