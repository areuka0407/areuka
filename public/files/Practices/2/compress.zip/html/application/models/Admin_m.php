<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_m extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function exist_code($code){
        $this->db->from("managers");
        $this->db->where("remember_code", $code);
        $q = $this->db->get();
        if ($q->num_rows() === 0) return false;
        else return $q->row();
    }
}