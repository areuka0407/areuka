<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Board_m extends CI_Model {

    var $table = 'Board';
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function get_list($table='articles', $type='', $offset='', $limit='', $search_word='',  $site='')
    {
        if ( $search_word != '' )
        {
            //검색어가 있을 경우의 처리
            $this->db->like('articles.title', $search_word);
            $this->db->or_like('articles.contents', $search_word);
        }
        
        if ($limit != '' OR $offset != '')
        {
            
            //페이징이 있을 경우의 처리
            if($offset <= 1){
                $offset = 0;
            }else if($offset == 2){
                $offset =  5;
            }else{
                $offset = ($offset-1)*$limit;
            }
        }
       
        
        $this->db->select('articles.*, users.name AS writer');
        $this->db->from('articles');
        $this->db->join('boards', 'boards.idboard = articles.idboard');
        $this->db->join('users', 'users.idusers = articles.idusers');
        $this->db->where('boards.idsite', $site);
        $this->db->order_by('articles.idarticle', 'DESC');
      
       
        if ($type == 'count') 
        { 
            
            $query = $this->db->get();
            $result = $query->num_rows(); 
        }
        else
        {
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
            $result = $query->result();
        }
       
       
        //return $this->db->last_query();  
        return $result;
    }
    

    /**
	 * 게시물 상세보기 가져오기
	 *
	 * @author HaeRyong Jeong <jhr1843@naver.com>
	 * @param string $table 게시판 테이블
	 * @param string $id 게시물번호
	 * @return array
	 */
    function get_detail($_id)
    {
        $query = $this->db->get_where('articles', array('idarticle' => $_id));
       
        //쿼리결과 리턴
        $result = $query->row();
        return $result;
    }

    function get_writer($_id){
       $query = $this->db->get_where('users', array('idusers' => $_id));
       
       //쿼리결과 리턴
       $result = $query->row();
       return $result;
    }

     //공지사항 최신글 가져오기
     public function noticeLatestPosts($_idsite)
     {
         $this->load->model("front/board_m");
         $this->db->select('articles.*, users.name AS writer, users.regDate AS uregDate');
         $this->db->from('articles');
         $this->db->join('boards', 'boards.idboard = articles.idboard');
         $this->db->join('users', 'users.idusers = articles.idusers');
         $this->db->where('boards.idsite', $_idsite);
         $this->db->order_by('articles.regDate', 'DESC');
         $this->db->limit(10);
         $query = $this->db->get();
         $result = $query->result();
         return $result;
           
     }
}