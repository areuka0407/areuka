<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Schedule_m extends CI_Model {

    var $table = 'symposiums';
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function get_list($table, $site='', $type='', $offset='', $limit='', $search_word='')
    {
        $sword= '';
        
        if ( $search_word != '' )
        {
            //검색어가 있을 경우의 처리
            $this->db->like('title', $search_word);
            $this->db->or_like('description', $search_word);           
        }
        
       
        if ($limit != '' OR $offset != '')
        {
            
            //페이징이 있을 경우의 처리
            if($offset <= 1){
                $offset = 0;
            }else if($offset == 2){
                $offset =  5;
            }else{
                $offset = ($offset-1)*$limit;
            }
        }
      
        $this->db->from('symposiums');
        $this->db->where('idsite', $site);
        $this->db->order_by('idsymposium', 'DESC');
       //$this->db->limit($offset, $limit);
        $query = $this->db->get();
        
        if ($type == 'count')
        {
            //리스트를 반환하는 것이 아니라 전체 게시물의 갯수를 반환
            $result = $query->num_rows();
            //$this->db->count_all($table);
        }
        else
        {
            //게시물 리스트 반환
            $result = $query->result();
        }
        //return $this->db->last_query();  
        return $result;
    }
    

    /**
	 * 게시물 상세보기 가져오기
	 *
	 * @author HaeRyong Jeong <jhr1843@naver.com>
	 * @param string $table 게시판 테이블
	 * @param string $id 게시물번호
	 * @return array
	 */
    function get_detail($_id)
    {
    	$this->db->from('symposiums');
    	$this->db->where('idsymposium', $_id);
    	$query = $this->db->get();
    	$result = $query->row();
    	return $result;
    }

    function get_live($_id)
    {
    	$this->db->from('symposiums');
    	$this->db->where('idsymposium', $_id);
    	$query = $this->db->get();
    	$result = $query->row();
    	return $result;
    }

    function simposiumLatestPosts($_site){
        $this->db->from('symposiums');
        $this->db->where('idsite', $_site);
        $this->db->order_by('idsymposium', 'DESC');
        $this->db->limit(10);
        $query = $this->db->get();
        $result = $query->result();
        //return $this->db->last_query();  
        return $result;
    }
}