<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//메세지 출력 후 이동
function alert($msg='이동합니다', $url='') 
{
	echo "
		<script type='text/javascript'>
			alert('".$msg."');
			location.replace('".$url."');
		</script>
	";
	exit;
}

// 창닫기
function alert_close($msg) 
{
	$CI =& get_instance();
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=".$CI->config->item('charset')."\">";
	echo "<script type='text/javascript'> alert('".$msg."'); window.close(); </script>";
	exit;
}

// 경고창 만
function alert_only($msg, $exit=TRUE) 
{
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=".$CI->config->item('charset')."\">";
	echo "<script type='text/javascript'> alert('".$msg."'); </script>";
	if ($exit) exit;
}

function replace($url='/') {
	echo "<script type='text/javascript'>";
    if ($url)
        echo "window.location.replace('".$url."');";
	echo "</script>";
	exit;
}

function back($message = ""){
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">";
	echo "<script type='text/javascript'>";
	if ($message !== "")  echo "alert('$message');";
	echo "history.back();";
  	echo "</script>";
}

// 디버깅
function dd(){
    foreach (func_get_args() as $arg){
        echo "<pre>";
        var_dump($arg);
        echo "</pre>";
    }
}

/* End of file */
