<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this->load->model('/manager/manager_m');
        $this->load->helper(array('form', 'date', 'url'));
        $this->load->helper(array('directory','alert','file'));
    }

    public function index()
    {
    }

    /*function set_theme(){

        $this->load->model("front/common_m");
        //현재 주소 가져오기
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);
        if( $site['config'] ->idsite){
            $_idsite= $site['config']->idsite;
        }
            
        //pages 가져오기
        $view['pages'] = $this->common_m->get_pages($_idsite);
    
        //theme 가져오기  
        $view['layout'] = $this->common_m->get_theme($_idsite);  
        
        if(is_dir(APPPATH.'views/page/'.$view['layout']->relativePath)==false){
             
            //디렉터리  
            mkdir(APPPATH.'views/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template, 0777, true);
    
            $dirMap = directory_map(APPPATH .'views/template/'.$view['layout']->template.'/', 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = APPPATH.'views/template/'.$view['layout']->template."/".$dm;
                
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
    }*/
    
    /*function set_theme($_id){
        //선택된 테마 idsite
        $_idsite = $_id;
        $this->load->model("front/common_m");

        //pages 가져오기
        $view['pages'] = $this->common_m->get_pages($_idsite);
    
        //theme 가져오기  
        $view['layout'] = $this->common_m->get_theme($_idsite);  
        
        if(is_dir(APPPATH.'views/page/'.$view['layout']->relativePath)==false){
             
            //디렉터리  
            mkdir(APPPATH.'views/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template, 0777, true);
    
            $dirMap = directory_map(APPPATH .'views/template/'.$view['layout']->template.'/', 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = APPPATH.'views/template/'.$view['layout']->template."/".$dm;
                
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
    }*/

    //탬플릿 내용 수정
    function set_modify_theme(){
        $o_templeate = $this->input->post('o_templeate', TRUE);
        $c_templeate = $this->input->post('c_templeate', TRUE);
        $_file = $this->input->post('_file', TRUE);
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', TRUE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', TRUE);
        
        $o_data = APPPATH .'views/template/'.$o_templeate.$_file;
        $c_data = APPPATH .'views/template/'.$c_templeate.$_file;
     
        //파일이 있는지 확인
        if(is_file($o_data)){
            //파일 읽기
            $fp = read_file($o_data);
            //읽은 파일에 내용 확인
            if (strcmp($fp, $o_content)){
                //변경할 내용으로 치환하기
                $_data = str_replace($o_content, $c_content, $fp);
            }
            //파일쓰기
            write_file($o_data, $_data);
            
            if(write_file($o_data, $_data)){
                alert('파일이 정상적으로 수정되었습니다.', '/main');
            }else{
                alert('파일이 정상적으로 수정되지 않았습니다.', '/main');
            }
        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', '/main');
        }
        
    }
  
    // 탬플릿 설정
    function set_theme($_relativePath, $_templeate){

        /**
         * 
         * 
         * @$_relativePath (상대경로)
         * @$_templeat(탬플릿)
         * 
         * 
         */
        

        //탬플릿 원본
        $o_templeate = APPPATH .'views/template/'.$_templeate.'/';
        //탬플릿 복사 위치
        $c_templeate = APPPATH.'views/page/'.$_relativePath.'/template/'.$_templeate."/";
        
        if(is_dir($c_templeat) == false){
            //디렉터리  
            mkdir($c_templeat, 0777, true);
            //탬플릿 복사(파일)
            $dirMap = directory_map($o_templeate, 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = $o_templeat.$dm;
                
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$_relativePath.'/template/'.$_templeate."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
    } 
   
    /*function set_theme($_relativePath, $_templeat){


        //탬플릿 원본
        $o_templeat = APPPATH .'views/template/'.$_templeat.'/';
        //탬플릿 복사 위치
        $c_templeat = APPPATH.'views/page/'.$_templeat;
        
        if(is_dir() == false){
            //디렉터리  
            mkdir($c_templeat, 0777, true);
            //탬플릿 복사(파일)
            $dirMap = directory_map($o_templeat, 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = $o_templeat.$dm;
                
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$_relativePath.'/template/'.$view['layout']->template."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
} */


    //디렉터리와 파일 복사
    function copy_directory($src_dir, $dest_dir)
    {
        if($src_dir == $dest_dir)
            return false;
        if(!is_dir($src_dir))
            return false;
        if(!is_dir($dest_dir)) {
            @mkdir($dest_dir, 0707);
            @chmod($dest_dir, 0707);
        }
        $dir = opendir($src_dir);
        while (false !== ($filename = readdir($dir))) {
            if($filename == "." || $filename == "..")
                continue;
            $files[] = $filename;
        }
        for($i=0; $i<count($files); $i++) {
            $src_file = $src_dir.'/'.$files[$i];
            $dest_file = $dest_dir.'/'.$files[$i];
            if(is_file($src_file)) {
                copy($src_file, $dest_file);
                @chmod($dest_file, 0606);
            }
        }
    }
   
}