<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Counseling extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        
        if(@$this->session->userdata('logged_in') == false)
        {
            redirect('/member/login', location);
        }
    }

    public function index()
    {
        $this->counseling();
    }


    public function counseling()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
             //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기  
            $view['layout'] = $this->common_m->get_theme($_idsite);  
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
         //브라우저에 따라 pc&mobile 테마가져오기
         if ($this->agent->is_browser())
         {
             //상대경로가 없으면 기본 탬플릿 표시
             if($view['layout']->relativePath){
                 $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling';
             }else{
                 $mainPage ='/template/A/member/counseling';
             }
             $this->load->view($mainPage, $view);
         }
         elseif ($this->agent->is_mobile())
         {
             if($view['layout']->relativePath){
                 $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/member/counseling';
             }else{
                 $mainPage ='/template/A/mobile/member/counseling';
             }
             //mobileTheme 가져오기  
             $this->load->view($mainPage, $view); 
         }     
    } 
    
    public function test()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, $view['layout']->template);
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    public function test2()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, $view['layout']->template);
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/member/counseling-test2.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/member/counseling-test2.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
}

/* End of file guide.php */
/* Location: ./application/controllers/guide.php */