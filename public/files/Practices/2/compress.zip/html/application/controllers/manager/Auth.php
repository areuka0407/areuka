<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this -> load -> helper('alert');
        $this->load->model('/manager/manager_m');
        $this->load->helper(array('form', 'date', 'url'));

    }

    public function index()
    {
        $this->login();
    }

    function join_agree(){
        $this->load->model("front/Common_m");
        $view['layout'] = $this->Common_m->get_theme();  
        $this->load->view('template/'.$view['layout']->template.'/member/join_agree', $view);
    }
    //회원가입
    function join(){
        //폼 검증 라이브러리 로드
        $this->load->library('form_validation');
                
        //폼 검증할 필드와 규칙 사전 정의
        $this->form_validation->set_rules('id', '아이디', 'required');
        $this->form_validation->set_rules('password', '패스워드', 'required');
        $this->form_validation->set_rules('name', '이름', 'required');
        $this->form_validation->set_rules('last_idsite', '사이트', 'required');

        //폼 검증이 정상적으로 완료되면
        if ($this->form_validation->run() == TRUE)
        {
                  
            $id = $this->input->post('id', TRUE);
            $password = $this->input->post('password', TRUE);
            $name = $this->input->post('name', TRUE);
            $last_idsite = $this->input->post('last_idsite', TRUE);
            //가맹점 데이터 등록
            $auth_data = array(
                'id' =>  $userid,
                'password' =>  $password,
                'name' => $name,
                'last_idsite' => $last_idsite,         
            );

            //중복 회원 가입확인
            $manager_check = $this->manager_m->user_check('manages' ,$id);
            if($manager_check){
                alert('이미 회원가입되어 있는 아이디 입니다.' , '/manager/login');
            }else{
                $result = $this->manager_m->join($auth_data);
                if($result){
                    alert('정상적으로 회원가입되었습니다.' , '/manager/login'); 
                }else{
                    alert('정상적으로 회원가입이 되지 않았습니다.\n 잠시 후 다시 시도해주세요.' , '/manager/join'); 
                }
            }
        }else{
            //$this->load->model("front/Common_m");
           // $view['layout'] = $this->Common_m->get_theme();  
            $this->load->view('/manager/join_form');
        }
    }

    //회원정보수정
    function modify(){
        //폼 검증 라이브러리 로드
        $this->load->library('form_validation');
                
        //폼 검증할 필드와 규칙 사전 정의
       // $this->form_validation->set_rules('id', '아이디', 'required');
        //$this->form_validation->set_rules('password', '패스워드', 'required');
        $this->form_validation->set_rules('name', '이름', 'required');
        $this->form_validation->set_rules('last_idsite', '사이트', 'required');

        //폼 검증이 정상적으로 완료되면
        if ($this->form_validation->run() == TRUE)
        {
            
            //$id = $this->input->post('id', TRUE);
            //$password = $this->input->post('password', TRUE);
            $name = $this->input->post('name', TRUE);
            $last_idsite = $this->input->post('last_idsite', TRUE);
      
            //회원 정보 수정데이터
            $modify_data = array(
                'idusers'=> $this->session->userdata('idusers'),
                'userid' =>  $userid,
                'password' =>  $password,
                'email' => $email,
                /*'name' => $name,
                'firstname' => $firstname,
                'lastname' => $lastname,*/
                'phone' => $phone,               
            );
            $result = $this->manager_m->modify($modify_data);
            if($result){
                alert('회원정보가 정상적으로 수정되었습니다.' , '/manager/login'); 
            }else{
                alert('회원정보가 수정되지 않았습니다.\n 잠시 후 다시 시도해주세요.' , '/manager/modify'); 
            }
        }else{
            $view['auth'] = $this->manager_m->get_user($this->session->userdata('idusers'));  
            $this->load->view('/manager/modify_form', $view);
        }
    }


    function login()
    {
        //폼 검증 라이브러리 로드
        $this->load->library('form_validation');
        
        //폼 검증할 필드와 규칙 사전 정의
        $this->form_validation->set_rules('id', '아이디', 'required');
        $this->form_validation->set_rules('password', '패스워드', 'required');
  
        //폼 검증이 정상적으로 완료되면
        if ($this->form_validation->run() == TRUE)
        {
            if(@$this->session->userdata('logged_in')==true)
            {
                alert('이미 로그인 되어 있습니다.', '/manager/main');

            }else{
                $login_data = array(
                    'id' => $this->input->post('id', TRUE),
                    'password' => $this->input->post('password', TRUE)
                );
                

                $result = $this->manager_m->login($login_data);
                if($result){
                    //세션 생성
                     $auth_data = array(
                    'idmanager' => $result['idmanager'],
                    'id' => $result['id'],
                    'name'  => $result['name'],                
                    'last_idsite'  => $result['last_idsite'],                                    
                    'logged_in' => TRUE
                    );    
                    alert($this->session->userdata('name').'님 반갑습니다.', '/manager/main'); 
                }else{
                    alert('아이디와 비밀번호를 확인 해주세요.', '/manager/login');
                }
                
            }
        }else{
            $this->load->view('/manager/login');
        } 
    }
}

/* End of file counseling.php */
/* Location: ./application/controllers/counseling.php */