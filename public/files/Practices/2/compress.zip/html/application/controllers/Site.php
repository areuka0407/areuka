<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index($sitePath)
    {
        $this->load->model("front/common_m");
       
        $row = $this->common_m->get_idsite($sitePath);
        //print_r($this->session->all_userdata());
        //exit;
        
        if ($row != null) {
            
            //idsite ���ؼ� Ʋ���� �α׾ƿ� ó��
            if($this->session->set_userdata('idsite') != $row->idsite){
                $this->session->unset_userdata('idusers');
                $this->session->unset_userdata('userid');
                $this->session->unset_userdata('name');
                $this->session->unset_userdata('fistname');
                $this->session->unset_userdata('lastname');
                $this->session->unset_userdata('email');
                $this->session->unset_userdata('phone');
                $this->session->unset_userdata('logged_in');
            }
            $this->session->set_userdata('idsite', $row->idsite);
            redirect('/main', 'refresh');
        } else {
            show_404();
        }
    }
}