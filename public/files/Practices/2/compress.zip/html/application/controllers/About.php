<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class About extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    
    function __construct()
    {
        parent::__construct(); 
        $this->load->helper('url');
        $this->load->library('user_agent');
        
        if(@$this->session->userdata('logged_in') == false)
        {
            redirect('/member/login', location);
        }
    }

    public function index()
    {
        $this->about();
    }


    public function about()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
             //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기  
            $view['layout'] = $this->common_m->get_theme($_idsite);  
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/about/about';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about';
               // $mainPage ='/template/A/about/about';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/about/about';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about';
                //$mainPage ='/template/A/mobile/about/about';
            }
            //mobileTheme 가져오기  
            $this->load->view($mainPage, $view); 
        }
    }


    public function test()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/about/about-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/about/about-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    
    
    public function test2()
    {
        
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/about/about-test2.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about-test2.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/about/about-test2.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/about/about-test2.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    
    function set_modify_theme(){
        $this->load->helper("alert");
        
        $_relative_path = $this->input->post("_relative_path", TRUE);
        $_current_url = $this->input->post("_current_url", TRUE);
        
        $_templeate = $this->input->post('_templeate', TRUE);
        $_segment = $this->input->post('_segment', TRUE);
        $_file = $this->input->post('_file', TRUE);
 
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', FALSE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', FALSE);

        $o_data = APPPATH.'views/page/'.$_relative_path.'/template/'.$_templeate.'/'.$_segment.'/'.$_file;
        $c_data = APPPATH.'views/page/'.$_relative_path.'/template/'.$_templeate.'/'.$_segment.'/'.$_file;

 

        //print_r($o_content);
        //print_r($c_content);

        //파일 일기
        $o_content = explode('|',  $o_content);
        $c_content = explode('|',  $c_content);

//        print_r($o_data);
//        print_r($c_content);
//        exit;
        //파일이 있는지 확인
        $this->load->helper("alert");
        if(is_file($o_data)){

            //파일 읽기
            $rp = file_get_contents($o_data);

            //읽은 파일에 내용 확인
            for($i=0;$i < count($o_content);$i++){

                //변경할 내용으로 치환하기
                $rp  = str_replace($o_content[$i], $c_content[$i], $rp);

                file_put_contents($o_data, $rp);

                if(!file_put_contents($o_data, $rp)){
                    alert('파일이 정상적으로 수정되지 않았습니다.', $_current_url);
                }
            }


        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', $_current_url);
        }


        alert('파일이 정상적으로 수정되었습니다.', $_current_url);
    }
    
    function set_modify_theme2(){
        $this->load->helper('alert');
        $_templeate = $this->input->post('_templeate', TRUE);
        $_segment = $this->input->post('_segment', TRUE);
        $_file = $this->input->post('_file', TRUE);
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', FALSE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', FALSE);
        
        $o_data = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$_file;
        $c_data = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$_file;
        
        $o_content = explode('|',  $o_content);
        $c_content = explode('|',  $c_content);

        //파일이 있는지 확인
        if(is_file($o_data)){
            
            //파일 읽기
            $rp = file_get_contents($o_data);
            
            //읽은 파일에 내용 확인
            for($i=0;$i < count($o_content);$i++){
                
                //변경할 내용으로 치환하기
                $rp  = str_replace($o_content[$i], $c_content[$i], $rp);
                
                file_put_contents($o_data, $rp);
                
                if(!file_put_contents($o_data, $rp)){
                    alert('파일이 정상적으로 수정되지 않았습니다.', '/about/test2');
                }
            }

        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', '/about/test2');
        }
        
        alert('파일이 정상적으로 수정되었습니다.', '/about/test2');
    }
}

/* End of file about.php */
/* Location: ./application/controllers/about.php */