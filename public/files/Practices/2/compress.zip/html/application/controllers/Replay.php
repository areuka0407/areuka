<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Replay extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this -> load -> helper('alert');
        $this->load->model('/front/replay_m');
        $this->load->helper(array('form', 'date', 'url'));
        $this->load->library('url_explode');
        $this->load->library('segment_explode');
        
        if(@$this->session->userdata('logged_in') == false)
        {
            redirect('/member/login', location);
        }
    }

    function index(){
        $this->lists(); 
    }
    
    public function lists()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
             //pages 가져오기
            $data['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기  
            $data['layout'] = $this->common_m->get_theme($_idsite);  
        }else{
            $data['pages'] = $this->config->item('default_page');
            $data['layout'] = $this->config->item ('default_theme');
        }
        
        //검색어 초기화
        $search_word = $page_url = '';
        $uri_segment = 4;
        //주소중에서 q(검색어) 세그먼트가 있는지 검사하기 위해 주소를 배열로 변환
        $uri_array = $this->segment_explode->_explode($this->uri->uri_string());
        if( in_array('q', $uri_array) ) {
            //주소에 검색어가 있을 경우의 처리. 즉 검색시
            $search_word = urldecode($this->url_explode($uri_array, 'q'));
            //페이지네이션용 주소
            $page_url = '/q/'.$search_word;
            $uri_segment = 6;
        }
        
        /* //페이지네이션 라이브러리 로딩 추가
        $this->load->library('pagination');
        
        //페이지네이션 설정
        $config['base_url'] = '/replay/lists/'.$page_url.'/page/'; //페이징 주소
        $config['total_rows'] = $this->replay_m->get_list('vods', 'count', '', '', $search_word, $_idsite); //게시물의 전체 갯수
        
        $config['use_page_numbers'] = TRUE;
        $config['per_page'] = 5;
        $config['uri_segment'] = $uri_segment; //페이지 번호가 위치한 세그먼트
        //$config['num_links'] = 2;  //좌우로 보여지는  NUMBER 갯수
        $config['cur_tag_open'] = '<a class="on" href="#">';
        $config['cur_tag_close'] = '</a>';
        $config["num_tag_open"] = '';
        $config["num_tag_close"] = '';
        $config['first_link'] = FALSE;
        $config['last_link'] = FALSE;
        $config['prev_link'] = FALSE;
        $config['next_link'] = FALSE;
        
        //페이지네이션 초기화
        $this->pagination->initialize($config);
        //페이징 링크를 생성하여 view에서 사용할 변수에 할당
        $data['pagination'] = $this->pagination->create_links();
        
        //게시판 목록을 불러오기 위한 offset, limit 값 가져오기
        $data['page'] = $page = $this->uri->segment($uri_segment, 1);
        
        if ($page > 1) {
            $start = (($page / $config['per_page'])) * $config['per_page'];
        } else {
            $start = ($page - 1) * $config['per_page'];
        }
        
        $limit = $config['per_page'];
        
        //전체 페이지 가져오기
        if( $config['total_rows'] > 0 && $limit > 0) {
            $total_pages = ceil($config['total_rows']/$limit);
        } else {
            $total_pages = 0;
        } 
        
        $data['list'] = $this->replay_m->get_list('vods', '', $start, $limit, $search_word, $_idsite);
        $data['first_url'] = '/board/lists'.$page_url.'/page/1';
        $data['last_url'] = '/board/lists'.$page_url.'/page/'.$total_pages;  */
        
        $data['list'] = $this->replay_m->get_list('vods', '', '', '', $search_word, $_idsite);
        
         //브라우저에 따라 pc&mobile 테마가져오기
         if ($this->agent->is_browser())
         {
             //상대경로가 없으면 기본 탬플릿 표시
             if(!empty($data['layout']->relativePath)){
                 $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/replay/list';
             }else{
                 $mainPage ='/template/'.$data['layout']->template.'/replay/list';
             }
             $this->load->view($mainPage, $data);
         }
         elseif ($this->agent->is_mobile()) 
         {
            if(!empty($data['layout']->relativePath)){
                 $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/replay/list';
             }else{
                 $mainPage ='/template/'.$data['layout']->template.'/replay/list';
             }
             //mobileTheme 가져오기  
             $this->load->view($mainPage, $data); 
         }
    }

    public function test(){
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
            //pages 가져오기
            $data['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $data['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $data['pages'] = $this->config->item('default_page');
            $data['layout'] = $this->config->item ('default_theme');
        }

        //검색어 초기화
        $search_word = $page_url = '';
        $uri_segment = 4;
        //주소중에서 q(검색어) 세그먼트가 있는지 검사하기 위해 주소를 배열로 변환
        $uri_array = $this->segment_explode->_explode($this->uri->uri_string());
        if( in_array('q', $uri_array) ) {
            //주소에 검색어가 있을 경우의 처리. 즉 검색시
            $search_word = urldecode($this->url_explode($uri_array, 'q'));
            //페이지네이션용 주소
            $page_url = '/q/'.$search_word;
            $uri_segment = 6;
        }

        /* //페이지네이션 라이브러리 로딩 추가
        $this->load->library('pagination');

        //페이지네이션 설정
        $config['base_url'] = '/replay/lists/'.$page_url.'/page/'; //페이징 주소
        $config['total_rows'] = $this->replay_m->get_list('vods', 'count', '', '', $search_word, $_idsite); //게시물의 전체 갯수

        $config['use_page_numbers'] = TRUE;
        $config['per_page'] = 5;
        $config['uri_segment'] = $uri_segment; //페이지 번호가 위치한 세그먼트
        //$config['num_links'] = 2;  //좌우로 보여지는  NUMBER 갯수
        $config['cur_tag_open'] = '<a class="on" href="#">';
        $config['cur_tag_close'] = '</a>';
        $config["num_tag_open"] = '';
        $config["num_tag_close"] = '';
        $config['first_link'] = FALSE;
        $config['last_link'] = FALSE;
        $config['prev_link'] = FALSE;
        $config['next_link'] = FALSE;

        //페이지네이션 초기화
        $this->pagination->initialize($config);
        //페이징 링크를 생성하여 view에서 사용할 변수에 할당
        $data['pagination'] = $this->pagination->create_links();

        //게시판 목록을 불러오기 위한 offset, limit 값 가져오기
        $data['page'] = $page = $this->uri->segment($uri_segment, 1);

        if ($page > 1) {
            $start = (($page / $config['per_page'])) * $config['per_page'];
        } else {
            $start = ($page - 1) * $config['per_page'];
        }

        $limit = $config['per_page'];

        //전체 페이지 가져오기
        if( $config['total_rows'] > 0 && $limit > 0) {
            $total_pages = ceil($config['total_rows']/$limit);
        } else {
            $total_pages = 0;
        }

        $data['list'] = $this->replay_m->get_list('vods', '', $start, $limit, $search_word, $_idsite);
        $data['first_url'] = '/board/lists'.$page_url.'/page/1';
        $data['last_url'] = '/board/lists'.$page_url.'/page/'.$total_pages;  */

        $data['list'] = $this->replay_m->get_list('vods', '', '', '', $search_word, $_idsite);

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/replay/list-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/replay/list-test.php';
            }
            $this->load->view($mainPage, $data);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/replay/list-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/replay/list-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $data);
        }
    }

    /**
     * 게시물 보기
     */
    function detail()
    {
        $_id = $this->uri->segment(3);
        //게시판 이름과 게시물 번호에 해당하는 게시물 가져오기
        $view['detail'] = $this->replay_m->get_detail($_id);
        //view 호출
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
             //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기  
            $view['layout'] = $this->common_m->get_theme($_idsite);  
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/replay/view';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/replay/view';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/replay/view';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/replay/view';
            }
            //mobileTheme 가져오기  
            $this->load->view($mainPage, $view); 
        }
    }
    function detail_test(){
        $_id = $this->uri->segment(3);
        //게시판 이름과 게시물 번호에 해당하는 게시물 가져오기
        $view['detail'] = $this->replay_m->get_detail($_id);
        //view 호출
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/replay/view-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/replay/view-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/replay/view-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/replay/view-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }

    /**
     * 게시물 쓰기 
     */
    function write()
    {
        //경고창 헬퍼 로딩
        $this->load->helper('alert');
        echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
        if( @$this->session->userdata('logged_in') == TRUE )
        {
            //폼 검증 라이브러리 로드
            $this->load->library('form_validation');
            //폼 검증할 필드와 규칙 사전 정의
            $this->form_validation->set_rules('title', '제목', 'required');
            $this->form_validation->set_rules('description', '내용', 'required');
            if ($this->form_validation->run() == TRUE)
            {
                //주소중에서 page 세그먼트가 있는지 검사하기 위해 주소를 배열로 변환
                $uri_array = $this->segment_explode->_explode($this->uri->uri_string());
                if(in_array('page', $uri_array))
                {
                    $pages = urldecode($this->url_explode($uri_array, 'page'));
                }
                else
                {
                    $pages = 1;
                }
                $write_data = array(
                    'table' => 'vods', //게시판 테이블명
                    'title' => $this->input->post('title', TRUE),
                    'description' => $this->input->post('description', TRUE),
                    'idarticle' => $this->session->userdata('idarticle')
                );
                
                $result = $this->replay_m->insert_vods($write_data);

                if ($result)
                {
                    //글 작성 성공
                    alert('입력되었습니다.', '/replay/lists/'.$this->uri->segment(3).'/p/'.$pages);
                    exit;
                }
                else
                {
                    //글 실패시 게시판 목록으로
                    alert('다시 입력해 주세요.', '/replay/lists/'.$this->uri->segment(3).'/p/'.$pages);
                    exit;
                }
            }
            else
            {
                //쓰기폼 view 호출
                $this->load->view('/replay/write_v');
            }
        }
        else
        {
            alert('로그인후 작성하세요', 'member/login');
            exit;
        }
    }

    function set_modify_theme(){
        $this->load->helper("alert");
        $_relative_path = $this->input->post("_relative_path", TRUE);
        $_current_url = $this->input->post("_current_url", TRUE);
        
        $_templeate = $this->input->post('_templeate', TRUE);
        $_segment = $this->input->post('_segment', TRUE);
        $_file = $this->input->post('_file', TRUE);
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', FALSE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', FALSE);

        $o_data = APPPATH.'views/page/'.$_relative_path.'/'.$_templeate.'/'.$_segment.'/'.$_file;
        $c_data = APPPATH.'views/page/'.$_relative_path.'/'.$_templeate.'/'.$_segment.'/'.$_file;

//        dd($c_content);
//        exit;
        //print_r($o_content);
        //print_r($c_content);

        //파일 일기
        $o_content = explode('|',  $o_content);
        $c_content = explode('|',  $c_content);

        //print_r($o_data);
        //print_r($c_content);
        //exit;
        //파일이 있는지 확인
        if(is_file($o_data)){

            //파일 읽기
            $rp = file_get_contents($o_data);

            //읽은 파일에 내용 확인
            for($i=0;$i < count($o_content);$i++){

                //변경할 내용으로 치환하기
                $rp  = str_replace($o_content[$i], $c_content[$i], $rp);

                file_put_contents($o_data, $rp);

                if(!file_put_contents($o_data, $rp)){
                    alert('파일이 정상적으로 수정되지 않았습니다.', $_current_url);
                }
            }


        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', $_current_url);
        }


        alert('파일이 정상적으로 수정되었습니다.', $_current_url);
    }
}