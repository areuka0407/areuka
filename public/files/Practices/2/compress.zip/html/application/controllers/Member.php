<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Member extends CI_Controller {
    
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this->load-> helper('alert');
        //$this->load->driver('session');
        $this->load->model('/front/member_m');
        $this->load->model("front/common_m");
        $this->load->helper(array('form', 'date', 'url', 'cookie'));    
    }
    
    public function index()
    {
        $this->login();
    }
    
    function join_agree(){
        
        if(@$this->session->userdata('logged_in') == true && uri_string() != "member/counseling" && @$this->session->userdata("idmanagers") === false)
        {
            alert('이미 로그인한 회원입니다', '/main');
        }
        else{
        
            $this->load->model("front/common_m");
            $this->load->library('user_agent');
            
            //현재 주소 가져오기
            $currentDomain =  $_SERVER['HTTP_HOST'];
            $currentUrl =  $_SERVER['REQUEST_URI'];
            
            $site['config'] = $this->common_m->get_site_config($currentUrl);
            if(!empty($site['config'] ->idsite)){
                $data['idsite'] = $site['config']->idsite;
            }else if ($this->session->userdata('idsite') != null){
                $data['idsite'] = $this->session->userdata('idsite');
            } else {
                show_404();
            }
            if(!empty($data['idsite'])){
                
                //pages 가져오기
                $data['pages'] = $this->common_m->get_pages($data['idsite']);
                
                //theme 가져오기
                $data['layout'] = $this->common_m->get_theme($data['idsite']);
            }else{
                $data['pages'] = $this->config->item('default_page');
                $data['layout'] = $this->config->item ('default_theme');
            }
            
            //브라우저에 따라 pc&mobile 테마가져오기
            if ($this->agent->is_browser())
            {
                //상대경로가 없으면 기본 탬플릿 표시
                if($data['layout']->relativePath){
                    $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_agree';
                }else{
                    $mainPage ='/template/'.$data['layout']->template.'member/join_agree';
                }
                $this->load->view($mainPage, $data);
            }
            elseif ($this->agent->is_mobile())
            {
                if($data['layout']->relativePath){
                    $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_agree';
                }else{
                    $mainPage ='/template/'.$data['layout']->template.'member/join_agree';
                }
                //mobileTheme 가져오기
                $this->load->view($mainPage, $data);
            }
        }
    }
    function join_agree_test(){
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);
        if(!empty($site['config'] ->idsite)){
            $data['idsite'] = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $data['idsite'] = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($data['idsite'])){

            //pages 가져오기
            $data['pages'] = $this->common_m->get_pages($data['idsite']);

            //theme 가져오기
            $data['layout'] = $this->common_m->get_theme($data['idsite']);
        }else{
            $data['pages'] = $this->config->item('default_page');
            $data['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($data['layout']->relativePath){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_agree-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/member/join_agree-test.php';
            }
            $this->load->view($mainPage, $data);
        }
        elseif ($this->agent->is_mobile())
        {
            if($data['layout']->relativePath){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_agree-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/member/join_agree-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $data);
        }
    }

    //회원가입
    function join(){
        if(@$this->session->userdata('logged_in') == true && @$this->session->userdata("idmanagers") === false){
            alert('이미 가입된 회원입니다', '/main');
        }else{
           //폼 검증 라이브러리 로드
            $this->load->library('form_validation');
            
            //폼 검증할 필드와 규칙 사전 정의
            $this->form_validation->set_rules('userid', '아이디', 'required');
            $this->form_validation->set_rules('password', '패스워드', 'required');
            $this->form_validation->set_rules('email', '이메일', 'required');
            $this->form_validation->set_rules('firstname', '성', 'required');
            $this->form_validation->set_rules('lastname', '이름', 'required');
            $this->form_validation->set_rules('phone', '핸드폰번호', 'required');
            
            //폼 검증이 정상적으로 완료되면
            if ($this->form_validation->run() == TRUE)
            {
                $userid = $this->input->post('userid', TRUE);
                $password = $this->input->post('password', TRUE);
                $email = $this->input->post('email', TRUE);
                $firstname = $this->input->post('firstname', TRUE);
                $lastname = $this->input->post('lastname', TRUE);
                $phone = $this->input->post('phone', TRUE);
                if(strpos($phone, '-')!== false){
                   $ph = explode($phone);
                   $phone = $ph[0].$ph[1].$ph[2];
                }
                $hospital = $this->input->post('hospital', TRUE);
                $course= $this->input->post('course', TRUE);
                $salesofficer = $this->input->post('salesofficer', TRUE);
                $salesgroup = $this->input->post('salesgroup', TRUE);
                $userid = $this->input->post('userid', TRUE);
                $currentUrl =  $_SERVER['REQUEST_URI'];
                //$idsite = $this->get_idsite($currentUrl);
                
                $currentUrl =  $_SERVER['REQUEST_URI'];
                $site['config'] = $this->common_m->get_site_config($currentUrl);
                
                if(!empty($site['config'] ->idsite)){
                    $_idsite = $site['config']->idsite;
                }else if ($this->session->userdata('idsite') != null){
                    $_idsite = $this->session->userdata('idsite');
                } else {
                    show_404();
                }
                //가맹점 데이터 등록
                $auth_data = array(
                    'userid' =>  $userid,
                    'password' =>  $password,
                    'email' => $email,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'name' => $firstname.$lastname,
                    'phone' =>  $phone,
                    'idsite' =>$_idsite
                );
                
                //print_r($auth_data);
                //exit;
                if($hospital){
                    $auth_data['hospital'] = $hospital;
                }
                if($course){
                    $auth_data['course'] = $course;
                }
                if($salesofficer){
                    $auth_data['salesofficer'] = $salesofficer;
                }
                if($salesgroup){
                    $auth_data['salesgroup'] = $salesgroup;
                }
                
                //중복 회원 가입확인
                $user_check = $this->member_m->user_check($userid, $_idsite);
                if($user_check){
                    alert('이미 회원가입되어 있는 아이디 입니다.' , '/member/join');
                }else{
                    $result = $this->member_m->join($auth_data);
                    if($result){
                        alert('정상적으로 회원가입되었습니다.' , '/member/login');
                    }else{
                        alert('정상적으로 회원가입이 되지 않았습니다.\n 잠시 후 다시 시도해주세요.' , '/member/join');
                    }
                }
            }
            else{
                $this->load->model("front/common_m");
                $this->load->library('user_agent');
                
                //현재 주소 가져오기
               // $currentDomain =  $_SERVER['HTTP_HOST'];
                $currentUrl =  $_SERVER['REQUEST_URI'];
                
                $site['config'] = $this->common_m->get_site_config($currentUrl);
                
                if(!empty($site['config'] ->idsite)){
                    $_idsite = $site['config']->idsite;
                }else if ($this->session->userdata('idsite') != null){
                    $_idsite = $this->session->userdata('idsite');
                } else {
                    show_404();
                }
                if(!empty($_idsite)){
                    //pages 가져오기
                    $data['pages'] = $this->common_m->get_pages($_idsite);
                    
                    //theme 가져오기
                    $data['layout'] = $this->common_m->get_theme($_idsite);
                }else{
                    $data['pages'] = $this->config->item('default_page');
                    $data['layout'] = $this->config->item ('default_theme');
                }
                
                //브라우저에 따라 pc&mobile 테마가져오기
                if ($this->agent->is_browser())
                {
                    //상대경로가 없으면 기본 탬플릿 표시
                    if(!empty($data['layout']->relativePath)){
                        $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_form';
                    }else{
                        $mainPage ='/template/'.$data['layout']->template.'/member/join_form';
                    }
                    $this->load->view($mainPage, $data);
                }
                elseif ($this->agent->is_mobile())
                {
                    if(!empty($data['layout']->relativePath)){
                        $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_form';
                    }else{
                        $mainPage ='/template/'.$data['layout']->template.'/member/join_form';
                    }
                    //mobileTheme 가져오기
                    $this->load->view($mainPage, $data);
                }
            }
        }
    }
    function join_test(){
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        // $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($_idsite)){
            //pages 가져오기
            $data['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $data['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $data['pages'] = $this->config->item('default_page');
            $data['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_form-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/member/join_form-test.php';
            }
            $this->load->view($mainPage, $data);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/member/join_form-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/member/join_form-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $data);
        }
    }

    //회원정보수정
    function modify(){
        if(@$this->session->userdata('logged_in') == false){
            alert('로그인이 되어 있지 않습니다.\n로그인 해주세요.', '/member/login');
        }else{
            //폼 검증 라이브러리 로드
            $this->load->library('form_validation');
            
            //폼 검증할 필드와 규칙 사전 정의
            /*($this->form_validation->set_rules('userid', '아이디', 'required');
             $this->form_validation->set_rules('password', '패스워드', 'required');*/
            $this->form_validation->set_rules('email', '이메일', 'required');
            $this->form_validation->set_rules('firstname', '성', 'required');
            $this->form_validation->set_rules('lastname', '이름', 'required');
            $this->form_validation->set_rules('phone', '핸드폰번호', 'required');
            
            //폼 검증이 정상적으로 완료되면
            if ($this->form_validation->run() == TRUE)
            {
              
                //$oldpassword = $this->input->post('oldpassword', TRUE);
                //$newpassword = $this->input->post('newpassword', TRUE);
                $email = $this->input->post('email', TRUE);
                $firstname = $this->input->post('firstname', TRUE);
                $lastname = $this->input->post('lastname', TRUE);
                $phone = $this->input->post('phone', TRUE);
                $name = $firstname.$lastname;
                $hospital = $this->input->post('hospital', TRUE);
                $course = $this->input->post('course', TRUE);
                $salesofficer = $this->input->post('salesofficer', TRUE);
                $salesgroup = $this->input->post('salesgroup', TRUE);
                
                //회원 정보 수정데이터
                $modify_data = array(
                    'idusers'=> $this->session->userdata('idusers'),
                    'oldpassword' =>  $this->input->post('oldpassword', TRUE),
                    'newpassword' =>  $this->input->post('newpassword', TRUE),
                    'email' => $email,
                    'name' => $name,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'phone' => $phone,
                    'idsite' => $this->session->userdata('idsite')
                );
                
                
                if($hospital){
                    $modify_data['hospital'] = $hospital;
                }
                if($course){ 
                    $modify_data['course'] = $course;
                }
                if($salesofficer){
                    $modify_data['salesofficer'] = $salesofficer;
                }
                if($salesgroup){
                    $modify_data['salesgroup'] = $salesgroup;
                }
                
                //print_r($modify_data);
                //exit;
                //echo $hospital;
                $result = $this->member_m->modify($modify_data);
                if($result){
                    alert('회원정보가 정상적으로 수정되었습니다.' , '/main');
                }else{
                    alert('회원정보가 수정되지 않았습니다.\n 잠시 후 다시 시도해주세요.' , '/member/modify');
                }

            }
            else{
                $this->load->model("front/common_m");
                $this->load->library('user_agent');
                
                //현재 주소 가져오기
                $currentDomain =  $_SERVER['HTTP_HOST'];
                $currentUrl =  $_SERVER['REQUEST_URI'];
                
                $site['config'] = $this->common_m->get_site_config($currentUrl);
                
                if(!empty($site['config'] ->idsite)){
                    $_idsite = $site['config']->idsite;
                }else if ($this->session->userdata('idsite') != null){
                    $_idsite = $this->session->userdata('idsite');
                } else {
                    show_404();
                }
                if(!empty($_idsite)){
                    //pages 가져오기
                    $view['pages'] = $this->common_m->get_pages($_idsite);
                    
                    //theme 가져오기
                    $view['layout'] = $this->common_m->get_theme($_idsite);
                }else{
                    $view['pages'] = $this->config->item('default_page');
                    $view['layout'] = $this->config->item ('default_theme');
                }

                
                // 관리자 이면 공백의 회원 정보 삽입
                if ($this->session->userdata("idmanagers") === false)
                    $view['auth'] = $this->member_m->get_user($this->session->userdata('idusers'));
                else
                    $view['auth'] = (object)array("user_id" => "", "email" => "", "firstname" => "", "lastname" => "", "phone" => "");

                //브라우저에 따라 pc&mobile 테마가져오기
                if ($this->agent->is_browser())
                {
                    //상대경로가 없으면 기본 탬플릿 표시
                    if(!empty($view['layout']->relativePath)){
                        $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/modify_form';
                    }else{
                        $mainPage ='/template/'.$view['layout']->template.'/member/modify_form';
                    }
                    $this->load->view($mainPage, $view);
                }
                elseif ($this->agent->is_mobile())
                {
                    if(!empty($view['layout']->relativePath)){
                        $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/member/modify_form';
                    }else{
                        $mainPage ='/template/'.$view['layout']->template.'/mobile/member/modify_form';
                    }
                    //mobileTheme 가져오기
                    $this->load->view($mainPage, $view);
                }
            }
        }
    }
    function modify_test(){
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }

        $view['auth'] = $this->member_m->get_user($this->session->userdata('idusers'));
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/modify_form-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/member/modify_form-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/member/modify_form-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/mobile/member/modify_form-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    
    
    function login()
    {
        $save_id_cookie = $this->input->cookie('save_id_cookie', TRUE);
        
        if(!empty($save_id_cookie)){
            $data['save_id_value'] = $save_id_cookie;
        }
        //폼 검증 라이브러리 로드
        $this->load->library('form_validation'); 
        //폼 검증할 필드와 규칙 사전 정의
        $this->form_validation->set_rules('userid', '아이디', 'required');
        $this->form_validation->set_rules('password', '패스워드', 'required');      
        
        //폼 검증이 정상적으로 완료되면
        if ($this->form_validation->run() == TRUE){


            // 관리자 페이지에 경우, 로그인 불가
            if ($this->session->userdata("idmanagers") == FALSE){
                back("관리자 페이지에서는 지원하지 않는 기능입니다.");
            }

            $check_save_id = $this->input->post('check_save_id', TRUE);
            
            if(@$this->session->userdata('logged_in')==TRUE)
            {
                alert('이미 로그인 되어 있습니다.', '/main');
            }else{
                $currentUrl =  $_SERVER['REQUEST_URI'];
                
                $idsite = $this->get_idsite($currentUrl);
                
                $login_data = array(
                    'userid' => $this->input->post('userid', TRUE),
                    'password' => $this->input->post('password', TRUE),
                    'idsite' => $idsite
                );
                $result = $this->member_m->login($login_data);
                
                if($result){
                    //세션 생성
                    $newdata = array(
                        'idusers' => $result['idusers'],
                        'idsite' => $result['idsite'],
                        'userid'  => $result['userid'],
                        'name' => $result['firstname'].$result['lastname'],
                        'fistname'  => $result['firstname'],
                        'lastname'  => $result['lastname'],
                        'email'  => $result['email'],
                        'phone' => $result['phone'],
                        'logged_in' => TRUE
                    );
                  
                    $this->session->set_userdata($newdata);
                    
                    //체크박스가 선택되어 있으면 아이디 저장
                    if(!empty($check_save_id)){
                        $cookie = array(
                            'name'=> 'save_id_cookie',
                            'value'  => $result['userid'],
                            'expire' => '3600'
                        );
                    }
                   
                    $this->input->set_cookie($cookie);         
                    redirect('/main');
                }else{ 
                    alert('아이디와 비밀번호를 확인 해주세요.', '/member/login');
                }
                
            }
        }
        else{
            
            $this->load->model("front/common_m");
            $this->load->library('user_agent');
            
            //현재 주소 가져오기
            $currentDomain =  $_SERVER['HTTP_HOST'];
            $currentUrl =  $_SERVER['REQUEST_URI'];

            $site['config'] = $this->common_m->get_site_config($currentUrl);

            if(!empty($site['config'] ->idsite)){
                $_idsite = $site['config']->idsite;
            }else if ($this->session->userdata('idsite') != null){
                $_idsite = $this->session->userdata('idsite');
            } else {
                show_404();
            }
            if(!empty($_idsite)){
                //pages 가져오기
                $data['pages'] = $this->common_m->get_pages($_idsite);
                
                //theme 가져오기
                $data['layout'] = $this->common_m->get_theme($_idsite);
            }else{
                $data['pages'] = $this->config->item('default_page');
                $data['layout'] = $this->config->item ('default_theme');
            }

            $data['auth'] = $this->member_m->get_user($this->session->userdata('idusers'));
            $this->load->model("front/common_m");
            $this->load->library('user_agent');
            
            //브라우저에 따라 pc&mobile 테마가져오기
            if ($this->agent->is_browser())
            {
                //상대경로가 없으면 기본 탬플릿 표시
                if(!empty($data['layout']->relativePath)){
                    $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/login/login';
                }else{
                    $mainPage ='/template/'.$data['layout']->template.'/login/login';
                }
                $this->load->view($mainPage, $data);
            }
            elseif ($this->agent->is_mobile())
            {
                if(!empty($data['layout']->relativePath)){
                    $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/login/login';
                }else{
                    $mainPage ='/template/'.$data['layout']->template.'/login/login';
                }
                //mobileTheme 가져오기
                $this->load->view($mainPage, $data);
            }
        }
    }
    function login_test(){
        $save_id_cookie = $this->input->cookie('save_id_cookie', TRUE);

        if(!empty($save_id_cookie)){
            $data['save_id_value'] = $save_id_cookie;
        }

        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($_idsite)){
            //pages 가져오기
            $data['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $data['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $data['pages'] = $this->config->item('default_page');
            $data['layout'] = $this->config->item ('default_theme');
        }

        $data['auth'] = $this->member_m->get_user($this->session->userdata('idusers'));
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/login/login-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/login/login-test.php';
            }
            $this->load->view($mainPage, $data);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($data['layout']->relativePath)){
                $mainPage ='/page/'.$data['layout']->relativePath.'/template/'.$data['layout']->template.'/login/login-test.php';
            }else{
                $mainPage ='/template/'.$data['layout']->template.'/login/login-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $data);
        }
    }
    
    function logout()
    {
        if ($this->session->userdata("idmanagers") == FALSE){
            back("관리자 페이지에선 지원하지 않는 기능입니다.");
        }

        if(@$this->session->userdata('logged_in') == FALSE)
        {
            alert('로그인이 되어 있지 않습니다.', '/member/login');
        }else{
            $_idsite = null;

            if ($this->session->userdata('idsite') != null){
                $_idsite = $this->session->userdata('idsite');
                $idsite = $_idsite;
            }
            $this->session->sess_destroy();

            if($_idsite != null) {
                $this->session->set_userdata('idsite', $_idsite);
            }
            
            if($idsite!= null){
                $this->session->set_userdata('idsite', $idsite);
                $data['layout'] = $this->common_m->get_theme($idsite);
                echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
                alert('로그아웃 되었습니다.', '/site/'.$data['layout']->relativePath);
                //echo $this->session->userdata('idsite');
                //exit;
            }
            
           
            /* echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
            alert('로그아웃 되었습니다.', '/main'); */
        }
    }
    
    function counseling(){
        //if(@$this->session->userdata('logged_in')!=true){
           // alert('로그인이 되어 있지 않습니다.', '/member/login');
            //redirect('/member/login', location);
        //}else{
            //폼 검증 라이브러리 로드
            $this->load->library('form_validation');
            
            //폼 검증할 필드와 규칙 사전 정의
            $this->form_validation->set_rules('name', '이름', 'required');
            $this->form_validation->set_rules('email', '이메일', 'required');
            $this->form_validation->set_rules('tel', '전화번호', 'required');
            $this->form_validation->set_rules('title', '제목', 'required');
            $this->form_validation->set_rules('content', '내용', 'required');
            
            //폼 검증이 정상적으로 완료되면
            if ($this->form_validation->run() == TRUE)
            {
                
                $name = $this->input->post('name', TRUE);
                $email = $this->input->post('email', TRUE);
                $tel = $this->input->post('tel', TRUE);
                $title = $this->input->post('title', TRUE);
                $content = $this->input->post('content', TRUE);
                
                $counseling_data = array(
                    'name' => $name,
                    'email' => $email,
                    'tel' => $tel,
                    'title' => $title,
                    'content' => $content
                );
                
                $result = $this->member_m->counseling($counseling_data);
                if($result){
                    alert('상담신청이 완료 되었습니다.' , '/main');
                }else{
                    alert('상담신청이 완료 되지 않았습니다.\n 잠시 후 다시 시도해주세요.' , '/member/counseling');
                }
            }
            else{
                
                $this->load->model("front/common_m");
                $this->load->library('user_agent');
                
                //현재 주소 가져오기
                $currentDomain =  $_SERVER['HTTP_HOST'];
                $currentUrl =  $_SERVER['REQUEST_URI'];
                
                $site['config'] = $this->common_m->get_site_config($currentUrl);
                
                if(!empty($site['config'] ->idsite)){
                    $_idsite = $site['config']->idsite;
                }else if ($this->session->userdata('idsite') != null){
                    $_idsite = $this->session->userdata('idsite');
                } else {
                    show_404();
                }
                if(!empty($_idsite)){
                    //pages 가져오기
                    $view['pages'] = $this->common_m->get_pages($_idsite);
                    
                    //theme 가져오기
                    $view['layout'] = $this->common_m->get_theme($_idsite);
                }else{
                    $view['pages'] = $this->config->item('default_page');
                    $view['layout'] = $this->config->item ('default_theme');
                }
                
                //브라우저에 따라 pc&mobile 테마가져오기
                if ($this->agent->is_browser())
                {
                    //상대경로가 없으면 기본 탬플릿 표시
                    if(!empty($view['layout']->relativePath)){
                        $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling';
                    }else{
                        $mainPage ='/template/'.$view['layout']->template.'/member/counseling';
                    }
                    $this->load->view($mainPage, $view);
                }
                elseif ($this->agent->is_mobile())
                {
                    if(!empty($view['layout']->relativePath)){
                        $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling';
                    }else{
                        $mainPage ='/template/'.$view['layout']->template.'/mobile/member/counseling';
                    }
                    //mobileTheme 가져오기
                    $this->load->view($mainPage, $view);
                }
            }
        //}
    }
    function counseling_test(){
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];

        $site['config'] = $this->common_m->get_site_config($currentUrl);

        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);

            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }

        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/member/counseling-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if(!empty($view['layout']->relativePath)){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/member/counseling-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/mobile/member/counseling-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }

    //idsite 가져오기
    function get_idsite($_currentUrl) {
        $this->load->model("front/common_m");
        if(empty($_currentUrl)){
            $_idsite = FALSE;
        }else{
            $site['config'] = $this->common_m->get_site_config($_currentUrl);
            if(!empty($site['config'] ->idsite)){
                $_idsite = $site['config']->idsite;
            }else if ($this->session->userdata('idsite') != null){
                $_idsite = $this->session->userdata('idsite');
            }
        }
        return $_idsite;
    }

    // 테스트 페이지 적용하기
    function set_modify_theme(){
        $this->load->helper("alert");
        $_relative_path = $this->input->post("_relative_path", TRUE);
        $_current_url = $this->input->post("_current_url", TRUE);
        
        $_templeate = $this->input->post('_templeate', TRUE);
        $_segment = $this->input->post('_segment', TRUE);
        $_file = $this->input->post('_file', TRUE);
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', FALSE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', FALSE);

        $o_data = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$_file;
        $c_data = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$_file;

//        dd($o_data);
//        exit;

        //print_r($o_content);
        //print_r($c_content);

        //파일 일기
        $o_content = explode('|',  $o_content);
        $c_content = explode('|',  $c_content);

        //print_r($o_data);
        //print_r($c_content);
        //exit;
        //파일이 있는지 확인
        if(is_file($o_data)){

            //파일 읽기
            $rp = file_get_contents($o_data);

            //읽은 파일에 내용 확인
            for($i=0;$i < count($o_content);$i++){

                //변경할 내용으로 치환하기
                $rp  = str_replace($o_content[$i], $c_content[$i], $rp);

                file_put_contents($o_data, $rp);

                if(!file_put_contents($o_data, $rp)){
                    alert('파일이 정상적으로 수정되지 않았습니다.', $_current_url);
                }
            }


        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', $_current_url);
        }
//        exit;
        alert('파일이 정상적으로 수정되었습니다.', $_current_url);
    }
    
    /*function auto_login_proc(){
        //쿠키값 가져오기
        $mb_id = $this->cookie_id;
        $result = $this->member_m->get_user_member($mb_id);
        
    }*/
}

/* End of file counseling.php */
/* Location: ./application/controllers/counseling.php */ 