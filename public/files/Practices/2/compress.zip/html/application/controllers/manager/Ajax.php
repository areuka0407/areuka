<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajax extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this -> load -> helper('alert');
        $this->load->model('front/common_m');
        $this->load->helper(array('form', 'date', 'url'));

    }

    public function index()
    {
        $this->imgupload();
    }

    function imgupload(){
        $this->load->model("front/common_m");
        $upload_path = $this->input->post('_path', TRUE);
        $this->load->library('upload');
        //echo $_path;
        //exit;
       //$filesCount = count($_FILES['userfile']['name']);
        $config = Array(
            'upload_path' 	=>  ".".$upload_path,
            'allowed_types' => 'gif|jpg|png',
            'encrypt_name' => TRUE,
            'max_size' 	=> '5120',
        );
         
        //이미지 초기화
        $this->upload->initialize($config);
        
        //이미지확인
        if (!$this->upload->do_upload("upfile"))
        {
           echo  $this->upload->display_errors();
           exit;
        }else{
            $upload_data =$this->upload->data();          
            $image = $upload_data['file_name'];
            
            echo  $this->upload->data('file_name');
            exit;
        } 
       /*if($upload_data['image_width'] > 300)
       { 
            $config['image_library'] = 'gd2';
            $config['source_image'] = $upload_data['full_path'];
            $config['create_thumb'] = TRUE;
            $config['maintain_ratio'] = TRUE;
            $config['width'] = 300;
            $config['height'] = 300;
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
        }*/ 
           
    } 
} 

/* End of file counseling.php */
/* Location: ./application/controllers/counseling.php */