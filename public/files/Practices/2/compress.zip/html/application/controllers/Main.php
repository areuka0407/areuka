<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('date', 'url'));
        $this->load->helper('file');
        $this->load->library('user_agent');
        $this->load->helper('directory');
        $this->load-> helper('alert');
        if($this->session->userdata('logged_in') == FALSE) {
            redirect('/member/login');
        }
    }
    
    public function index()
    {
        $this->main();
    }
    
    public function main()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }

        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, 'A');
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/main/main';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
        
        
    }
    
    
    
    public function b_main()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        $_idsite = 2;
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        //print_r($view['simposiumLatestPosts']);
        //exit;
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, 'B');
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main';
            }else{
                $mainPage ='/template/B/main/main';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/main/main';
            }else{
                $mainPage ='/template/B/mobile/main/main';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }

    }
    public function c_main()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
       
        $_idsite = 3;
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, 'C');
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main';
            }else{
                $mainPage ='/template/C/main/main';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/main/main';
            }else{
                $mainPage ='/template/C/mobile/main/main';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
        
    }
    public function d_main()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        /*if(!empty($site['config'] ->idsite)){
         $_idsite = $site['config']->idsite;
         }else{
         //기본 탬플릿 번호
         $_idsite = $this->config->item('default_idsite');
         }*/
        $_idsite = 4;
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
               // $this->set_theme($view['layout']->relativePath, 'D');
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main';
            }else{
                $mainPage ='/template/D/main/main';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/main/main';
            }else{
                $mainPage ='/template/D/mobile/main/main';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
        
    }

    public function test()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, $view['layout']->template);
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main-test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main-test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/main-test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    
    
    
    public function test2()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');
        
        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        
        if(!empty($_idsite)){
            //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기
            $view['layout'] = $this->common_m->get_theme($_idsite);
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
        
        //공지사항 최신글
        $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
        $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
        $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);
        
        
        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                //$this->set_theme($view['layout']->relativePath, $view['layout']->template);
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/test.php';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/test.php';
            }else{
                $mainPage ='/template/'.$view['layout']->template.'/main/test.php';
            }
            //mobileTheme 가져오기
            $this->load->view($mainPage, $view);
        }
    }
    
    //공지사항 최신글 가져오기
    public function noticeLatestPosts($_idsite)
    {
        $this->load->model("front/board_m");
        $result = $this->board_m->noticeLatestPosts($_idsite);
        return $result;
        
    }
    public function replayLatestPosts($_idsite)
    {
        $this->load->model("front/replay_m");
        $result = $this->replay_m->replayLatestPosts($_idsite);
        $week_num = nice_date($result[0]->regDate, 'w');
        if ($week_num == 0) {
            $result[0]->regWeek = '일';
        } else if ($week_num == 1) {
            $result[0]->regWeek = '월';
        } else if ($week_num == 2) {
            $result[0]->regWeek = '화';
        } else if ($week_num == 3) {
            $result[0]->regWeek = '수';
        } else if ($week_num == 4) {
            $result[0]->regWeek = '목';
        } else if ($week_num == 5) {
            $result[0]->regWeek = '금';
        } else if ($week_num == 6) {
            $result[0]->regWeek = '토';
        }
        return $result;
        
    }
    
    public function simposiumLatestPosts($_idsite)
    {
        $this->load->model("front/schedule_m");
        $result = $this->schedule_m->simposiumLatestPosts($_idsite);
        $week_num = nice_date($result[0]->regDate, 'w');
        if ($week_num == 0) {
            $result[0]->regWeek = '일';
        } else if ($week_num == 1) {
            $result[0]->regWeek = '월';
        } else if ($week_num == 2) {
            $result[0]->regWeek = '화';
        } else if ($week_num == 3) {
            $result[0]->regWeek = '수';
        } else if ($week_num == 4) {
            $result[0]->regWeek = '목';
        } else if ($week_num == 5) {
            $result[0]->regWeek = '금';
        } else if ($week_num == 6) {
            $result[0]->regWeek = '토';
        }
        return $result;  
    }
    
    function set_theme($_relativePath, $_templeate){
        
        /**
         *
         *
         * @$_relativePath (상대경로)
         * @$_templeat(탬플릿)
         *
         *
         */
        
        
        //탬플릿 원본
        $o_templeate = APPPATH .'views/template/'.$_templeate.'/';
        //탬플릿 복사 위치
        $c_templeate = APPPATH.'views/page/'.$_relativePath.'/template/'.$_templeate."/";
        
        if(is_dir($c_templeat) == false){
            //디렉터리
            mkdir($c_templeate, 0777, true);
            //탬플릿 복사(파일)
            $dirMap = directory_map($o_templeate, 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = $o_templeat.$dm;
                
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$_relativePath.'/template/'.$_templeate."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
    }
    //디렉터리와 파일 복사
    function copy_directory($src_dir, $dest_dir)
    {
        if($src_dir == $dest_dir)
            return false;
            if(!is_dir($src_dir))
                return false;
                if(!is_dir($dest_dir)) {
                    @mkdir($dest_dir, 0707);
                    @chmod($dest_dir, 0707);
                }
                $dir = opendir($src_dir);
                while (false !== ($filename = readdir($dir))) {
                    if($filename == "." || $filename == "..")
                        continue;
                        $files[] = $filename;
                }
                for($i=0; $i<count($files); $i++) {
                    $src_file = $src_dir.'/'.$files[$i];
                    $dest_file = $dest_dir.'/'.$files[$i];
                    if(is_file($src_file)) {
                        copy($src_file, $dest_file);
                        @chmod($dest_file, 0606);
                    }
                }
    }


    // 테스트 페이지 적용하기
    function set_modify_theme(){
        $this->load->helper("alert");
        
        $_relative_path = $this->input->post("_relative_path", TRUE);
        $_current_url = $this->input->post("_current_url", TRUE);
        
        $_templeate = $this->input->post('_templeate', TRUE);
        $_segment = $this->input->post('_segment', TRUE);
        $_file = $this->input->post('_file', TRUE);
        //원본 컨텐츠
        $o_content = $this->input->post('o_content', FALSE);
        //수정 컨텐츠
        $c_content = $this->input->post('c_content', FALSE);
        
        $o_data = APPPATH.'views/page/'.$_relative_path.'/template/'.$_templeate.'/'.$_segment.'/'.$_file;
        $c_data = APPPATH.'views/page/'.$_relative_path.'/template/'.$_templeate.'/'.$_segment.'/'.$_file;

         
        //print_r($o_content);
        //print_r($c_content);
        
        //파일 일기
        $o_content = explode('|',  $o_content);
        $c_content = explode('|',  $c_content);
        
        //print_r($o_data);
        //print_r($c_content);
        //exit;
        //파일이 있는지 확인
        if(is_file($o_data)){
            
            //파일 읽기
            $rp = file_get_contents($o_data);
            
            //읽은 파일에 내용 확인
            for($i=0;$i < count($o_content);$i++){
                
                //변경할 내용으로 치환하기
                $rp  = str_replace($o_content[$i], $c_content[$i], $rp);
                
                file_put_contents($o_data, $rp);
                
                if(!file_put_contents($o_data, $rp)){
                   alert('파일이 정상적으로 수정되지 않았습니다.', $_current_url);
                }
            }
            
            
        }else{
            alert('탬플릿 파일을 찾지 못했습니다.', $_current_url);
        }


        alert('파일이 정상적으로 수정되었습니다.', $_current_url);
    }
    // 원본 페이지 적용하기
    function set_modify_original(){
        $_current_url = $this->input->post("_current_url", TRUE); // 요청을 보낸 페이지의 URL
        $_templeate = $this->input->post('_templeate', TRUE); // 템플릿 명
        $_segment = $this->input->post('_segment', TRUE); // View의 폴더명 (세그먼트)
        $test_file = $this->input->post('_file', TRUE); // Test 페이지의 파일명

        $pos = mb_strpos($test_file, "-test.php");
        $real_file = mb_substr($test_file, 0, $pos). ".php"; // 원본 페이지 파일명

        $test_path = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$test_file; // 테스트 페이지 경로
        $real_path = APPPATH.'views/page/theme_test/template/'.$_templeate.'/'.$_segment.'/'.$real_file; // 원본 페이지 경로

        if (is_file($test_path) && is_file($real_path)){ // 두 경로에 파일이 모두 존재하면
            $t_data = file_get_contents($test_path); // 테스트 파일을 가져와서

            // <div id="wrap-off"> </div>  이 사이에만 가능하도록 적용시켜야함.

            preg_match("/<div id=\"wrap_off\">(.|\\s|\\n)+<\\/div>/", $t_data, $matches);
            dd($matches);

            exit;

            if (!file_put_contents($real_path, $t_data)){
                alert("원본 페이지에 적용하는 데에 실패했습니다.", $_current_url);
            }
        } else {
            alert("해당 페이지의 경로를 찾을 수 없습니다.", $_current_url);
        }

        alert("원본 페이지에 적용되었습니다.", $_current_url);
    }
}


 


/* End of file main.php */
/* Location: ./application/controllers/main.php */