<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Main extends CI_Controller {
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('date', 'url'));
        //$this->load->helper('file');
        $this->load->helper('directory');
        $this->load->library('user_agent');
    }  

    public function index()
    {
        $this->main();
    }


    public function main()
    {
        $this->load->model("front/common_m");
        $this->load->library('user_agent');

        //현재 주소 가져오기
        $currentDomain =  $_SERVER['HTTP_HOST'];
        $currentUrl =  $_SERVER['REQUEST_URI'];
        
        $site['config'] = $this->common_m->get_site_config($currentUrl);
        
        if(!empty($site['config'] ->idsite)){
            $_idsite = $site['config']->idsite;
        }else if ($this->session->userdata('idsite') != null){
            $_idsite = $this->session->userdata('idsite');
        } else {
            show_404();
        }
        if(!empty($_idsite)){
             //pages 가져오기
            $view['pages'] = $this->common_m->get_pages($_idsite);
            
            //theme 가져오기  
            $view['layout'] = $this->common_m->get_theme($_idsite);  
        }else{
            $view['pages'] = $this->config->item('default_page');
            $view['layout'] = $this->config->item ('default_theme');
        }
       
         //공지사항 최신글
         $view['simposiumLatestPosts'] = $this-> simposiumLatestPosts($_idsite);
         $view['noticeLatestPosts'] = $this-> noticeLatestPosts($_idsite);
         $view['replayLatestPosts'] = $this-> replayLatestPosts($_idsite);


        //브라우저에 따라 pc&mobile 테마가져오기
        if ($this->agent->is_browser())
        {
            //상대경로가 없으면 기본 탬플릿 표시
            if($view['layout']->relativePath){
                $this->set_theme($view['layout']->relativePath, 'B');
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/main/main';
            }else{
                $mainPage ='/template/A/main/main';
            }
            $this->load->view($mainPage, $view);
        }
        elseif ($this->agent->is_mobile())
        {
            if($view['layout']->relativePath){
                $mainPage ='/page/'.$view['layout']->relativePath.'/template/'.$view['layout']->template.'/mobile/main/main';
            }else{
                $mainPage ='/template/A/mobile/main/main';
            }
            //mobileTheme 가져오기  
            $this->load->view($mainPage, $view); 
        }
        
          
    }

    //공지사항 최신글 가져오기
    public function noticeLatestPosts($_idsite)
    {
        $this->load->model("front/board_m");
        $result = $this->board_m->noticeLatestPosts($_idsite);
        return $result;
          
    }
    public function replayLatestPosts($_idsite)
    {
        $this->load->model("front/replay_m");
        $result = $this->replay_m->replayLatestPosts($_idsite);
        return $result;
          
    } 
    
    public function simposiumLatestPosts($_idsite)
    {
        $this->load->model("front/schedule_m");
        $result = $this->schedule_m->simposiumLatestPosts($_idsite);
        return $result;
          
    }

    function set_theme($_relativePath, $_templeat){

        /**
         * 
         * 
         * @$_relativePath (상대경로)
         * @$_templeat(탬플릿)
         * 
         * 
         */
        

        //탬플릿 원본
        $o_templeat = APPPATH .'views/template/'.$_templeat.'/';
        //탬플릿 복사 위치
        $c_templeat = APPPATH.'views/page/'.$_templeat;
        
        if(is_dir($c_templeat) == false){
            //디렉터리  
            mkdir($c_templeat, 0777, true);
            //탬플릿 복사(파일)
            $dirMap = directory_map($o_templeat, 1);
            
            //디렉터리 복사
            foreach($dirMap as $dm){
                //원본 탬플릿
                $src_dir = $o_templeat.$dm;
                 
                //복사될 탬플릿 위치
                $dest_dir = APPPATH.'views/page/'.$_relativePath.'/template/'.$_templeat."/".$dm;
                $this->copy_directory($src_dir, $dest_dir);
            }
        }
    } 


    //디렉터리와 파일 복사
    function copy_directory($src_dir, $dest_dir)
    {
        if($src_dir == $dest_dir)
            return false;
        if(!is_dir($src_dir))
            return false;
        if(!is_dir($dest_dir)) {
            @mkdir($dest_dir, 0707);
            @chmod($dest_dir, 0707);
        }
        $dir = opendir($src_dir);
        while (false !== ($filename = readdir($dir))) {
            if($filename == "." || $filename == "..")
                continue;
            $files[] = $filename;
        }
        for($i=0; $i<count($files); $i++) {
            $src_file = $src_dir.'/'.$files[$i];
            $dest_file = $dest_dir.'/'.$files[$i];
            if(is_file($src_file)) {
                copy($src_file, $dest_file);
                @chmod($dest_file, 0606);
            }
        }
    }
}

/* End of file main.php */
/* Location: ./application/controllers/main.php */