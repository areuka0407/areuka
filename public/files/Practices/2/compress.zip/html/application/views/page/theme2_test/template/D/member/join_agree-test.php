<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php  //if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php  // } ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">
	</style>
</head>
<body>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">본문 바로가기</a>
		<a href="#">네비게이션 바로가기</a>
	</div>
	<!--header-->
	<div id="header">
		<div class="top_img"></div>
		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/177370c3035ca127487c6e3f88d9d1b0.png" alt="INTOON (주)인투온" /></a></h1>
			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->
				<!--tm-->
				<div id="tm">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">회원정보 수정</a></li>
						<?php } ?>
						<li><a href="/board">공지사항</a></li>
						<li><a href="/member/counseling">상담문의</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">로그아웃</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">로그인</a></li>
						<?php } ?>
					</ul>
				</div>
				<!--tm-->
			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->
	<div class="menu_bg"></div>
	<!--//header-->
	<!--container-->
	<div id="container">
		<!--    	<h2>회원가입</h2>-->
		<!--wrap-->
		<div class="wrap">
			<h3 class="generalBasic" id="data-idx2">회원가입</h3>
			<p>Join Membership</p>
			<ol>
				<li><a href="/main">Symposium Home</a></li>
				<li><a href="/member/join_agree">회원가입</a></li>
			</ol>
			<!--w_box-->
			<div class="top_supis"></div>

			<div class="w_box">
				<!--member-->
				<div class="member">
					<h4 class="generalBasic" id="data-idx3">이용약관 및 개인정보이용에 대한 동의</h4>
					<div class="agree_box generalBasic" id="data-idx4">
						1) 수집하는 개인정보의 항목<br />
						<br />
						귀하로부터 아이디, 이름, 분과, 핸드폰 번호, 병원명, 과명을 제공받습니다.<br />
						<br />
						2) 수집 및 이용의 목적	<br />
						<br />
						제공하신 정보는 [제약사명](이하”회사”)가 주최하는 본 symposium(“본 심포지엄”)의 진행을 위하여 수집, 이용되며 나아가 온라인 및 오프라인 제품설명회(“제품설명회”)에 대한 초청 및 기타 회사가 제공하는 마케팅 프로그램의 알림 서비스 제공 등 기타 회사의 의,약학적 학술활동 및 마케팅 활동의 수행을 위해 수집 이용됩니다.<br />
						<br />
						3) 정보의 활용 및 보안<br />
						<br />
						귀하의 사전 허락 없이 개인정보를 제3자에게 제공하지 않습니다. 다만, 회사가 주최하는 제품설명회에 대한 초청장 발송 등 행사의 원활한 진행과 관련된 업무, 제공하는 마케팅 프로그램의 알림서비스 제공 등과 관련된 업무를 (주)인투온에 위탁하고 있음을 알려 드립니다.<br />
						<br />
						4) 보유 및 이용기간<br />
						<br />
						관계 법령의 규정에 따라 귀하의 개인정보를 보존할 의무가 있는 경우가 아닌 한, 회사는 위 제1항에 규정된 수집 및 이용목적을 달성할 때까지 귀하의 개인정보를 보유 및 이용합니다. 귀하는 위와 같은 개인정보의 수집 및 이용을 거부할 수 있습니다. 다만, 제1항에 규정한 정보를 제공하지 않으실 경우 본 심포지엄의 참석이 제한되오며, 향후 제품설명회에 대한 초청장 발송 및 마케팅 프로그램에 대한 안내 문자 등이 발송되지 않음을 알려드립니다.
					</div>
					<div class="agree_check check"><input type="checkbox" id="cb_agree" /><label for="cb_agree">개인정보의 수집 및 이용에 관한 설명을 모두 이해하고, 이에 동의합니다.</label></div>
					<p class="tc"><a href="#" class="bt_txt bt_bot">회원가입</a></p>
				</div>
				<!--//member-->

			</div>
			<!--//w_box-->
		</div>
		<!--//wrap-->
	</div>
	<!--//container-->
	<!--footer-->
	<div id="footer">
		<!--wrap-->
		<div class="foot_top">
			<h3 class="generalBasic" id="data-idx5">Symposium</h3>
			<p class="generalBasic" id="data-idx6">이제는 심포지엄 인터넷으로 참여하는 시대 인투온을 통해 편리하게 소통하세요</p>
		</div>
		<div class="wrap">
			<div class="logo"><a href="/main"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
			<div class="info">
				<dl>
					<dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
					<dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
				</dl>
				<dl>
					<dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
					<dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
				</dl>
			</div>
			<div class="code generalBasic" id="data-idx27">GCMA COME : PP-PNA-ABT-0056</div>
		</div>
		<!--//wrap-->
	</div>
	<!--//footer-->
</div>
<script>
	$(document).ready(function(){
		$('.bt_bot').on('click', function(){
			if(!$('#cb_agree').is(":checked")){
				alert('회원가입약관에 관한 동의를 해주세요');
				$('#cb_agree').focus();
				return false;
			}else{
				location.href="/member/join";
			}
		});
	});
</script>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">테스트 페이지 적용</button>
	<button class="real-save">원본 페이지 적용</button>
</form>
<?php  $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
