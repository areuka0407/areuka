<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php  if(@$this->session->userdata('idmanagers')!=''){?>
    <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
    <?php } ?>
    <script type="text/javascript" src="<?php echo JS_DIR?>js/member.js"></script>
    <script type="text/javascript">

    </script>
    <style type="text/css">

    </style>
    <!--[if IE 9]>
        <script src="<?php echo JS_DIR.$layout->template?>/js/main_ie9.js"></script>
        <link rel="stylesheet" href="<?php echo CSS_DIR.$layout->template?>/css/style_ie9.css">
    <![endif]-->
</head>

<body>
    <div id="wrap">
        <div class="skip_nav">
            <a href="#">본문 바로가기</a>
            <a href="#">네비게이션 바로가기</a>
        </div>
        <div class="top_img"></div>
        <!--header-->
        <div id="header">

            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalBasic" id="data-idx1" src="<?php echo JS_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></h1>

                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!---->

                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <li class="hidden_m"><a href="#none">menu</a></li>
                            <!---->
                            <?php foreach($pages as $pg){?>
                            <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                        	<?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->

                    <!--tm_m-->
                    <div id="tm_m">
                        <ul>
                        <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/modify">회원정보 수정</a></li>
                        <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                            <li><a href="/member/login">로그인</a></li>
                        <?php } ?> 
                        </ul>

                        <div class="logo_h">
                            <!---->
                            <img class="generalImg" id="data-idx2" src="<?php echo JS_DIR.$layout->template?>/images/logo_h.png" alt="" />
                            <!---->
                        </div>

                    </div>
                    <!--//tm_m-->

                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <!--//header-->

        <div class="menu_bg"></div>
        <!---->

        <!--container-->
        <div id="container">
            <!--    	<h2>회원가입</h2>-->
            <div class="contents_inner">
                <!--tm-->
                <div id="tm">
                    <ul>
                       <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/modify">회원정보 수정</a></li>
                        <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                            <li><a href="/member/login">로그인</a></li>
                        <?php } ?> 
                    </ul>

                    <div class="logo_h">
                        <!---->
                        <img  class="generalImg" id="data-idx3" src="<?php echo JS_DIR.$layout->template?>images/logo_h.png" alt="" />
                        <!---->
                    </div>

                </div>
                <!--tm-->


                <div class="wrap_bg">
                    <div class="bg_inner">
                        <h3 class="generalBasic" id="data-idx4">회원가입</h3>
                        <!--        	    <h3 class="colortit"> 소개</h3>-->
                        <span class="generalBasic" id="data-idx5">Join Membership</span>
                    </div>
                </div>

                <!--wrap-->
                <div class="wrap">
                    <!--w_box-->
                    <form name="joinForm" id="joinForm" action="/member/join" method="post">            		
                    <div class="w_box2">
                        <!--member-->                       
                        <div class="member">
                            <div class="agree_tit2">
                                <h4 class="tc mb10 generalBasic" id="data-idx6">회원가입 입력</h4>
                                <p class="must"><i>＊</i> 필수 입력항목 입니다.</p>
                            </div>
                            <div class="agree_">
                                <div class="form">
                                    <dl>
                                        <dt><i>＊</i>아이디</dt>
                                        <dd><input type="text" name="userid" id="userid" placeholder="아이디를 입력해주세요." /></dd>
                                    </dl>
                                    <dl>
                                        <dt><i>＊</i>비밀번호</dt>
                                        <dd><input type="password" name="password" id="password" placeholder="비밀번호를 4글자 이상으로 정해주세요." /></dd>
                                    </dl>
                                    <dl>
                                        <dt><i>＊</i>비밀번호 확인</dt>
                                        <dd><input type="password" name="repassword" id="repassword" placeholder="입력하신 비밀번호를 다시한번 입력해주세요." /></dd>
                                    </dl>
                                    <dl>
                                        <dt><i>＊</i>이메일</dt>
                                        <dd><input type="text" name="email" id="email" placeholder="이메일을 입력해주세요." /></dd>
                                    </dl>
                                    <dl>
                                        <dt><i>＊</i>이름</dt>
                                        <dd class="name"><input type="text" name="firstname" id="firstname" placeholder="성" /><input type="text" name="lastname" id="lastname" placeholder="이름" /></dd>
                                    </dl>
                                    <dl>
                                        <dt><i>＊</i>핸드폰 번호</dt>
                                        <dd><input type="text" name="phone" id="phone" placeholder="" /></dd>
                                    </dl>
                                    <dl>
                                        <dt>병원명</dt>
                                        <dd><input type="text" name="hospital" id="hospital" placeholder="" /></dd>
                                    </dl>
                                    <dl>
                                        <dt>과명</dt>
                                        <dd><input type="text" name="course" id="course" placeholder="" /></dd>
                                    </dl>
                                    <dl>
                                        <dt>영업담당</dt>
                                        <dd><input type="text" name="salesofficer" id="salesofficer" placeholder="" /></dd>
                                    </dl>
                                    <dl>
                                        <dt>영업담당조직</dt>
                                        <dd><input type="text" name="salesgroup" id="salesgroup" placeholder="" /></dd>
                                    </dl>
                                </div>
                                <p class="tc"><a href="#" class="bt_txt bt_bot">회원가입</a></p>
                            </div>
                        </div>
                        <!--//member-->

                    </div>
                    </form>
                    <!--//w_box-->
                </div>
                <!--//wrap-->

                <!--footer-->
                <div id="footer">
                    <!--wrap-->
                    <div class="wrap">
                        <div class="logo"><a href="/main"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></div>
                        <div class="info">
                            <dl>
                                <dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
                                <dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                            </dl>
                            <dl>
                                <dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
                                <dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                            </dl>
                        </div>
                    </div>
                    <!--//wrap-->
                    <div class="code generalBasic" id="data-idx13">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
                <!--//footer-->
				<?php  if(@$this->session->userdata('idmanagers')!='') : ?>
					<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
						<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
						<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
						<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
						<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
						<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
						<input type="hidden" name="o_content" id="o_content" value="" />
						<input type="hidden" name="c_content" id="c_content" value="" />
						<button class="test-save" type="submit">테스트 페이지 적용</button>
						<button class="real-save">원본 페이지 적용</button>
					</form>
					<?php
					$this->load->view("/manager/config/configPopUp");
				endif;
				?>
            </div>
            <!--//contents_inner-->
        </div>
        <!--//container-->
    </div>
</body>

</html>
