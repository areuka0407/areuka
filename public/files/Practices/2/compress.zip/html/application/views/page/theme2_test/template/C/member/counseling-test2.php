<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php // if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php //} ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">

	</style>
	<!--[if IE 9]>
	<script src="<?php echo JS_DIR.$layout->template?>/js/main_ie9.js"></script>
	<link rel="stylesheet" href="<?php echo CSS_DIR.$layout->template?>/css/style_ie9.css">
	<![endif]-->
</head>

<body>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">본문 바로가기</a>
		<a href="#">네비게이션 바로가기</a>
	</div>
	<div class="top_img"></div>
	<!--header-->
	<div id="header">

		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/d791c784f89a52547b285e79547d5c98.png" alt="INTOON (주)인투온" /></a></h1>

			<a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
			<!---->

			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<li class="hidden_m"><a href="#none">menu</a></li>
						<!---->
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->

				<!--tm_m-->
				<div id="tm_m">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">회원정보 수정</a></li>
						<?php } ?>
						<li><a href="/board">공지사항</a></li>
						<li><a href="/member/counseling">상담문의</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">로그아웃</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">로그인</a></li>
						<?php } ?>
					</ul>

					<div class="logo_h">
						<!---->
						<img class="generalImg" id="data-idx2" src="<?php echo IMG_DIR.$layout->template?>/images/logo_h.png" alt="" />
						<!---->
					</div>

				</div>
				<!--//tm_m-->

			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->

	<div class="menu_bg"></div>
	<!---->

	<!--container-->
	<div id="container">
		<!--    	<h2>상담문의</h2>-->
		<div class="contents_inner">
			<!--tm-->
			<div id="tm">
				<ul>
					<?php if(@$this->session->userdata('logged_in')==true){?>
						<li><a href="/member/modify">회원정보 수정</a></li>
					<?php } ?>
					<li><a href="/board">공지사항</a></li>
					<li><a href="/member/counseling">상담문의</a></li>
					<?php if(@$this->session->userdata('logged_in')==true){?>
						<li><a href="/member/logout">로그아웃</a></li>
					<?php }else{ ?>
						<li><a href="/member/login">로그인</a></li>
					<?php } ?>
				</ul>

				<div class="logo_h">
					<!---->
					<img  class="generalImg" id="data-idx3" src="<?php echo IMG_DIR.$layout->template?>/images/logo_h.png" alt="" />
					<!---->
				</div>

			</div>
			<!--tm-->

			<div class="wrap_bg">
				<div class="bg_inner">
					<h3 class="generalBasic" id="data-idx4">심포지엄 상담문의</h3>
					<!--        	    <h3 class="colortit"> 소개</h3>-->
					<span class="generalBasic" id="data-idx5">Customer center</span>
				</div>
			</div>

			<!--wrap-->
			<div class="wrap">
				<div class="w_box2">
					<!--member-->
					<form name="counseling" id="counselingForm" method="post">
						<div class="member">
							<div class="agree_tit2">
								<h4 class="tc mb10 generalBasic" id="data-idx6">상담문의 내용 입력</h4>
								<p class="must"><i>＊</i> 필수 입력항목 입니다.</p>
							</div>
							<div class="agree_">
								<div class="form">
									<dl>
										<dt class="cus"><span class="spa"><i>＊</i>성함</span></dt>
										<dd class="mdt30">
											<input class="idcon1" type="text" name="name" id="name" placeholder="" value="<?php echo @$this->session->userdata('name')? $this->session->userdata('name'): '';?>"/>
										</dd>
									</dl>

									<dl>
										<dt class="cus"><span class="spa"><i>＊</i>이메일</span></dt>
										<dd class="mdt30">
											<input class="idcon4" type="text" name="email" id="email" placeholder="" value="<?php echo @$this->session->userdata('email')? $this->session->userdata('email'): '';?>"/>
										</dd>
									</dl>

									<dl>
										<dt class="cus"><span class="spa"><i>＊</i>전화번호</span></dt>
										<dd class="mdt30 idcon5"><input class="idcon5" type="text" name="tel" id="tel" placeholder="" value="<?php echo @$this->session->userdata('phone')? $this->session->userdata('phone'): '';?>"/></dd>
									</dl>

									<dl>
										<dt class="cus"><span class="spa"><i>＊</i>제목</span></dt>
										<dd class="mdt30"><input type="text"  name="title" id="title" placeholder="" /></dd>
									</dl>

									<dl>
										<dt class="cus"><span class="spa"><i>＊</i>내용</span></dt>
										<dd class="mdt30"><textarea  name="content" id="content" placeholder=""></textarea></dd>
									</dl>
								</div>
								<p class="tc"><a href="#" class="bt_txt bt_bot">상담하기</a></p>
							</div>
						</div>
						<!--//member-->
					</form>
				</div>
				<!--//w_box-->
			</div>
			<!--//wrap-->



			<!--footer-->
			<div id="footer">
				<!--wrap-->
				<!--
                <div class="foot_top">
                    <div class="f_top_inner">
                        <ul>
                            <li>
                                <a href="#" class="f_top_tit">접속테스트</a>
                                <p>원활한 심포지엄 접속을 위해 방화벽 테스트, 인터넷 속도 테스트, 플래시 플레이어 버전 테스트 등을 진행합니다.</p>
                                <a href="#self" class="bt_go2">확인하기</a>
                            </li>
                            <li>
                                <a href="#" class="f_top_tit">모바일 접속안내</a>
                                <p>클릭하시면 모바일 접속 방법을 자세히 확인 하실 수 있습니다.</p>
                                <a href="#self" class="bt_go2">확인하기</a>
                            </li>
                        </ul>
                    </div>
                </div>
-->
				<div class="wrap">
					<div class="logo"><a href="/main"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></div>
					<div class="info">
						<dl>
							<dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
							<dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
						</dl>
						<dl>
							<dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
							<dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
						</dl>
					</div>
				</div>
				<!--//wrap-->
				<div class="code generalBasic" id="data-idx13">GCMA COME : PP-PNA-ABT-0056</div>
			</div>
			<script>
				$(document).ready(function(){
					$('.bt_bot').on('click', function(){
						if($('#name').val()==""){
							alert('이름을 입력해주세요.');
							$('#name').focus();
							return false;
						}else if($('#email').val()==""){
							alert('이메일을 입력해주세요.');
							$('#email').focus();
							return false;
						}else if($('#tel').val()==""){
							alert('전화번호를 입력해주세요.');
							$('#tel').focus();
							return false;
						}else if($('#title').val()==""){
							alert('제목를 입력해주세요.');
							$('#title').focus();
							return false;
						}else if($('#content').val()==""){
							alert('내용을 입력해주세요.');
							$('#content').focus();
							return false;
						}else{
							$('#counselingForm').submit();
						}
					});
				});
			</script>
			<!--//footer-->
		</div>
	</div>
	<!--//contents_inner-->
</div>
<!--//container-->
<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">테스트 페이지 적용</button>
	<button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>

</body>

</html>
