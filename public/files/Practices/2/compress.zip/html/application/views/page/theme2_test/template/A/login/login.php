<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
<title><?php echo $layout->name?></title>
<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
<?php  if(@$this->session->userdata('idmanagers')!=''){?>
<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
<style type="text/css">
#layerPopup{
  padding:20px; 
  border:4px solid #ddd; 
  position:absolute; 
  left:100px; 
  top:100px; 
  background:#fff;
}

#layerPopup button{
  cursor:pointer;
} 
.generalImg, .generalText, .generalBasic{
    cursor:pointer;
}
</style>
<?php } ?>
</head>
<body>
<div id="wrap_off">
<div id="wrap"> 
    <!--header-->
    <div id="header"> 
        <!--wrap-->
        <div class="wrap">
            <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
            <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
           <!--menu-->
           <div id="menu">
                <!--gnb-->
                <div id="gnb">
                    <ul>
                        <?php foreach($pages as $pg){?>
                            <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
                <!--//gnb-->
                <!--tm-->
                <div id="tm">
                    <ul>
                    <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/modify">회원정보 수정</a></li>
                    <?php } ?>
                        <li><a href="/board">공지사항</a></li>
                        <li><a href="/member/counseling">상담문의</a></li>
                        <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/logout">로그아웃</a></li>
                        <?php }else{ ?>
                        <li><a href="/member/login">로그인</a></li>
                    <?php } ?>
                    </ul>
                </div>
                <!--tm--> 
            </div>
            <!--//menu-->
        </div>
        <!--//wrap--> 
    </div>
    <div class="menu_bg"></div>
    <!--//header--> 
    <!--login-->
    <div class="login"> 
        <!--wrap-->
        <div class="wrap">       
        	<div class="login_box">
                <form name="loginForm" id="loginForm" method="post">                
            	<h2 class="generalBasic" id="data-idx2">로그인</h2>
                <div class="form">
                	<input type="text" name="userid" id="userid" value="<?php echo !empty($save_id_value) ? $save_id_value: '' ?>" placeholder="아이디" />
                    <input type="password" name="password" id="password" placeholder="비밀번호" />  
                    <p class="security">
                        <input id="member_check_save_id" name="check_save_id" id="check_save_id" value="chech_save_id" type="checkbox" <?php echo !empty($save_id_value) ? 'checked': '' ?>>
                        <label for="member_check_save_id">로그인 정보 기억하기</label>
                    </p>             
                </div>
                <a href="#" class="bt_txt bt_login">로그인</a>
                <div class="btns"><a href="/member/join_agree">회원가입</a>|<a href="#self">비밀번호 찾기</a></div>
            </div>
            <div class="guide_box">
            	<h2 class="generalBasic" id="data-idx3">이용안내</h2>
                <p class="generalBasic" id="data-idx4">행사 문의 및 기술 지원은 아래 번호로 연락주세요.</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p class="mb40">등록 관련  :  02-6959-4867<br />
                접속 관련  :  02-6959-4867</p>
                <div class="btns">
                	<p><a href="/member/counseling" class="generalBasic" id="data-idx12">문의하기</a></p>
                	<p><a href="https://into-on.adobeconnect.com/common/help/ko/support/meeting_test.htm" target="_blank">접속테스트</a></p>
                	<p><a href="/guide" class="generalBasic" id="data-idx11">접속안내</a></p>
                </div>
            </div>
            </form>
        </div>
        <!--//wrap--> 
    </div>
    <!--//login--> 
    <!--footer-->
    <div id="footer"> 
        <!--wrap-->
        <div class="wrap">
            <div class="logo"><a href="/main"><img class="generalImg" id="data-idx5" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
            <div class="info">
            	<dl>
                	<dt class="generalBasic" id="data-idx6">인투온제약(주)</dt>
                    <dd class="generalBasic" id="data-idx7">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                </dl>
            	<dl>
                	<dt class="generalBasic" id="data-idx8">인투온약품(주)</dt>
                    <dd class="generalBasic" id="data-idx9">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                </dl>
                <div class="code generalBasi" id="data-idx10">GCMA COME : PP-PNA-ABT-0056</div>
            </div>
        </div>
        </div>
        <!--//wrap--> 
    </div>
    <!--//footer--> 
</div>
<script>
$(document).ready(function(){
    $('.bt_login').on('click', function(){
        if($('#userid').val()==""){
            alert('아이디를 입력해주세요.');
            $('#userid').focus();
            return false;
        }else if($('#password').val()==""){
            alert('비밀번호를 입력해주세요.');
            $('#password').focus();
            return false;
        }else{
            $('#loginForm').submit();
        }
    });
    $('form input').keydown(function(e) {
        if (e.keyCode == 13) {
        	 if($('#userid').val()==""){
                 alert('아이디를 입력해주세요.');
                 $('#userid').focus();
                 return false;
             }else if($('#password').val()==""){
                 alert('비밀번호를 입력해주세요.');
                 $('#password').focus();
                 return false;
             }else{
                 $('#loginForm').submit();
             }
        }
    });
});
</script>
<?php  if(@$this->session->userdata('idmanagers')!='') : ?>
	<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
		<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
		<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
		<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
		<input type="hidden" name="_segment" value="login"/>
		<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
		<input type="hidden" name="o_content" id="o_content" value="" />
		<input type="hidden" name="c_content" id="c_content" value="" />
		<button class="test-save" type="submit">테스트 페이지 적용</button>
		<button class="real-save">원본 페이지 적용</button>
	</form>
	<?php
	$this->load->view("/manager/config/configPopUp");
endif;
?>
</body>
</html>
