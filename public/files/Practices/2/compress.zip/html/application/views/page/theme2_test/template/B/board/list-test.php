<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php //if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php //} ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">

	</style>
</head>
<body>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">���� �ٷΰ���</a>
		<a href="#">�׺���̼� �ٷΰ���</a>
	</div>
	<!--header-->
	<div id="header">
		<div class="top_img"></div>
		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/7e293b4bb7e100938645b38c8f443d6c.png" alt="INTOON (��)������" /></a></h1>

			<a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>�޴� ����</a><!---->

			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<li class="hidden_m"><a href="#none">menu</a></li><!---->
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->
				<!--tm-->
				<div id="tm">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">ȸ������ ����</a></li>
						<?php } ?>
						<li><a href="/board">��������</a></li>
						<li><a href="/member/counseling">��㹮��</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">�α׾ƿ�</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">�α���</a></li>
						<?php } ?>
					</ul>

					<div class="logo_h"><!---->
						<img class="generalImg" id="data-idx2" src="<?php echo IMG_DIR.$layout->template?>/images/logo_h.png" alt=""/><!---->
					</div>

				</div>
				<!--tm-->
			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->

	<div class="menu_bg"></div>
	<!---->

	<!--container-->
	<div id="container">
		<!--    	<h2>�������� ��������</h2>-->

		<div class="wrap_bg">
			<div class="bg_inner">
				<h3 class="generalBasic" id="data-idx3">�������� ��������</h3>
				<!--        	    <h3 class="colortit"> �Ұ�</h3>-->
				<p class="generalBasic" id="data-idx4">Symposium Notice</p>
			</div>
		</div>

		<!--wrap-->
		<div class="wrap">


			<div class="w_box2">
				<!--                <h4 class="w_tit">�������� ���</h4>-->
				<!--board-->
				<div class="board">
					<table class="tb_board">
						<caption class="generalBasic" id="data-idx5">
							�������� ����Ʈ
						</caption>
						<colgroup>
							<col width="" />
						</colgroup>
						<thead>
						<tr>
							<th scope="col" class="m_less">��ȣ</th>
							<th scope="col">����</th>
							<th scope="col" class="m_less">�ۼ���</th>
							<th scope="col">��¥</th>
						</tr>
						</thead>
						<tbody>
						<?php  foreach ($list as $key => $lt){?>
							<tr>
								<td><?php echo $total_rows - (($page - 1) * $per_page + $key);?></td>
								<td class="tit"><a href="/board/detail/<?php echo $lt->idarticle;?>"><span>[��������]</span><?php echo $lt->title ?></a></td>
								<td><?php echo $lt->writer?></td>
								<td><?php echo mdate("%Y. %m. %d", human_to_unix($lt->regDate));?></td>
							</tr>
						<?php } ?>
						<!--<tr>
                            <td>9</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td class="tit"><a href="view.html"><span>[��������]</span>������ ���̳��� �Ұ�</a></td>
                            <td>John Smith</td>
                            <td>2019. 05. 07</td>
                        </tr>-->
						</tbody>
					</table>
					<!--                    <div class="top_supis2"></div>-->
					<!--pagination-->
					<div class="pagination">
						<?php
						if($this->uri->segment(4) > 1){
							$prevUrl = $this->uri->segment(4)-1;
						}else{
							$prevUrl = 1;
						}
						if($this->uri->segment(4) < $total_pages){
							$nextUrl = $this->uri->segment(4)+1;
						}else{
							$nextUrl = $last_url;
						}
						?>
						<?php if($total_pages == 1){?>
							<a href="<?php echo $first_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="�� ó��" />
							</a>
							<a href="<?php echo $first_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="����" />
							</a>
							<span>
                           <a href="<?php echo $first_url;?>" class="on">1</a>
                        </span>
							<a href="<?php echo $last_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="����" />
							</a>
							<a href="<?php echo $last_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="������" />
							</a>
						<?php }else{ ?>
							<a href="<?php echo $first_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="�� ó��" />
							</a>
							<a href="<?php echo $prevUrl;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="����" />
							</a>
							<span>
                           <?php echo $pagination;?>
                        </span>
							<a href="<?php echo $nextUrl;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="����" />
							</a>
							<a href="<?php echo $last_url;?>">
								<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="������" />
							</a>
						<?php } ?>
					</div>
					<!--//pagination-->
				</div>
				<!--//board-->
			</div>
			<!--//w_box-->
		</div>
		<!--//wrap-->
	</div>
	<!--//container-->
	<!--footer-->
	<div id="footer">
		<!--wrap-->
		<div class="foot_top">
			<div class="f_top_inner">
				<ul>
					<li>
						<a href="https://into-on.adobeconnect.com/common/help/ko/support/meeting_test.htm" target="_blank" class="f_top_tit">�����׽�Ʈ</a>
						<p class="generalBasic" id="data-idx7">��Ȱ�� �������� ������ ���� ��ȭ�� �׽�Ʈ, ���ͳ� �ӵ� �׽�Ʈ, �÷��� �÷��̾� ���� �׽�Ʈ ���� �����մϴ�.</p>
						<a href="https://into-on.adobeconnect.com/common/help/ko/support/meeting_test.htm" target="_blank" class="bt_go2">Ȯ���ϱ�</a>
					</li>
					<li>
						<a href="/guide" class="f_top_tit">���Ӿȳ�</a>
						<p class="generalBasic" id="data-idx9">Ŭ���Ͻø� ����� ���� ����� �ڼ��� Ȯ�� �Ͻ� �� �ֽ��ϴ�.</p>
						<a href="/guide" class="bt_go2">Ȯ���ϱ�</a>
					</li>
				</ul>
			</div>
		</div>
		<div class="wrap">
			<div class="logo"><a href="/main"><img class="generalImg" id="data-idx10" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (��)������" /></a></div>
			<div class="info">
				<dl>
					<dt class="generalBasic" id="data-idx11">����������(��)</dt>
					<dd class="generalBasic" id="data-idx12">����� ��걸 ����� 341 ��ȣ��þ�þ� A���� 2�� / ��ǰ���� 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
				</dl>
				<dl>
					<dt class="generalBasic" id="data-idx13">�����¾�ǰ(��)</dt>
					<dd class="generalBasic" id="data-idx14">��⵵ ������ ������ �ֱ���� 392-11 / ��ǰ���� 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
				</dl>
			</div>
			<div class="code generalBasic" id="data-idx280">GCMA COME : 99-9NA-ABT-0056</div>
		</div>
		<!--//wrap-->
	</div>
	<!--//footer-->
</div>
<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">�׽�Ʈ ������ ����<button>
			<button class="real-save">���� ������ ����</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
