<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php  if(@$this->session->userdata('idmanagers')!=''){?>
	<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php } ?>
	<script type="text/javascript">


    </script>
    <style type="text/css">

    </style>
    <!--[if IE 9]>
        <script src="<?php echo JS_DIR.$layout->template?>/js/main_ie9.js"></script>
        <link rel="stylesheet" href="<?php echo CSS_DIR.$layout->template?>/css/style_ie9.css">
    <![endif]-->
</head>

<body>
    <div id="wrap">
        <div class="skip_nav">
            <a href="#">본문 바로가기</a>
            <a href="#">네비게이션 바로가기</a>
        </div>
        <div class="top_img"></div>
        <!--header-->
        <div id="header">

            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo JS_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></h1>

                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!---->

                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <li class="hidden_m"><a href="#none">menu</a></li>
                            <!---->
                           <?php foreach($pages as $pg){?>
                            <li><a href="<?php echo  $pg->path;?>" class="<?php echo $this->uri->segment(1) == 'replay'&& $pg->path=='/replay' ? 'active':''?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->

                    <!--tm_m-->
                    <div id="tm_m">
                        <ul>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                            <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                            <li><a href="/member/login">로그인</a></li>
                            <?php } ?> 
                        </ul>

                        <div class="logo_h">
                            <!---->
                            <img class="generalImg" id="data-idx2" src="<?php echo JS_DIR.$layout->template?>/images/logo_h.png" alt="" />
                            <!---->
                        </div>

                    </div>
                    <!--//tm_m-->

                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <!--//header-->

        <div class="menu_bg"></div>
        <!---->

        <!--container-->
        <div id="container">
            <!--    	<h2>심포지엄 다시보기</h2>-->

            <div class="contents_inner">
                <!--tm-->
                <div id="tm">
                    <ul>
                        <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/modify">회원정보 수정</a></li>
                        <?php } ?>
                        <li><a href="/board">공지사항</a></li>
                        <li><a href="/member/counseling">상담문의</a></li>
                        <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/logout">로그아웃</a></li>
                        <?php }else{ ?>
                        <li><a href="/member/login">로그인</a></li>
                        <?php } ?> 
                    </ul>

                    <div class="logo_h">
                        <!---->
                        <img class="generalImg" id="data-idx3" src="<?php echo JS_DIR.$layout->template?>/images/logo_h.png" alt="" />
                        <!---->
                    </div>

                </div>
                <!--tm-->
                <div class="wrap_bg">
                    <div class="bg_inner">
                        <h3 class="generalBasic" id="data-idx4">심포지엄 다시보기</h3>
                        <!--        	    <h3 class="colortit"> 소개</h3>-->
                        <span class="generalBasic" id="data-idx5">Symposium Schedule</span>
                    </div>
                </div>
                <!--wrap-->
                <div class="wrap">
                  <!--   <h4 class="w_tit2 generalBasic" id="data-idx6">다시보기 리스트</h4> -->
                    <!--sp_lay-->
                    <div class="sp_lay2">
                        <!--l_area-->
                        <div class="l_area">
                            <!--reviewing-->
                            <div class="schedule2"><!--reviewing-->
                                <ul class="list">
                                 <?php  foreach ($list as $lt){?>
                                    <li>
                                        <div class="ph"><a href="/replay/detail/<?php echo $lt->idvods;?>"><img src="<?php echo IMG_DIR.$layout->template?>/images/rev4.png" alt="" /></a></div>
                                        <div class="tx">
                                            <a href="/replay/detail/<?php echo $lt->idvods;?>" class="tit"><?php echo $lt->title;?></a>
                                            <div class="date_list">
                                                <span class="fc_red2"><?php echo mdate("%Y.", human_to_unix($lt->regDate));?></span>
                                                <span class="fc_red2"><?php echo mdate("%m.", human_to_unix($lt->regDate));?></span>
                                                <span class="fc_red2"><?php echo mdate("%d", human_to_unix($lt->regDate));?></span>
                                            </div>
                                            <div class="info">
                                                <dl>
                                                    <dt>발표시간</dt>
                                                    <dd class="dlml"> <?php echo mdate("%Y-%m-%d", human_to_unix($lt->regDate));?> <?php echo $lt->startTime;?> ~ <?php echo $lt->endTime;?></dd>
                                                    <p class="brmm">&nbsp;</p>
                                                    <dt>발표자</dt>
                                                    <dd><?php echo $lt->speaker;?> (<?php echo $lt->speakerTitle;?>)</dd>
                                                </dl>
                                            </div>
                                            <!--                                            <a href="detail.html" class="bt_txt bt_view_detail">다시보기</a>-->
                                        </div>
                                    </li>
                                    <?php } ?>
                                    <!-- <li>
                                        <div class="ph"><a href="detail.html"><img src="../images/rev3.png" alt="" /></a></div>
                                        <div class="tx">
                                            <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                            <div class="date_list">
                                                <span class="fc_red2">2019.</span>
                                                <span class="fc_red2">05.</span>
                                                <span class="fc_red2">01</span>
                                            </div>
                                            <div class="info">
                                                <dl>
                                                    <dt>발표시간</dt>
                                                    <dd class="dlml"> 2015-07-22 21:30 ~ 22:30</dd>
                                                    <p class="brmm">&nbsp;</p>
                                                    <dt>발표자</dt>
                                                    <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                                </dl>
                                            </div>
                                                                                  
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ph"><a href="detail.html"><img src="../images/rev2.png" alt="" /></a></div>
                                        <div class="tx">
                                            <a href="detail.html" class="tit">SEPSIS 심포지엄 - 다시보기</a>
                                            <div class="date_list">
                                                <span class="fc_red2">2019.</span>
                                                <span class="fc_red2">05.</span>
                                                <span class="fc_red2">01</span>
                                            </div>
                                            <div class="info">
                                                <dl>
                                                    <dt>발표시간</dt>
                                                    <dd class="dlml"> 2015-07-22 21:30 ~ 22:30</dd>
                                                    <p class="brmm">&nbsp;</p>
                                                    <dt>발표자</dt>
                                                    <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                                </dl>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ph"><a href="detail.html"><img src="../images/rev.png" alt="" /></a></div>
                                        <div class="tx">
                                            <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                            <div class="date_list">
                                                <span class="fc_red2">2019.</span>
                                                <span class="fc_red2">05.</span>
                                                <span class="fc_red2">01</span>
                                            </div>
                                            <div class="info">
                                                <dl>
                                                    <dt>발표시간</dt>
                                                    <dd class="dlml"> 2015-07-22 21:30 ~ 22:30</dd>
                                                    <p class="brmm">&nbsp;</p>
                                                    <dt>발표자</dt>
                                                    <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                                </dl>
                                            </div>
                                        
                                        </div>
                                    </li> -->
                                </ul>
                            </div>
                            <!--//reviewing-->
                        </div>
                        <!--//l_area-->
                        <!--pagination-->
                       <?php 
                    	//if($last_url > 0){
                    	?>
                    
                        <!--<div class="pagination">-->
                            <?php 
                               /*if($this->uri->segment(4) > 1){
                                   $prevUrl = $this->uri->segment(4)-1;  
                               }else{
                                   $prevUrl = 1;
                               }
                               if($this->uri->segment(4) < $total_pages){
                                   $nextUrl = $this->uri->segment(4)+1;
                               }else{
                                   $nextUrl = $last_url;
                               }
                             ?>
                             <?php if($total_pages == 1){?>
                              <a href="<?php echo $first_url;?>">
                            	<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="맨 처음" />
                            </a>
                             <a href="<?php echo $first_url;?>">
                                 <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="이전" />
                             </a>
                             <span>
                                 <a href="<?php echo $first_url;?>" class="on">1</a>
                             </span>
                             <a href="<?php echo $last_url;?>">
                                  <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="다음" />
                              </a>
                              <a href="<?php echo $last_url;?>">
                                   <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="마지막" />
                               </a>
                            </div>
                             <?php }else{?>
                            <a href="<?php echo $first_url;?>">
                            	<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="맨 처음" />
                            </a>
                             <a href="<?php echo $prevUrl;?>">
                                 <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="이전" />
                             </a>
                             <span>
                                 <?php echo $pagination;?>
                             </span>
                             <a href="<?php echo $prevUrl;?>">
                                  <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="다음" />
                              </a>
                              <a href="<?php echo $last_url;?>">
                                   <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="마지막" />
                               </a>
                            </div>-->
                            <?php 
                                   }
                    	       }*/
                            ?>
                 
                           <!--  <a href="#self">
                                <img src="../images/pn_first.png" alt="맨 처음" />
                            </a>
                            <a href="#self">
                                <img src="../images/pn_prev.png" alt="이전" />
                            </a>
                            <span>
                                <a href="#self" class="on">1</a>
                                <a href="#self">2</a>
                                <a href="#self">3</a>
                                <a href="#self">4</a>
                                <a href="#self">5</a>
                            </span>
                            <a href="#self">
                                <img src="../images/pn_next.png" alt="다음" />
                            </a>
                            <a href="#self">
                                <img src="../images/pn_last.png" alt="마지막" />
                            </a>
                        </div> -->
                        <!--//pagination->
                    </div>
                    <!--//sp_lay-->
                    <!--
                    <div class="foot_top2">
                        <div class="f_top_inner">
                            <ul>
                                <li class="ofoot2">
                                    <a href="#" class="f_top_tit">접속테스트</a>
                                    <p>원활한 심포지엄 접속을 위해 방화벽 테스트, 인터넷 속도 테스트, 플래시 플레이어 버전 테스트 등을 진행합니다.</p>
                                    <a href="#self" class="bt_go2">확인하기</a>
                                </li>
                                <li class="ofoot3">
                                    <a href="#" class="f_top_tit">모바일 접속안내</a>
                                    <p>클릭하시면 모바일 접속 방법을 자세히 확인 하실 수 있습니다.</p>
                                    <a href="#self" class="bt_go2">확인하기</a>
                                </li>

                                <li>
                                    <a href="#" class="f_top_tit">강좌 시청 안내</a>
                                    <dl class="guide_for2">
                                        <dt>1</dt>
                                        <dd>Explorer 10이상, Chrome 등에서 원활한 시청 가능합니다.</dd>
                                        <br />
                                        <dt>2</dt>
                                        <dd>강좌 시청을 완료하시면 서베이가 진행됩니다.</dd>
                                        <br />
                                        <dt>3</dt>
                                        <dd>강좌 시청시 원하시는 위치로 이동하여 시청하실 수 있습니다.</dd>
                                        <br />
                                        <dt class="nodt">&nbsp;&nbsp;</dt>
                                        <dd>(반복시청 가능)</dd>
                                    </dl>
                                    <p class="ender">많은 참여 부탁드립니다.</p>
                                </li>
                            </ul>
                        </div>
                    </div>
-->
                </div>
                <!--//wrap-->

                <!--footer-->
                <div id="footer">
                    <!--wrap-->

                    <div class="wrap">
                        <div class="logo"><a href="/main"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></div>
                        <div class="info">
                            <dl>
                                <dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
                                <dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                            </dl>
                            <dl>
                                <dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
                                <dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                            </dl>

                        </div>
                    </div>
                    <!--//wrap-->
                    <div class="code generalBasic" id="data-idx13">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
                <!--//footer-->
            </div>
            <!--//contents_inner-->
        </div>
        <!--//container-->
    </div>
		<?php  if(@$this->session->userdata('idmanagers')!='') : ?>
			<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
				<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
				<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
				<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
				<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
				<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
				<input type="hidden" name="o_content" id="o_content" value="" />
				<input type="hidden" name="c_content" id="c_content" value="" />
				<button class="test-save" type="submit">테스트 페이지 적용</button>
				<button class="real-save">원본 페이지 적용</button>
			</form>
			<?php
			$this->load->view("/manager/config/configPopUp");
		endif;
		?>
</body>

</html>
