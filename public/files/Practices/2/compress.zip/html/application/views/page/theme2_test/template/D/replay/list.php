<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
<title><?php echo $layout->name?></title>
<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
<?php  if(@$this->session->userdata('idmanagers')!=''){?>
<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
<?php } ?>
<script type="text/javascript">

</script>
<style type="text/css">

</style>
</head>
<body>
<div id="wrap"> 
    <div class="skip_nav">
        <a href="#">본문 바로가기</a>
        <a href="#">네비게이션 바로가기</a>
    </div>
    <!--header-->
    <div id="header"> 
       <div class="top_img"></div>
        <!--wrap-->
        <div class="wrap">
            <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
            <!--menu-->
            <div id="menu">
                <!--gnb-->
                <div id="gnb">
                    <ul>
                        <?php foreach($pages as $pg){?>
                            <li><a href="<?php echo  $pg->path;?>" class="<?php echo $this->uri->segment(1) == 'replay'&& $pg->path=='/replay' ? 'active':''?>"><?php echo $pg->title; ?></a></li>
                        <?php } ?> 
                    </ul>
                </div>
                <!--//gnb-->
                <!--tm-->
                <div id="tm">
                    <ul>
                    <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/modify">회원정보 수정</a></li>
                    <?php } ?>
                        <li><a href="/board">공지사항</a></li>
                        <li><a href="/member/counseling">상담문의</a></li>
                        <?php if(@$this->session->userdata('logged_in')==true){?>
                        <li><a href="/member/logout">로그아웃</a></li>
                        <?php }else{ ?>
                        <li><a href="/member/login">로그인</a></li>
                    <?php } ?>  
                    </ul>
                </div>
                <!--tm--> 
            </div>
            <!--//menu-->
        </div>
        <!--//wrap--> 
    </div>
    <!--//header--> 
    <div class="menu_bg"></div>
    <!--//header--> 
    <!--container-->
    <div id="container"> 
<!--    	<h2>심포지엄 다시보기</h2>-->
        <!--wrap-->
        <div class="wrap">
           <h3 class="generalBasic" id="data-idx2">심포지엄</h3>
           <h3 class="colortit generalBasic" id="data-idx3"> 다시보기</h3>
            <p class="generalBasic" id="data-idx4">Symposium Review</p>
            <ol>
                <li><a href="/main">Symposium Home</a></li>
                <li><a href="/replay">심포지엄 다시보기</a></li>
            </ol>
            <!--w_box-->
            <div class="top_supis"></div>
      <!--       <h4 class="w_tit2 generalBasic" id="data-idx5">다시보기 영상 리스트</h4> -->
            <!--sp_lay-->
            <div class="sp_lay">
            	<!--l_area-->
            	<div class="l_area">
                    <!--reviewing-->
                    <div class="schedule2"><!--reviewing-->
                        <ul class="list">
                        <?php  foreach ($list as $lt){?>
                            <li>
                                <div class="ph"><a href="/replay/detail/<?php echo $lt->idvods;?>"><img src="<?php echo IMG_DIR.$layout->template?>/images/cs.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="/replay/detail/<?php echo $lt->idvods;?>" class="tit"><?php echo $lt->title;?></a>
                                    <p class="info_txt"><?php echo $lt->description;?></p>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> <?php echo mdate("%Y. %m. %d", human_to_unix($lt->regDate));?> <?php echo $lt->startTime;?> ~ <?php echo $lt->endTime;?></dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd><?php echo $lt->speaker;?> (<?php echo $lt->speakerTitle;?>)</dd>
                                        </dl>
                                    </div>
<!--                                    <a href="detail.html" class="bt_txt bt_view_detail">자세히보기</a>-->
                                </div>
                            </li>
                            <?php } ?>
                            <!--<li>
                                <div class="ph"><a href="detail.html"><img src="../images/ccss.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> 2015-07-22 21:30 ~ 22:30</dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                        </dl>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="ph"><a href="detail.html"><img src="../images/ccs.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="detail.html" class="tit">SEPSIS 심포지엄 - 다시보기</a>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> 2015-07-22 21:30 ~ 22:30</dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                        </dl>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="ph"><a href="detail.html"><img src="../images/ccc3.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> 2015-07-22 21:30 ~ 22:30</dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                        </dl>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="ph"><a href="detail.html"><img src="../images/ccc2.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> 2015-07-22 21:30 ~ 22:30</dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                        </dl>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="ph"><a href="detail.html"><img src="../images/ccc.png" alt="" /></a></div>
                                <div class="tx">
                                    <a href="detail.html" class="tit">네시나액트 2019 심포지엄 - 다시보기</a>
                                    <div class="info">
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd> 2015-07-22 21:30 ~ 22:30</dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                        </dl>
                                    </div>
                                </div>
                            </li>-->
                        </ul>
                    </div>
                    <!--//reviewing-->
                </div>
            	<!--//l_area-->
            	<!--pagination-->
            	<?php 
            	//if($last_url > 0){
            	?>
                  <!--   <div class="pagination"> -->
                    <?php 
                        /*if($this->uri->segment(4) > 1){
                            $prevUrl = $this->uri->segment(4);                        
                        }else{
                            $prevUrl = 1;
                        }
                        if($last_url > $last_url){
                            $nextUrl = $this->uri->segment(4);
                        }else{
                            $nextUrl = $last_url;
                        }
                     ?>
                    <?php if($total_pages == 1){?>
                      <a href="<?php echo $first_url;?>">
                    	<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="맨 처음" />
                    </a>
                     <a href="<?php echo $first_url;?>">
                         <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="이전" />
                     </a>
                     <span>
                       <a href="<?php echo $first_url;?>" class="on">1</a>
                     </span>
                     <a href="<?php echo $last_url;?>">
                          <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="다음" />
                      </a>
                      <a href="<?php echo $last_url;?>">
                           <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="마지막" />
                       </a>
                    </div>
                    <?php }else{?>
                    <a href="<?php echo $first_url;?>">
                    	<img src="<?php echo IMG_DIR.$layout->template?>/images/pn_first.png" alt="맨 처음" />
                    </a>
                     <a href="<?php echo $prevUrl;?>">
                         <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_prev.png" alt="이전" />
                     </a>
                     <span>
                         <?php echo $pagination;?>
                     </span>
                     <a href="<?php echo $prevUrl;?>">
                          <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_next.png" alt="다음" />
                      </a>
                      <a href="<?php echo $last_url;?>">
                           <img src="<?php echo IMG_DIR.$layout->template?>/images/pn_last.png" alt="마지막" />
                       </a>
                    </div>
                    <?php 
                          }
            	       }
                    */
                    ?>
                     <!--<a href="#self">
                            <img src="../images/pn_first.png" alt="맨 처음" />
                        </a>
                        <a href="#self">
                            <img src="../images/pn_prev.png" alt="이전" />
                        </a>
                        <span>
                            <a href="#self" class="on">1</a>
                            <a href="#self">2</a>
                            <a href="#self">3</a>
                            <a href="#self">4</a>
                            <a href="#self">5</a>
                        </span>
                        <a href="#self">
                            <img src="../images/pn_next.png" alt="다음" />
                        </a>
                        <a href="#self">
                            <img src="../images/pn_last.png" alt="마지막" />
                        </a>
                    </div>-->
                    <!--//pagination-->
            </div>
            <!--//sp_lay-->
        </div>
        <!--//wrap--> 
    </div>
    <!--//container--> 
    <!--footer-->
    <div id="footer"> 
        <!--wrap-->
        <div class="foot_top">
            <h3 class="generalBasic" id="data-idx6">Symposium</h3>
            <p class="generalBasic" id="data-idx7">이제는 심포지엄 인터넷으로 참여하는 시대 인투온을 통해 편리하게 소통하세요</p>
        </div>
        <div class="wrap">
            <div class="logo"><a href="/main"><img class="generalImg" id="data-idx8" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
            <div class="info">
            	<dl>
                	<dt class="generalBasic" id="data-idx9">인투온제약(주)</dt>
                    <dd class="generalBasic" id="data-idx10">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                </dl>
            	<dl>
                	<dt class="generalBasic" id="data-idx11">인투온약품(주)</dt>
                    <dd class="generalBasic" id="data-idx12">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                </dl>
            </div>
           <div class="code generalBasic" id="data-idx27">GCMA COME : PP-PNA-ABT-0056</div>
        </div>
        <!--//wrap--> 
    </div>
    <!--//footer-->
	<?php  if(@$this->session->userdata('idmanagers')!='') : ?>
		<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
			<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
			<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
			<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
			<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
			<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
			<input type="hidden" name="o_content" id="o_content" value="" />
			<input type="hidden" name="c_content" id="c_content" value="" />
			<button class="test-save" type="submit">테스트 페이지 적용</button>
			<button class="real-save">원본 페이지 적용</button>
		</form>
		<?php
		$this->load->view("/manager/config/configPopUp");
	endif;
	?>
</div>
</body>
</html>
