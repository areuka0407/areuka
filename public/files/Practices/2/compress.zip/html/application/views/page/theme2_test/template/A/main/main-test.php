<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php  //if(@$this->session->userdata('idmanagers')!=''){?>
    <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
    <?php //} ?>
    <style type="text/css">

    </style>
</head> 
<body>
<div id="wrap_off">
    <div id="wrap">
        <!--header-->
        <div id="header">
            <!--wrap-->
            <div class="wrap">
                <h1 id="logo"><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <?php foreach($pages as $pg){?>
                                <li><a href="<?php echo $pg->path;?>" class="<?php echo $this->uri->segment(1) == 'main'&& $pg->path=='/main' ? 'active':''?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->
                    <!--tm-->
                    <div id="tm">
                        <ul>
                            <?php if(@$this->session->userdata('userid')!=''){?>
                                <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('userid')!=''){?>
                                <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                                <li><a href="/member/login">로그인</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--tm-->
                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <div class="menu_bg"></div>
        <!--//header-->
        <!--main_contents-->
        <div id="main_contents">
            <!--wrap-->
            <div class="wrap">
                <?php if(!empty($simposiumLatestPosts)){?>
                    <h2 class="c_wh generalBasic" id="data-idx2">심포지엄 일정</h2>
                    <!--m_s_schedule-->
                    <div class="m_s_schedule">
                        <div class="ph"><img class="generalImg" id="data-idx3" src="<?php echo IMG_DIR.$layout->template?>/images/sph559x290.jpg" alt="" /></div>
                        <div class="tx">
                            <h3><?php echo  $simposiumLatestPosts[0]->title;?></h3>
                            <div class="g_tx"><?php echo  $simposiumLatestPosts[0]->description?></div>
                            <div class="info">
                                <span>발표시간  :  <?php echo nice_date( $simposiumLatestPosts[0]->regDate, 'Y.m.d');?>(<?php echo $simposiumLatestPosts[0]->regWeek;?>) <?php echo $simposiumLatestPosts[0]->startTime;?> ~ <?php echo $simposiumLatestPosts[0]->endTime;?></span>
                                <span>발표자  :  <?php echo $simposiumLatestPosts[0]->speaker?> (<?php echo  $simposiumLatestPosts[0]->speaker?>)</span>
                            </div>
                            <a href="/schedule/live/<?php echo $simposiumLatestPosts[0]->idsymposium?>" class="bt_txt bt_enter">입장하기</a>
                        </div>
                    </div>
                <?php } ?>
                <!--//m_s_schedule-->
                <?php if(!empty($replayLatestPosts)){
                    if(count($replayLatestPosts) == 1){
                    }?>
                    <h2 class="generalBasic" id="data-idx4">다시보기</h2>
                    <!--m_s_reviewing-->
                    <div class="m_s_schedule">
                        <div class="ph"><img class="generalImg" id="data-idx3" src="<?php echo IMG_DIR.$layout->template?>/images/sph559x290.jpg" alt="" /></div>
                        <div class="tx">
                            <h3><?php echo  $replayLatestPosts[0]->title;?></h3>
                            <div class="g_tx"><?php echo  $replayLatestPosts[0]->description?></div>
                            <div class="info">
                                <span>발표시간  :  <?php echo nice_date($replayLatestPosts[0]->regDate, 'Y.m.d');?>(<?php echo $simposiumLatestPosts[0]->regWeek;?>) <?php echo$replayLatestPosts[0]->startTime;?> ~ <?php echo $replayLatestPosts[0]->endTime;?></span>
                                <span>발표자  :  <?php echo $replayLatestPosts[0]->speaker?> (<?php echo  $replayLatestPosts[0]->speaker?>)</span>
                            </div>
                            <a href="/replay/detail/<?php echo $replayLatestPosts[0]->idvods?>" class="bt_txt bt_enter">입장하기</a>
                        </div>
                    </div>
                    <?php
                }else{
                    ?>
                    <h2 class="generalBasic" id="data-idx4"></h2>
                    <!--m_s_reviewing-->
                    <div class="m_s_reviewing">
                        <a href="/replay/lists" class="bt_txt bt_view_more generalBasic" id="data-idx5">더보기</a>
                        <ul class="list">
                            <?php  foreach ($replayLatestPosts as $rp){?>
                                <li>
                                    <div class="ph" style="background-image:url(<?php echo IMG_DIR.$layout->template?>/images/sph290x218.jpg);"><a href="/replay/detail/<?php echo $rp->idvods;?>">바로가기</a></div>
                                    <div class="tx">
                                        <a href="/replay/detail/<?php echo $rp->idvods;?>" class="tit"><?php echo $rp->title;?></a>
                                        <dl>
                                            <dt>발표시간</dt>
                                            <dd><?php echo mdate("%Y-%m-%d", human_to_unix($rp->regDate));?> <?php echo $rp->startTime;?> ~ <?php echo $rp->endTime;?></dd>
                                        </dl>
                                        <dl>
                                            <dt>발표자</dt>
                                            <dd><?php echo $rp->speaker;?> (<?php echo $rp->speakerTitle;?>)</dd>
                                        </dl>
                                    </div>
                                </li>
                            <?php } ?>
                            <!--<li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기네시나 액트 2019 - 다시보기네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)김병준 교수 (가천의대 내분비내과)김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="ph" style="background-image:url(images/sph290x218.jpg);"><a href="#self">바로가기</a></div>
                                <div class="tx">
                                    <a href="#self" class="tit">네시나 액트 2019 - 다시보기</a>
                                    <dl>
                                        <dt>발표시간</dt>
                                        <dd>2015-07-22 21:30 ~ 22:30</dd>
                                    </dl>
                                    <dl>
                                        <dt>발표자</dt>
                                        <dd>김병준 교수 (가천의대 내분비내과)</dd>
                                    </dl>
                                </div>
                            </li>-->
                        </ul>
                    </div>
                <?php } ?>
                <!--//m_s_reviewing-->
                <div class="m_bot">
                    <div class="m_notice">
                        <h3 class="generalBasic" id="data-idx6"><a href="/board/lists">심포지엄 공지사항</a></h3>
                        <a href="/board/lists" class="bt_view_more">더보기</a>
                        <dl>
                            <dt>
                                <?php echo  $noticeLatestPosts[0]->title;?>
                                <span><?php echo nice_date( $noticeLatestPosts[0]->regDate, 'Y-m-d');?></span>
                            </dt>
                            <dd> <?php echo  $noticeLatestPosts[0]->content;?></dd>
                        </dl>
                    </div>
                    <div class="m_quick">
                        <a href="https://into-on.adobeconnect.com/common/help/ko/support/meeting_test.htm" target="_blank">
                            <span class="generalBasic" id="data-idx7">접속테스트</span>
                            원활한 심포지엄 접속을 위해 방화벽 테스트, 인터넷 속도 테스트, 플래시 플레이어 버전 테스트 등을 진행합니다.
                        </a>
                        <a href="/guide" class="c_bk">
                            <span class="generalBasic" id="data-idx8">접속 안내</span>
                            클릭하시면 모바일 접속 방법을 자세히 확인 하실 수 있습니다.
                        </a>
                    </div>
                </div>
            </div>
            <!--//wrap-->
        </div>
        <!--//main_contents-->
        <!--footer-->
        <div id="footer">
            <!--wrap-->
            <div class="wrap">
                <div class="logo"><a href="/main"><img class="generalImg" id="data-idx9" src="<?php echo IMG_DIR.$layout->template?>/images/135a8cdf12f8a83f0d2e417d78a59fac.png" alt="INTOON (주)인투온" /></a></div>
                <div class="info">
                    <dl>
                        <dt class="generalBasic" id="data-idx10">인투온제약(주)</dt>
                        <dd class="generalBasic" id="data-idx11">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="www.into-on.com" target="_blank">www.into-on.com</a></dd>
                    </dl>
                    <dl>
                        <dt class="generalBasic" id="data-idx12">인투온약품(주)</dt>
                        <dd class="generalBasic" id="data-idx13">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="www.into-on.co.kr" target="_blank">www.into-on.co.kr</a></dd>
                    </dl>
                    <div class="code generalBasic" id="data-idx14">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
            </div>
            <!--//wrap-->
        </div>
        <!--//footer-->
    </div>
</div>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
    <input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
    <input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
    <input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
    <input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
    <input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
    <input type="hidden" name="o_content" id="o_content" value="" />
    <input type="hidden" name="c_content" id="c_content" value="" />
    <button class="test-save" type="submit">테스트 페이지 적용<button>
    <button class="real-save">원본 페이지 적용</button>
</form>

<?php $this->load->view("/manager/config/configPopUp");?>
</body>
</html>