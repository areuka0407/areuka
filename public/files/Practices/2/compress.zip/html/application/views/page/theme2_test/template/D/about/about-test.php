<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php  //if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php  //} ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">

	</style>
</head>
<body>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">본문 바로가기</a>
		<a href="#">네비게이션 바로가기</a>
	</div>


	<!--header-->
	<div id="header">
		<div class="top_img"></div>
		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/ca121186d63a99a11abc7d8ccfc4f881.png" alt="INTOON (주)인투온" /></a></h1>
			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>" class="<?php echo $this->uri->segment(1) == 'about'&& $pg->path=='/about' ? 'active':''?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->
				<!--tm-->
				<div id="tm">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">회원정보 수정</a></li>
						<?php } ?>
						<li><a href="/board">공지사항</a></li>
						<li><a href="/member/counseling">상담문의</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">로그아웃</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">로그인</a></li>
						<?php } ?>
					</ul>
				</div>
				<!--tm-->
			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->


	<div class="menu_bg"></div>
	<!--//header-->
	<!--container-->
	<div id="container">
		<!--    	<h2>심포지엄 소개</h2>-->
		<!--wrap-->
		<div class="wrap">
			<h3 class="generalBasic" id="data-idx2">심포지엄</h3>
			<h3 class="colortit generalBasic" id="data-idx3">소개</h3>
			<p>e-Symposium에 정중히 모십니다.</p>
			<ol>
				<li><a href="#" class="generalBasic" id="data-idx4">Symposium Home</a></li>
				<li><a href="#" class="generalBasic" id="data-idx5">심포지엄 소개</a></li>
			</ol>
			<!--w_box-->
			<div class="top_supis"></div>


			<div class="w_box">
				<h4 class="aboutit generalBasic" id="data-idx6">심포지엄 소개</h4>
				<!--about-->
				<div class="about">
					<div class="ph"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/jeil_img1.png" alt="INTOON 인투온" /></div>
					<div class="tx">
						<h4 class="generalBasic" id="data-idx8">e-Symposium에 정중히 모십니다.</h4>
						<p class="generalBasic" id="data-idx9">안녕하십니까?<br />
							이제 화창한 봄날인 00월입니다.<br /><br />
							저희 [제약사팀]에서는 [심포지엄명]을 통해 더욱 새로운 모습으로 선생님과의 만남을 준비하고 있습니다.<br />
							00월 00일(금) [심포지엄명]에서는 ["주제"]이라는 주제로 공유하고자 합니다.<br />
							환자 진료에 바쁘시더라도 부디 참석하시어 유익한 학술의 장을 만들어 주시기 바랍니다.</p>
						<p>&nbsp;</p>
						<p>선생님과 가정에 행운이 함께 하시길 기원합니다.</p>
						<p>&nbsp;</p>
						<div class="tr">0000년 00월<br />
							[제약사팀] 드림</div>
					</div>
				</div>
				<!--//about-->
			</div>
			<!--//w_box-->

			<div class="guider"></div>

			<h4 class="fc_grey generalBasic" id="data-idx10">제품 소개</h4>
			<!--w_box-->
			<div class="w_box">
				<!--about-->
				<div class="about">
					<div class="ph"><img class="generalImg" id="data-idx11" src="<?php echo IMG_DIR.$layout->template?>/images/jeil_img2.png" alt="캐스드레싱" /></div>
					<div class="tx">
						<dl>
							<dt class="generalBasic" id="data-idx12">전문의약품</dt>
							<dd class="generalBasic" id="data-idx13">
								리피토®정 10 mg, 20 mg (아토르바스타틴칼슘삼수화물)<br />
								Lipitor® Tablets 10 mg, 20 mg (atorvastatin calcium trihydrate)
							</dd>
						</dl>

						<dl>
							<dt class="generalBasic" id="data-idx14">보험코드</dt>
							<dd class="generalBasic" id="data-idx15">
								10 mg: E01890181<br />
								20 mg: E01890131
							</dd>
						</dl>

						<dl>
							<dt class="generalBasic" id="data-idx16">원료약품의 분량</dt>
							<dd class="generalBasic" id="data-idx17">
								10 mg: 매정당 아토르바스타틴칼슘 삼수화물(EP) 10.85 mg(아토르바스타틴으로서 10 mg에 해당량)을 함유<br />
								20 mg: 매정당 아토르바스타틴칼슘 삼수화물(EP) 21.70 mg(아토르바스타틴으로서 20 mg에 해당량)을 함유
							</dd>
						</dl>

						<dl>
							<dt class="generalBasic" id="data-idx18">포장단위</dt>
							<dd class="generalBasic" id="data-idx19">
								10 mg: 28정/블리스터, 90정/병<br />
								20 mg: 28정/블리스터, 90정/병
							</dd>
						</dl>
					</div>
				</div>
				<!--//about-->
			</div>
			<!--//w_box-->
		</div>
		<!--//wrap-->
	</div>
	<!--//container-->


	<!--footer-->
	<div id="footer">
		<!--wrap-->
		<div class="foot_top">
			<h3 class="generalBasic" id="data-idx20">Symposium</h3>
			<p class="generalBasic" id="data-idx21">이제는 심포지엄 인터넷으로 참여하는 시대 인투온을 통해 편리하게 소통하세요</p>
		</div>
		<div class="wrap">
			<div class="logo"><a href="/main"><img class="generalImg" id="data-idx22" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
			<div class="info">
				<dl>
					<dt class="generalBasic" id="data-idx23">인투온제약(주)</dt>
					<dd class="generalBasic" id="data-idx24">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
				</dl>
				<dl>
					<dt class="generalBasic" id="data-idx25">인투온약품(주)</dt>
					<dd class="generalBasic" id="data-idx26">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
				</dl>
			</div>
			<div class="code generalBasic" id="data-idx27">GCMA COME : PP-PNA-ABT-0056</div>
		</div>
		<!--//wrap-->
	</div>
	<!--//footer-->
</div>
<div class="full_screen_video">
	<img src="../images/sph780x414.jpg" alt="" />
	<h3 class="generalBasic" id="data-idx29">SEPSIS 심포지엄</h3>
	<a href="#self" class="bt_i bt_full_screen_off">전체화면 끄기</a>
</div>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">테스트 페이지 적용</button>
	<button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
