<!-- Modal -->
<div class="inton-modal" id="modal-name">
  <div class="inton-modal-sandbox"></div>
  <div class="inton-modal-box">
    <div class="inton-modal-header">
      <div class="inton-top-close-modal">&#10006;</div> 
      <h1>항목수정</h1>
    </div>
    <div class="inton-modal-body">
      <div class="inton-modal-content_id" id="" style="display:none;"></div>
      <div class="inton-modal-content">
      	<textarea name="inton-modal-textarea" id="myTextarea" class="inton-modal-textarea"></textarea>
         <div class="buttos">
          <br/> 
            <button class="inton-save-modal">확인</button>
            <button class="inton-close-modal">닫기</button>
          </div>
      </div>       
      <div class="inton-modal-img-content"  style="display:none;">
          <form id="upload_form" name="upload_form" method="post" enctype="multipart/form-data">
              <input type="text"  id="image-input" readonly>    
                  <input type="hidden" id="_path" name="_path" />
                  <input id="fileInput" type="file" name="upfile"/>
             <div class="buttos">
              	<br/> 
                	<button id="upfile-btn" class="inton-save-modal">확인</button>
                	<button class="inton-close-modal">닫기</button>
              </div>
          </form>  
       </div>            
    </div>
  </div>
</div>  
<script>
$(function() {
  tinymce.init({
	forced_root_block : "",
	mode : "specific_textareas",
    selector: '#myTextarea',
    menubar: false,
    plugins: [
      'autolink autosave code link media image table textcolor autoresize'
    ],
    toolbar: 'bold italic fontsizeselect forecolor link',
    fontsize_formats: "8pt 10pt 12pt 14pt 16pt 18pt 20pt 24pt 36pt 48pt",
    content_css: '//www.tinymce.com/css/codepen.min.css',
    mobile: {
        theme: 'mobile',
        plugins: [
            'autolink autosave code link media image table textcolor autoresize'
          ],
          toolbar: 'bold italic fontsizeselect forecolor link',
          fontsize_formats: "8pt 10pt 12pt 14pt 16pt 18pt 20pt 24pt 36pt 48pt",
          content_css: '//www.tinymce.com/css/codepen.min.css',
    }
  }); 
});
</script><!-- TINYMCE -->
<script src="<?php echo JS_DIR?>js/plugins/tinymce/jquery.tinymce.min.js"></script>
<script src="<?php echo JS_DIR?>js/plugins/tinymce/tinymce.min.js"></script>
<!-- //TINYMCE -->