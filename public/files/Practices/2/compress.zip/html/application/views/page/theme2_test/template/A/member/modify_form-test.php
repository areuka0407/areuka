<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php // if(@$this->session->userdata('idmanagers')!=''){?>
        <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
    <?php // } ?>
    <script type="text/javascript">

    </script>
    <style type="text/css">

    </style>
</head>
<body>
<div id="wrap_off">
    <div id="wrap">
        <!--header-->
        <div id="header">
            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <?php foreach($pages as $pg){?>
                                <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->
                    <!--tm-->
                    <div id="tm">
                        <ul>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                                <li><a href="/member/login">로그인</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--tm-->
                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <div class="menu_bg"></div>
        <!--//header-->
        <!--container-->
        <div id="container">
            <h2 class="generalBasic" id="data-idx2">회원정보 수정</h2>
            <!--wrap-->
            <div class="wrap">
                <h3 class="generalBasic" id="data-idx3">회원정보 수정</h3>
                <!--w_box-->
                <div class="w_box">
                    <form name="modifyForm" id="modifyForm" action="/member/modify" method="post">
                        <!--member-->
                        <div class="member">
                            <h4 class="tc mb30 generalBasic" id="data-idx4">수정내용 입력<span class="must"><i>＊</i> 필수 입력항목 입니다.</span></h4>
                            <div class="form">
                                <dl>
                                    <dt><i>*</i>아이디</dt>
                                    <dd><input type="text" name="userid" id="userid" value="<?php echo $auth->userid?>" placeholder="아이디를 입력해주세요."  readonly/></dd>
                                </dl>
                                <dl>
                                    <dt><i></i>기존 비밀번호</dt>
                                    <dd><input type="password" name="oldpassword" id="oldpassword" placeholder="기존비밀번호를 입력해주세요."/></dd>
                                </dl>
                                <dl>
                                    <dt><i></i>신규 비밀번호</dt>
                                    <dd><input type="password" name="newpassword" id="newpassword" placeholder="신규 비밀번호를 입력해주세요."/></dd>
                                </dl>
                                <dl>
                                    <dt><i></i>신규 비밀번호 확인</dt>
                                    <dd><input type="password" name="newrepassword" id="newrepassword" placeholder="입력하신  신규 비밀번호를 다시한번 입력해주세요."/></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>이메일</dt>
                                    <dd><input type="text" name="email" id="email" value="<?php echo $auth->email?>" placeholder="이메일을 입력해주세요." /></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>이름</dt>
                                    <dd class="name"><input type="text" name="firstname" id="firstname"  value="<?php echo $auth->firstname?>" placeholder="성" /><input type="text" name="lastname" id="lastname" value="<?php echo $auth->lastname?>" placeholder="이름" /></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>핸드폰 번호</dt>
                                    <dd><input type="text" name="phone" id="phone" value="<?php echo $auth->phone?>" placeholder="" /></dd>
                                </dl>
                                <dl>
                                    <dt>병원명</dt>
                                    <dd><input type="text" name="hospital" id="hospital" value="<?php if(!empty($auth->hospital)) echo $auth->hospital?>" placeholder="" /></dd>
                                </dl>
                                <dl>
                                    <dt>과명</dt>
                                    <dd><input type="text" name="course" id="course" value="<?php if(!empty($auth->course)) echo  $auth->course ?>" placeholder="" /></dd>
                                </dl>
                                <dl>
                                    <dt>영업담당</dt>
                                    <dd><input type="text" name="salesofficer" id="salesofficer"  value="<?php if(!empty($auth->salesofficer)) echo $auth->salesofficer?>" placeholder="" /></dd>
                                </dl>
                                <dl>
                                    <dt>영업담당조직</dt>
                                    <dd><input type="text" name="salesgroup" id="salesgroup" value="<?php if(!empty($auth->salesgroup)) echo $auth->salesgroup?>" placeholder="" /></dd>
                                </dl>
                            </div>
                            <p class="tc"><a href="#" class="bt_txt bt_bot modify_form_bt">수정하기</a></p>
                        </div>
                        <!--//member-->
                    </form>
                </div>
                <!--//w_box-->
            </div>
            <!--//wrap-->
        </div>
        <!--//container-->
        <!--footer-->
        <div id="footer">
            <!--wrap-->
            <div class="wrap">
                <div class="logo"><a href="/main"><img class="generalImg" id="data-idx5" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
                <div class="info">
                    <dl>
                        <dt class="generalBasic" id="data-idx6">인투온제약(주)</dt>
                        <dd class="generalBasic" id="data-idx7">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                    </dl>
                    <dl>
                        <dt class="generalBasic" id="data-idx8">인투온약품(주)</dt>
                        <dd class="generalBasic" id="data-idx9">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                    </dl>
                    <div class="code generalBasic" id="data-idx10">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
            </div>
        </div>
        <!--//wrap-->
    </div>
    <!--//footer-->
</div>
<script>
    $(document).ready(function(){
        //휴대폰번호 체크 정규식
        var phoneRegExp = /^\d{3}-\d{3,4}-\d{4}$/;
        //이메일 체크 정규식
        var emailRegExp = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
        $('.bt_bot').on('click', function(){
            if($('#email').val()==""){
                alert('이메일을 입력해주세요.');
                $('#email').focus();
                return false;
            }else if (!emailRegExp.test($('#email').val())) {
                alert("잘못된 이메일주소입니다.");
                return false
            }else if($('#oldpassword').val()=="" && $('#newpassword').val()!=""){
                alert("기존비밀번호를 입력 해주세요.");
                $('#oldpassword').focus();
                return false;
            }else if($('#oldpassword').val()!="" && $('#newpassword').val()==""){
                alert("신규번호를 입력 해주세요.");
                $('#newpassword').focus();
                return false;
            }else if( $('#newpassword').val()!="" && $('#newrepassword').val()==""){
                alert("입력하신 신규번호를  다시 입력 해주세요.");
                $('#newrepassword').focus();
                return false;
            }else if($('#newpassword').val() != $('#newrepassword').val()){
                alert('입력하신 신규비밀번호와 신규비밀번호확인 데이터가 틀립니다.');
                $('#newpassword').val('');
                $('#newrepassword').val('');
                $('#newpassword').focus();
                return false;
            }else if($('#firstname').val()==""){
                alert('성을 입력해주세요.');
                $('#firstname').focus();
                return false;
            }else if($('#lastname').val()==""){
                alert('이름을 입력해주세요.');
                $('#lastname').focus();
                return false;
            }else if($('#phone').val()==""){
                alert('휴대폰 번호를 입력해주세요.');
                $('#phone').focus();
                return false;
            }else if (!phoneRegExp.test($('#phone').val())) {
                alert("잘못된 휴대폰 번호입니다. 숫자, - 를 포함한 숫자만 입력하세요.");
                return false
            }else{
                $('#modifyForm').submit();
            }
        });
    });
</script>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
    <input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
    <input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
    <input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
    <input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
    <input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
    <input type="hidden" name="o_content" id="o_content" value="" />
    <input type="hidden" name="c_content" id="c_content" value="" />
    <button class="test-save" type="submit">테스트 페이지 적용<button>
            <button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
