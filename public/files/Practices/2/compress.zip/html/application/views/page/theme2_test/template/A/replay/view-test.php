<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php  //if(@$this->session->userdata('idmanagers')!=''){?>
        <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
    <?php //} ?>
    <script type="text/javascript">

    </script>
    <style type="text/css">

    </style>
</head>

<body>
<div id="wrap_off">
    <div id="wrap">
        <!--nonLogin-->
        <!--header-->
        <div id="header">
            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <?php foreach($pages as $pg){?>
                                <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->
                    <!--tm-->
                    <div id="tm">
                        <ul>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                                <li><a href="/member/login">로그인</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--tm-->
                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <div class="menu_bg"></div>
        <!--//header-->
        <!--container-->
        <div id="container">
            <h2 class="generalBasic" id="data-idx23">심포지엄 다시보기</h2>
            <!--wrap-->
            <div class="wrap">
                <h3 class="generalBasic" id="data-idx24">심포지엄 다시보기</h3>
                <!--w_box-->
                <div class="sp_lay">
                    <!--reviewing-->
                    <div class="l_area">
                        <div class="reviewing">
                            <!--view-->
                            <div class="view">
                                <!--t_area-->
                                <div class="t_area">
                                    <div class="ph"><img src="<?php echo IMG_DIR.$layout->template?>/images/sph288x216.jpg" alt="" /></div>
                                    <div class="tx">
                                        <h4><?php echo $detail->title;?></h4>
                                        <div class="name"><?php echo $detail->speaker;?> (<?php echo $detail->speakerTitle;?>)</div>
                                        <p><?php echo nl2br($detail->description);?></p>
                                    </div>
                                </div>
                                <!--//t_area-->
                                <!--video-->
                                <div class="video">
                                    <div class="box"><img src="<?php echo IMG_DIR.$layout->template?>/images/sph1100x582.jpg" alt="" /><a href="#self" class="bt_i bt_full_screen">전체화면으로 보기</a></div>
                                </div>
                                <!--//video-->
                                <!--speaker-->
                                <div class="speaker">
                                    <div class="ph"><img src="<?php echo IMG_DIR.$layout->template?>/images/sph151x200.jpg" alt="" /></div>
                                    <div class="tx">
                                        <div class="s_info">
                                            <dl>
                                                <dt class="colortit">발표자</dt>
                                                <dd class="name"><?php echo $detail->speaker;?> (<?php echo $detail->speakerTitle;?>)</dd>
                                            </dl>
                                            <dl>
                                                <dt class="colortit generalBasic" id="data-idx25">경력</dt>
                                                <dd>
                                                    <?php echo nl2br($detail->speakerDescription);?>
                                                </dd>
                                            </dl>
                                            <dl>
                                                <dt>학회활동</dt>
                                                <dd>
                                                    <?php echo nl2br($detail->academicDescription);?>
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                    <div class="bt_bot bt_ana"><a href="/replay/lists" class="bt_txt bt_list">목록</a></div>
                                </div>
                                <!--//speaker-->
                            </div>
                            <!--//view-->
                        </div>
                    </div>
                    <!--//reviewing-->
                    <!--r_area-->
                    <div class="r_area">
                        <!--unit-->
                        <div class="unit u01">
                            <h4 class="generalBasic" id="data-idx13">접속 관련 문의</h4>
                            <p class="generalBasic" id="data-idx14">심포지엄 접속에 문제가 있으신 경우 02-6959-4867로 연락바랍니다. </p>
                        </div>
                        <!--//unit-->
                        <!--unit-->
                        <div class="unit u02">
                            <h4 class="generalBasic" id="data-idx22">접속안내</h4>
                            <p class="generalBasic" id="data-idx9">클릭하시면 모바일 접속 방법을 자세히 확인 하실 수 있습니다.</p>
                            <a href="/guide" class="bt_go"></a>
                        </div>
                        <!--//unit-->
                        <!--unit-->
                        <div class="unit u04">
                            <h4 class="generalBasic" id="data-idx17">강좌 시청 안내</h4>
                            <p class="generalBasic" id="data-idx18">1. Explorer 10이상, Chrome 등에서 원활한 시청 가능합니다.</p>
                            <p>&nbsp;</p>
                            <p class="generalBasic" id="data-idx19">2. 강좌 시청을 완료하시면 서베이가 진행됩니다.</p>
                            <p>&nbsp;</p>
                            <p class="fc_red b generalBasic" id="data-idx20">3. 강좌 시청시 원하시는 위치로 이동하여 시청하실 수 있습니다. (반복시청 가능)</p>
                            <p>&nbsp;</p>
                            <p class="generalBasic" id="data-idx21">많은 참여부탁드립니다.</p>
                        </div>
                        <!--//unit-->
                    </div>
                    <!--//r_area-->
                </div>
                <!--//w_box-->

            </div>
            <!--//wrap-->
        </div>
        <!--//container-->
        <!--footer-->
        <div id="footer">
            <!--wrap-->
            <div class="wrap">
                <div class="logo"><a href="/main"><img  class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
                <div class="info">
                    <dl>
                        <dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
                        <dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                    </dl>
                    <dl>
                        <dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
                        <dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                    </dl>
                    <div class="code generalBasic" id="data-idx12">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
            </div>
            <!--//wrap-->
        </div>
        <!--//footer-->
    </div>
    <div class="full_screen_video">
        <img src="<?php echo IMG_DIR.$layout->template?>/images/sph780x414.jpg" alt="" />
        <h3>SEPSIS 심포지엄</h3>
        <a href="#self" class="bt_i bt_full_screen_off">전체화면 끄기</a>
    </div>
</div>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
    <input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
    <input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
    <input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
    <input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
    <input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
    <input type="hidden" name="o_content" id="o_content" value="" />
    <input type="hidden" name="c_content" id="c_content" value="" />
    <button class="test-save" type="submit">테스트 페이지 적용<button>
    <button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp");?>
</body>
</html>
