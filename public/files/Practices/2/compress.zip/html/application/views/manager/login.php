    <!--login-->
    <div class="login"> 
        <!--wrap-->
        <div class="wrap">       
        	<div class="login_box">
                <form name="loginForm" id="loginForm" method="post">
            	<h2>로그인</h2>
                <div class="form">
                	<input type="text" name="id" id="id" placeholder="아이디"  value="<?php echo set_value('id');?>"/>
                    <input type="password" name="password" id="password" placeholder="비밀번호" />               
                </div>
                <input type="submit" class="bt_txt bt_login" value="로그인">
                <div class="btns"><a href="/member/join">회원가입</a>|<a href="#self">비밀번호 찾기</a></div>
            </div>        
            </form>
        </div>
        <!--//wrap--> 
    </div>
    <!--//login--> 
<script>
$(document).ready(function(){
    $('.bt_login').on('click', function(){
        if($('#id').val()==""){
            alert('아이디를 입력해주세요.');
            $('#id').focus();
            return false;
        }else if($('#password').val()==""){
            alert('비밀번호를 입력해주세요.');
            $('#password').focus();
            return false;
        }else{
            $('#loginForm').submit();
        }
    });
});
</script>
</body>
</html>
