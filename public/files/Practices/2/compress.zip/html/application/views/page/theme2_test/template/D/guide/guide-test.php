<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php  //if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php //} ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">

	</style>
</head>
<body>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">본문 바로가기</a>
		<a href="#">네비게이션 바로가기</a>
	</div>
	<!--header-->
	<div id="header">
		<div class="top_img"></div>
		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/4be5b8353216f435a654cb73673ff61e.png" alt="INTOON (주)인투온" /></a></h1>
			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>" class="<?php echo $this->uri->segment(1) == 'guide'&& $pg->path=='/guide' ? 'active':''?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->
				<!--tm-->
				<div id="tm">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">회원정보 수정</a></li>
						<?php } ?>
						<li><a href="/board">공지사항</a></li>
						<li><a href="/member/counseling">상담문의</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">로그아웃</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">로그인</a></li>
						<?php } ?>
					</ul>
				</div>
				<!--tm-->
			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->
	<div class="menu_bg"></div>
	<!--//header-->
	<!--container-->
	<div id="container">
		<!--    	<h2>심포지엄 소개</h2>-->
		<!--wrap-->
		<div class="wrap">
			<h3 class="generalBasic" id="data-idx2">심포지엄</h3>
			<h3 class="colortit generalBasic" id="data-idx3"> 이용안내</h3>
			<p>Symposium Manual</p>
			<ol>
				<li><a href="/main" class="generalBasic" id="data-idx4">Symposium Home</a></li>
				<li><a href="#" class="generalBasic" id="data-idx5">심포지엄 이용안내</a></li>
			</ol>
			<!--w_box-->
			<div class="top_supis"></div>

			<!--w_box-->
			<div class="w_box">
				<h4 class="aboutit generalBasic" id="data-idx6">모바일 접속 안내</h4>
				<!--guide-->
				<div class="guide">
					<div class="ph"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>/images/m1d.png" alt="INTOON 인투온" /></div>
					<div class="tx">
						<h4 class="generalBasic" id="data-idx8">모바일 어플리케이션 다운로드 및 설치</h4>
						<p class="generalBasic" id="data-idx9">아이폰 앱스토어 및 안드로이드마켓에서 Adobe Connect Mobile로 검색하여 어플리케이션을 다운로드하거나 아래 QR code를 통하여 어플리케이션을 바로 다운로드 하실 수 있습니다.</p>
						<div class="qr_box">
							<img src="<?php echo IMG_DIR.$layout->template?>/images/qr_d.png" alt="qr_code"/>
						</div>

					</div>
				</div>
				<!--//guide-->
			</div>
			<!--//w_box-->
			<div class="guider"></div>
			<!--        	<h3 class="fc_grey">심포지엄 소개<span>Introduce Symposium</span></h3>-->
			<!--w_box-->
			<div class="w_box">
				<!--guide-->
				<div class="guide b_line">
					<div class="ph"><img class="generalImg" id="data-idx10" src="<?php echo IMG_DIR.$layout->template?>/images/m2d.png" alt="" /></div>
					<div class="tx">
						<h4 class="generalBasic" id="data-idx11">모바일 심포지엄 참가방법</h4>
						<p class="pointp generalBasic" id="data-idx12">1. 심포지엄 입장버튼 클릭</p>
						<p>&nbsp;</p>
						<p class="generalBasic" id="data-idx13">홈페이지에 로그인 하신 후, '심포지엄 입장' 빨간 버튼을 클릭하여 강의실에 입장합니다.</p>
						<p>&nbsp;</p>
						<p class="pointq generalBasic" id="data-idx14">※ 홈페이지 로그인 방법</p>
						<p>&nbsp;</p>
						<p class="generalBasic" id="data-idx15">1. 이메일로 전송된 초청장 내 접속 버튼을 통하여 사이트에 입장<br />
							2. SMS로 전달받은 고유번호를 ID/PW 란에 동일하게 입력<br />
							3. Guest Login 탭에서 간단한 정보 입력 후 로그인</p>
					</div>
				</div>
				<!--//guide-->
				<div class="guider2"></div>
				<!--guide-->
				<div class="guide b_line">
					<div class="ph"><img class="generalImg" id="data-idx16" src="<?php echo IMG_DIR.$layout->template?>/images/m3d.png" alt="" /></div>
					<div class="tx">
						<p class="pointp2 generalBasic" id="data-idx17">2. 강의실 입장 후 강의 시청</p>
						<p>&nbsp;</p>
						<p class="generalBasic" id="data-idx18">컨퍼런스 접속 후 강의를 시청하시면 됩니다.<br />
							좌측 탭을 통하여 다양한 화면모드로 보실 수 있으며, 질문 및 투표 참여가 가능합니다.</p>
					</div>
				</div>
				<!--//guide-->
				<!--guide-->
				<div class="guide ghp">
					<div class="ph"><img class="generalImg" id="data-idx19" src="<?php echo IMG_DIR.$layout->template?>/images/m4d.png" alt="" /></div>
					<div class="tx">
						<p class="pointp2 generalBasic" id="data-idx20">Chrome 브라우저의 경우</p>
						<p>&nbsp;</p>
						<p class="generalBasic" id="data-idx21">모바일에서 크롬 브라우저를 사용하시는 경우, 강의실 접속 전 좌측 이미지와 같은 화면이 나오게 됩니다.</p>
						<span>이 때, 아래 버튼인</span><span class="pointq"> Open Adobe Connect Mobile</span><span> 버튼을 누르시면 강의실로 접속이 됩니다.</span><br /><span>Adobe Connect app이 설치되지 않으신 분은 위의 버튼인</span><span class="pointq"> Get Adobe Connect Mobile</span><span> 버튼을 눌러 어플을 먼저 설치해 주세요.</span>
					</div>
				</div>
				<!--//guide-->
			</div>
			<!--//w_box-->
			<div class="guider3"></div>
			<h3 class="fc_grey generalBasic" id="data-idx22">심포지엄 접속 안내</h3>
			<!--w_box-->
			<div class="w_box mhq">
				<!--guide-->
				<div class="guide">
					<dl>
						<dt class="generalBasic" id="data-idx23">1. 참가신청</dt>
						<dd class="generalBasic" id="data-idx24">담장자및 심포지엄 사이트를 통하여 참가신청을 합니다.</dd>
					</dl>
					<dl>
						<dt class="generalBasic" id="data-idx25">2. 초대장 확인</dt>
						<dd class="generalBasic" id="data-idx26">발송해 드린 초대장을 확인하여 심포지엄의 내용을 확인합니다. 초청장 내 '심포지엄 사이트 입장하기'를 클릭하여 심포지엄 사이트에 입장합니다.</dd>
					</dl>
					<dl>
						<dt class="generalBasic" id="data-idx27">3. 사이트 입장</dt>
						<dd class="generalBasic" id="data-idx28">심포지엄 사이트에 들어 오셔서 심포지엄에 대한 자세한 사항을 확인합니다.</dd>
					</dl>
					<dl>
						<dt class="generalBasic" id="data-idx29">4. 심포지엄 참가</dt>
						<dd class="generalBasic" id="data-idx30">메인 화면의 ‘심포지엄 입장’ 버튼을 클릭하여 심포지엄에 입장하시고 강의를 시청합니다.</dd>
					</dl>
					<dl>
						<dt class="generalBasic" id="data-idx31">5. 질문/투표/설문</dt>
						<dd class="generalBasic" id="data-idx32">강의 종료후 Q&amp;A, 투표 및 설문에 참여 합니다.</dd>
					</dl>
				</div>
				<!--//guide-->
			</div>
			<!--//w_box-->
		</div>
		<!--//wrap-->
	</div>
	<!--//container-->
	<!--footer-->
	<div id="footer">
		<!--wrap-->
		<div class="foot_top">
			<h3 class="generalBasic" id="data-idx33">Symposium</h3>
			<p class="generalBasic" id="data-idx34">이제는 심포지엄 인터넷으로 참여하는 시대 인투온을 통해 편리하게 소통하세요</p>
		</div>
		<div class="wrap">
			<div class="logo"><a href="/main"><img class="generalBasic" id="data-idx35" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
			<div class="info">
				<dl>
					<dt class="generalBasic" id="data-idx36">인투온제약(주)</dt>
					<dd class="generalBasic" id="data-idx37">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
				</dl>
				<dl>
					<dt class="generalBasic" id="data-idx38">인투온약품(주)</dt>
					<dd class="generalBasic" id="data-idx39">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
				</dl>
			</div>
			<div class="code generalBasic" id="data-idx27">GCMA COME : PP-PNA-ABT-0056</div>
		</div>
		<!--//wrap-->
	</div>
	<!--//footer-->
</div>
<div class="full_screen_video">
	<img src="<?php echo IMG_DIR.$layout->template?>images/sph780x414.jpg" alt="" />
	<h3>SEPSIS 심포지엄</h3>
	<a href="#self" class="bt_i bt_full_screen_off">전체화면 끄기</a>
</div>

<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">테스트 페이지 적용</button>
	<button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
