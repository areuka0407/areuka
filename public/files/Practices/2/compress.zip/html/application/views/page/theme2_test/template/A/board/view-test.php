<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php  //if(@$this->session->userdata('idmanagers')!=''){?>
        <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
    <?php // } ?>
    <script type="text/javascript">

    </script>
    <style type="text/css">
    </style>
</head>
<body>
<div id="wrap_off">
    <div id="wrap">
        <!--header-->
        <div id="header">
            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <?php foreach($pages as $pg){?>
                                <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->
                    <!--tm-->
                    <div id="tm">
                        <ul>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                                <li><a href="/member/login">로그인</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--tm-->
                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <div class="menu_bg"></div>
        <!--//header-->
        <!--container-->
        <div id="container">
            <h2 class="generalBasic" id="data-idx2">심포지엄 공지사항</h2>
            <!--wrap-->
            <div class="wrap">
                <h3 class="generalBasic" id="data-idx3">공지사항</h3>
                <!--w_box-->
                <div class="w_box">
                    <!--board-->
                    <div class="board">
                        <table class="tb_board view">
                            <caption class="generalBasic" id="data-idx4">
                                공지사항 리스트
                            </caption>
                            <colgroup>
                                <col width="" />
                            </colgroup>
                            <thead>
                            <tr>
                                <th scope="col">번호</th>
                                <th scope="col">제목</th>
                                <th scope="col">작성자</th>
                                <th scope="col">날짜</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?php echo $detail->idarticle?></td>
                                <td class="tit"><span>[공지사항]</span><?php echo $detail->title?></td>
                                <td><?php echo $writer->name?></td>
                                <td><?php echo mdate("%Y. %m. %d", human_to_unix($detail->regDate));?></td>
                            </tr>
                            </tbody>
                        </table>
                        <div class="con_tx">
                            <?php echo nl2br($detail->content)?>
                            <br />
                            <!-- <img src="<?php echo IMG_DIR.$layout->template?>/images/preparing.jpg" alt="페이지 준비중입니다. 이용에 불편을 드려 죄송합니다. 빠른 시일내에 컨텐츠를 준비하도록 하겠습니다." class="mo" />-->
                        </div>
                        <div class="tc"><a href="/board/lists" class="bt_txt bt_list">목록</a></div>
                    </div>
                    <!--//board-->
                </div>
                <!--//w_box-->
            </div>
        </div>
        <!--//wrap-->
    </div>
    <!--//container-->
    <!--footer-->
    <div id="footer">
        <!--wrap-->
        <div class="wrap">
            <div class="logo"><a href="/main"><img class="generalImg" id="data-idx5" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
            <div class="info">
                <dl>
                    <dt class="generalBasic" id="data-idx6">인투온제약(주)</dt>
                    <dd class="generalBasic" id="data-idx7">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                </dl>
                <dl>
                    <dt class="generalBasic" id="data-idx8">인투온약품(주)</dt>
                    <dd class="generalBasic" id="data-idx9">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                </dl>
                <div class="generalBasic" id="data-idx10">GCMA COME : PP-PNA-ABT-0056</div>
            </div>
        </div>
        <!--//wrap-->
    </div>
    <!--//footer-->
</div>
<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
    <input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
    <input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
    <input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
    <input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
    <input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
    <input type="hidden" name="o_content" id="o_content" value="" />
    <input type="hidden" name="c_content" id="c_content" value="" />
    <button class="test-save" type="submit">테스트 페이지 적용<button>
    <button class="real-save">원본 페이지 적용</button>
</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
