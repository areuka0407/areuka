<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
    <title><?php echo $layout->name?></title>
    <link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
    <?php // if(@$this->session->userdata('idmanagers')!=''){?>
        <link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js2"></script>
    <?php // } ?>
    <script type="text/javascript">

    </script>
    <style type="text/css">

    </style>
</head>
<body>
<div id="wrap_off">
    <div id="wrap">
        <!--header-->
        <div id="header">
            <!--wrap-->
            <div class="wrap">
                <h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
                <a href="#self" id="bt_menu"><i></i><i></i><i></i><i></i>메뉴 열기</a>
                <!--menu-->
                <div id="menu">
                    <!--gnb-->
                    <div id="gnb">
                        <ul>
                            <?php foreach($pages as $pg){?>
                                <li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--//gnb-->
                    <!--tm-->
                    <div id="tm">
                        <ul>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/modify">회원정보 수정</a></li>
                            <?php } ?>
                            <li><a href="/board">공지사항</a></li>
                            <li><a href="/member/counseling">상담문의</a></li>
                            <?php if(@$this->session->userdata('logged_in')==true){?>
                                <li><a href="/member/logout">로그아웃</a></li>
                            <?php }else{ ?>
                                <li><a href="/member/login">로그인</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!--tm-->
                </div>
                <!--//menu-->
            </div>
            <!--//wrap-->
        </div>
        <div class="menu_bg"></div>
        <!--//header-->
        <!--container-->
        <div id="container">
            <h2 class="generalBasic" id="data-idx2">상담문의</h2>
            <!--wrap-->
            <div class="wrap">
                <h3>상담문의</h3>
                <!--w_box-->
                <div class="w_box">
                    <form name="counseling" id="counselingForm" method="post">
                        <!--member-->
                        <div class="member">
                            <h4 class="tc mb30">상담문의 내용 입력<span class="must"><i>＊</i> 필수 입력항목 입니다.</span></h4>
                            <div class="form">
                                <dl>
                                    <dt><i>*</i>성함</dt>
                                    <dd><input type="text" name="name" id="name" placeholder="성함을 입력해주세요."  value="<?php echo @$this->session->userdata('name')? $this->session->userdata('name'): '';?>"/></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>이메일</dt>
                                    <dd><input type="text" name="email" id="email" placeholder="연락 받으실 이메일을 입력해주세요." value="<?php echo @$this->session->userdata('email')? $this->session->userdata('email'): '';?>"/></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>전화번호</dt>
                                    <dd><input type="text" name="tel" id="tel" placeholder="연락 받으실 전화번호를 입력해주세요." value="<?php echo @$this->session->userdata('phone')? $this->session->userdata('phone'): '';?>"/></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>제목</dt>
                                    <dd><input type="text" name="title" id="title" placeholder="제목을 입력해주세요." /></dd>
                                </dl>
                                <dl>
                                    <dt><i>*</i>내용</dt>
                                    <dd><textarea name="content" id="content"></textarea></dd>
                                </dl>
                            </div>
                            <p class="tc"><a href="#" class="bt_txt bt_bot">상담하기</a></p>
                        </div>
                        <!--//member-->
                    </form>
                </div>
                <!--//w_box-->
            </div>
            <!--//wrap-->
        </div>
        <!--//container-->
        <!--footer-->
        <div id="footer">
            <!--wrap-->
            <div class="wrap">
                <div class="logo"><a href="/main"><img class="generalImg" id="data-idx4" src="<?php echo IMG_DIR.$layout->template?>/images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
                <div class="info">
                    <dl>
                        <dt class="generalBasic" id="data-idx5">인투온제약(주)</dt>
                        <dd class="generalBasic" id="data-idx6">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
                    </dl>
                    <dl>
                        <dt class="generalBasic" id="data-idx7">인투온약품(주)</dt>
                        <dd class="generalBasic" id="data-idx8">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
                    </dl>
                    <div class="code generalBasic" id="data-idx9">GCMA COME : PP-PNA-ABT-0056</div>
                </div>
            </div>
        </div>
        <!--//wrap-->
    </div>
    <!--//footer-->
    <script>
        $(document).ready(function(){
            $('.bt_bot').on('click', function(){
                if($('#name').val()==""){
                    alert('이름을 입력해주세요.');
                    $('#name').focus();
                    return false;
                }else if($('#email').val()==""){
                    alert('이메일을 입력해주세요.');
                    $('#email').focus();
                    return false;
                }else if($('#tel').val()==""){
                    alert('전화번호를 입력해주세요.');
                    $('#tel').focus();
                    return false;
                }else if($('#title').val()==""){
                    alert('제목를 입력해주세요.');
                    $('#title').focus();
                    return false;
                }else if($('#content').val()==""){
                    alert('내용을 입력해주세요.');
                    $('#content').focus();
                    return false;
                }else{
                    $('#counselingForm').submit();
                }
            });
        });
    </script>
</div>
<form method="post"  enctype="multipart/form-data" action="/main/set_modify_theme">
        <input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
        <input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
        <input type="hidden" name="_file" value="test.php"/>
        <input type="hidden" name="o_content" id="o_content" value="" />
        <input type="hidden" name="c_content" id="c_content" value="" />
        <button class="inton-save">최종수정하기<button>
	</form>
<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
