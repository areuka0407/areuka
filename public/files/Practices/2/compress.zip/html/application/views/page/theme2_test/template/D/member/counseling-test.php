<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0" />
	<title><?php echo $layout->name?></title>
	<link href="<?php echo CSS_DIR.$layout->template?>/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/default.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo CSS_DIR.$layout->template?>/css/media.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_DIR.$layout->template?>/js/layout.js"></script>
	<?php // if(@$this->session->userdata('idmanagers')!=''){?>
		<link href="<?php echo CSS_DIR?>/css/inton-modal.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo JS_DIR?>js/admin.js"></script>
	<?php //} ?>
	<script type="text/javascript">

	</script>
	<style type="text/css">

	</style>

	<script type="text/javascript">
		$(document).ready(function(){
			$('.bt_bot').on('click', function(){
				if($('#name').val()==""){
					alert('이름을 입력해주세요.');
					$('#name').focus();
					return false;
				}else if($('#email').val()==""){
					alert('이메일을 입력해주세요.');
					$('#email').focus();
					return false;
				}else if($('#tel').val()==""){
					alert('전화번호를 입력해주세요.');
					$('#tel').focus();
					return false;
				}else if($('#title').val()==""){
					alert('제목를 입력해주세요.');
					$('#title').focus();
					return false;
				}else if($('#content').val()==""){
					alert('내용을 입력해주세요.');
					$('#content').focus();
					return false;
				}else{
					$('#counselingForm').submit();
				}
			});
		});
	</script>
</head>
<body>
<form id="save_form" method="post"  enctype="multipart/form-data" action="/<?= $this->uri->segment(1) ?>/set_modify_theme">
	<input type="hidden" name="_current_url" value="<?= $_SERVER['REQUEST_URI'] ?>">
	<input type="hidden" name="_relative_path" value="<?= $layout->relativePath ?>">
	<input type="hidden" name="_templeate" value="<?php echo $layout->template; ?>"/>
	<input type="hidden" name="_segment" value="<?php echo $this->uri->segment(1);?>"/>
	<input type="hidden" name="_file" value="<?= mb_substr(__FILE__, mb_strlen(__DIR__) + 1) ?>"/>
	<input type="hidden" name="o_content" id="o_content" value="" />
	<input type="hidden" name="c_content" id="c_content" value="" />
	<button class="test-save" type="submit">테스트 페이지 적용</button>
	<button class="real-save">원본 페이지 적용</button>
</form>
<div id="wrap">
	<div class="skip_nav">
		<a href="#">본문 바로가기</a>
		<a href="#">네비게이션 바로가기</a>
	</div>
	<!--header-->
	<div id="header">
		<div class="top_img"></div>
		<!--wrap-->
		<div class="wrap">
			<h1><a href="/main"><img class="generalImg" id="data-idx1" src="<?php echo IMG_DIR.$layout->template?>/images/logo.png" alt="INTOON (주)인투온" /></a></h1>
			<!--menu-->
			<div id="menu">
				<!--gnb-->
				<div id="gnb">
					<ul>
						<?php foreach($pages as $pg){?>
							<li><a href="<?php echo  $pg->path;?>"><?php echo $pg->title; ?></a></li>
						<?php } ?>
					</ul>
				</div>
				<!--//gnb-->
				<!--tm-->
				<div id="tm">
					<ul>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/modify">회원정보 수정</a></li>
						<?php } ?>
						<li><a href="/board">공지사항</a></li>
						<li><a href="/member/counseling">상담문의</a></li>
						<?php if(@$this->session->userdata('logged_in')==true){?>
							<li><a href="/member/logout">로그아웃</a></li>
						<?php }else{ ?>
							<li><a href="/member/login">로그인</a></li>
						<?php } ?>
					</ul>
				</div>
				<!--tm-->
			</div>
			<!--//menu-->
		</div>
		<!--//wrap-->
	</div>
	<!--//header-->
	<div class="menu_bg"></div>
	<!--//header-->
	<!--container-->
	<div id="container">
		<!--    	<h2>상담문의</h2>-->
		<!--wrap-->
		<div class="wrap">
			<h3 class="generalBasic" id="data-idx2">심포지엄</h3>
			<h3 class="colortit generalBasic" id="data-idx3"> 상담문의</h3>
			<p>Customer Center</p>
			<ol>
				<li><a href="/main">Symposium Home</a></li>
				<li><a href="/counseling">상담문의</a></li>
			</ol>
			<!--w_box-->
			<div class="top_supis"></div>
			<div class="w_box">
				<!--member-->
				<form name="counseling" id="counselingForm" method="post">
					<div class="member">
						<h4 class="tc mb10 generalBasic" id="data-idx4">상담문의 내용 입력</h4>
						<p class="must"><i>＊</i> 필수 입력항목 입니다.</p>
						<div class="form">
							<dl>
								<dt><span class="spa"><i>＊</i>성함</span></dt>
								<dd><input class="idcon1" type="text" name="name" id="name" placeholder="성함을 입력해주세요." value="<?php echo @$this->session->userdata('name')? $this->session->userdata('name'): '';?>"/></dd>
							</dl>
							<dl>
								<dt><span class="spa"><i>＊</i>이메일</span></dt>
								<dd><input class="idcon4" type="text" name="email" id="email" placeholder="이메일을 입력해주세요" value="<?php echo @$this->session->userdata('email')? $this->session->userdata('email'): '';?>"/></dd>
							</dl>
							<dl>
								<dt><span class="spa"><i>＊</i>전화번호</span></dt>
								<dd><input class="idcon5" type="text" name="tel" id="tel" placeholder="연락처를 정확히 입력해주세요" value="<?php echo @$this->session->userdata('phone')? $this->session->userdata('phone'): '';?>"/></dd>
							</dl>
							<dl>
								<dt><span class="spa"><i>＊</i>제목</span></dt>
								<dd><input type="text"  name="title" id="title" placeholder="제목을 입력해주세요" /></dd>
							</dl>
							<dl>
								<dt><span class="spa"><i>＊</i>내용</span></dt>
								<dd><textarea  name="content" id="content" placeholder="내용을 입력해주세요"></textarea></dd>
							</dl>
						</div>
						<p class="tc"><a href="#" class="bt_txt bt_bot">문의하기</a></p>
					</div>
					<!--//member-->

			</div>
			<!--//w_box-->
		</div>
		<!--//wrap-->
	</div>
	<!--//container-->
	<!--footer-->
	<div id="footer">
		<!--wrap-->
		<div class="foot_top">
			<h3 class="generalBasic" id="data-idx5">Symposium</h3>
			<p class="generalBasic" id="data-idx6">이제는 심포지엄 인터넷으로 참여하는 시대 인투온을 통해 편리하게 소통하세요</p>
		</div>
		<div class="wrap">
			<div class="logo"><a href="/main"><img class="generalImg" id="data-idx7" src="<?php echo IMG_DIR.$layout->template?>images/logo_f.png" alt="INTOON (주)인투온" /></a></div>
			<div class="info">
				<dl>
					<dt class="generalBasic" id="data-idx8">인투온제약(주)</dt>
					<dd class="generalBasic" id="data-idx9">서울시 용산구 백범로 341 금호리첸시아 A블럭 2층 / 제품문의 02-2285-2526 / <a href="http://into-on.com/" target="_blank">www.into-on.com</a></dd>
				</dl>
				<dl>
					<dt class="generalBasic" id="data-idx10">인투온약품(주)</dt>
					<dd class="generalBasic" id="data-idx11">경기도 김포시 월곶면 애기봉로 392-11 / 제품문의 031-996-8530 ~ 8538 / <a href="#self">www.into-on.co.kr</a></dd>
				</dl>
			</div>
			<div class="code generalBasic" id="data-idx27">GCMA COME : PP-PNA-ABT-0056</div>
		</div>
		<!--//wrap-->
	</div>
	<!--//footer-->
</div>

<?php $this->load->view("/manager/config/configPopUp"); ?>
</body>
</html>
