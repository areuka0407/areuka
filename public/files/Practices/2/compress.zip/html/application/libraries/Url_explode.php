<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class Url_explode
{
  public function __construct()
  {
    $CI = & get_instance();
  }

  function _explode($url, $key)
  {
      $cnt = count($url);
      for($i=0; $cnt>$i; $i++ )
      {
          if($url[$i] ==$key)
          {
              $k = $i+1;
              return $url[$k];
          }
      }
  }
}