<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class Segment_explode
{
  public function __construct()
  {
    $CI = & get_instance();
  }

  function _explode($seg)
    {
        //세크먼트 앞뒤 '/' 제거후 uri를 배열로 반환
        $len = strlen($seg);
        if(substr($seg, 0, 1) == '/')
        {
            $seg = substr($seg, 1, $len);
        }
        $len = strlen($seg);
        if(substr($seg, -1) == '/')
        {
            $seg = substr($seg, 0, $len-1);
        }
        $seg_exp = explode("/", $seg);
        return $seg_exp;
    }
}