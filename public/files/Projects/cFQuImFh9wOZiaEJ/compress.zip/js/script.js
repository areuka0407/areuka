$("nav > ul > li").hover(
	function(){
		if( $(this).children("ul").is(":animated") ){
			 return;
		}
		$(this).children("ul").slideDown();
	},
	function(){
		$(this).children("ul").slideUp("fast");
	}
);
$(".history").hide();
$(".building").hide();
$(".review").hide();
$(".four").hide();
$(".rkr").hide();
$(".wkd").hide();
var page = 1;
$("#hm").click(function(){
	// alert("asdf1");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 1;
	$(".home").show();
});
$("#hi").click(function(){
	// alert("asdf2");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 2;
	$(".history").show();
});
$("#bu").click(function(){
	// alert("asdf3");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 3;
	$(".building").show();
});
$("#bu1").click(function(){
	// alert("asdf3");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 5;
	$(".four").show();
});
$("#bu2").click(function(){
	// alert("asdf3");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 6;
	$(".rkr").show();
});
$("#bu3").click(function(){
	// alert("asdf3");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 7;
	$(".wkd").show();
});
$("#re").click(function(){
	// alert("asdf4");
	if(page == 1){
		$(".home").hide();
	} else if(page == 2){
		$(".history").hide();
	} else if(page == 3){
		$(".building").hide();
	} else if(page == 4){
		$(".review").hide();
	} else if(page == 5){
		$(".four").hide();
	} else if(page == 6){
		$(".rkr").hide();
	} else if(page == 7){
		$(".wkd").hide();
	}
	page = 4;
	$(".review").show();
});

var slide = $("header > img");
var max = slide.length - 1;
var sn = 0;

function slider() {
	$( slide[sn] ).siblings("img").css({
		left : "-1000px",
		opacity : 0
	});

	$( slide[sn] ).animate({
		left : "1000px",
		opacity : 0
	}, 1000,
	function(){
		$(this).css({left: "-1000px"});
		}
	);
	sn=sn+1
	if(sn>max)
		sn=0;
		$( slide[sn] ).animate({
			left: "0",
			opacity : 1
		}, 1000);
}

var timer = setInterval(function(){
	slider();
}, 4000);