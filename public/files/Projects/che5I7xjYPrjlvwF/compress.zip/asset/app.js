let key = '3pDIIZgfittdCVQaNEIgpl0vITLPMjzVOHkMaj0BeUDpzmAar3OFc02Z4gZWasUGXoCkXu1GSX6mhanq917U0w%3D%3D';


function Pager(nowPage, totalCnt){
    let block = 5;
    this.totalPage = Math.ceil(totalCnt/10);
    this.end = Math.ceil(nowPage / block) * block;
    this.start = this.end - block + 1;

    this.next = true;
    this.prev = true;

    if(this.start <= 1){
        this.start = 1;
        this.prev = false;
    }

    if(this.end >= this.totalPage){
        this.end = this.totalPage;
        this.next = false;
    }
}


function getAreaCd(now = '1'){
    let url = 'http://openapi.epost.go.kr/postal/retrieveLotNumberAdressAreaCdService/retrieveLotNumberAdressAreaCdService/'; /*URL*/
    let queryParams = '?' + encodeURIComponent('ServiceKey') + '='+ key; /*Service Key*/
// console.log(url+queryParams);
    $("tbody").empty();
    url += 'getDetailListAreaCd';
    queryParams += '&' + encodeURIComponent('searchSe') + '=' + encodeURIComponent($("#searchSe").val());
    queryParams += '&' + encodeURIComponent('srchwrd') + '=' + encodeURIComponent($("#srchwrd").val());
    queryParams += '&' + encodeURIComponent('countPerPage') + '=' + encodeURIComponent('10');
    queryParams += '&' + encodeURIComponent('currentPage') + '=' + encodeURIComponent(now);
    $.get(url+queryParams, function(result){
        let codes = $(result).find("detailListAreaCd");
        console.log(codes);
        if(codes.length > 0){
            for(let i = 0; i<codes.length; i++){
                let number = $(codes[i]).find('no').text();
                let zipNo = $(codes[i]).find('zipNo').text();
                let adres = $(codes[i]).find('adres').text();
                let html = `<tr>
                            <td>${number}</td>
                            <td>${zipNo}</td>
                            <td>${adres}</td>
                        </tr>`;
                $("tbody").append(html);
                $(".search_container").fadeOut(1000);
                $(".view_container").fadeIn(1000);
            }

            let nowPage = $(result).find("currentPage").text();
            let totalCount = $(result).find("totalCount").text();
            let pager = new Pager(nowPage, totalCount);

            let prev = pager.prev ? "onclick=\"getAreaCd("+ (pager.start - 1) +")\"" : '' ;
            console.log(pager.totalPage);

            let next = pager.next ? "onclick=\"getAreaCd("+ (pager.end + 1) +")\"" : '';

            let html = `<a ${prev}>&laquo;</a>`;
            for(let i = pager.start ; i<=pager.end; i++){
                html += `<a onclick="getAreaCd(${i})">${i}</a>`
            }
            html += `<a ${next}>&raquo;</a>`
            $(".pagination").empty();
            $(".pagination").append(html);
        } else {
            alert("해당 주소가 존재하지 않습니다.");
            location.reload();
        }
    });
}

function resetAreaCd(){
    $(".view_container").fadeOut(1000);
    $(".search_container").fadeIn(1000);
    // $("tbody").empty();
    // $(".pagination").empty();
}


window.onload = function(){
};