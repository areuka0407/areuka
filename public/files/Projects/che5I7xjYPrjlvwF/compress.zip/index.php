<!--유승열 교수님 E-mail : asimryu@gmail.com-->
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>지번주소 조회서비스</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="asset/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
</head>
<body>
    <div id="wrap">
        <div class="search_container" >
            <div id="search_wrap">
                <span class="title">지번주소 조회하기</span>
                <form onsubmit="return false" id="form_wrap">
                    <div class="form_input_wrap">
                        <span class="form_title">검색 구분</span>
                        <select name="searchSe" id="searchSe" class="form_input">
                            <option value="dong">동/읍/면</option>
                            <option value="post">우편번호</option>
                            <option value="sido">시/군/구</option>
                        </select>
                    </div>
                    <div class="form_input_wrap">
                        <span class="form_title">검색어 입력</span>
                        <input type="text" id="srchwrd" placeholder="검색어" class="form_input">
                    </div>
                    <button id="form_btn" onclick="getAreaCd()">조회하기</button>
                </form>
                <img src="asset/apartment.PNG" alt="apart" width="200px" height="250px">
            </div>
        </div>
        <div class="view_container" style="display: none">
            <div id="view_wrap">
                <table id="view_table">
                    <thead>
                    <tr>
                        <th>번호</th>
                        <th>우편번호</th>
                        <th>지번주소</th>
                    </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
                <div id="pagination_wrap">
                    <div class="pagination">
<!--                        <a>&laquo;</a>-->
<!--                        <a>1</a>-->
<!--                        <a>2</a>-->
<!--                        <a>3</a>-->
<!--                        <a>4</a>-->
<!--                        <a>5</a>-->
<!--                        <a>&raquo;</a>-->
                    </div>
                </div>
            </div>
            <span id="view_reset" onclick="resetAreaCd()">
                <i class="fas fa-undo"></i>
            </span>
        </div>
    </div>
    <script src="asset/app.js"></script>
</body>
</html>
<!--유승열 교수님 E-mail : asimryu@gmail.com-->