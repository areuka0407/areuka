<?php
header("Content-Type:application/json");
if(isset($_GET['query'])) {
    $query = $_GET['query'];
    $news = "http://newssearch.naver.com/search.naver?where=rss&query={$query}&field=0&nx_search_query=&nx_and_query=&nx_sub_query=&nx_search_hlquery=&is_dts=0";
    $xml = simplexml_load_file($news);

    $channel = $xml->channel;
    $newslist = $channel->item;
    $data = array();
    $no = 0;
    foreach( $newslist as $news ){
//        var_dump($news->description);
//        $thumb = "";
//        if($news->children('media', true)){
//            $thumb =  $news->children('media', true)->thumbnail->attributes()->url;
//        }

        //print_r($news);
//        $namespaces = $news->getNamespaces(true); // get namespaces
//        if($news->children($namespaces['media'])) {
//            echo $news->children($namespaces['media'])->thumbnail->attributes()->url;
//        }
//        var_dump($news);

        $data[$no] = array(
                'title'=> $news->title,
                'author'=>$news->author,
                'link'=>$news->link,
                'category' => $news->category,
                'pubDate' => $news->pubDate,
                'thumb' => $news->children('media', true) ? $news->children('media', true)->thumbnail->attributes()->url : "",
                'content'=>str_replace('<![CDATA[', '', str_replace(']]>', '', $news->description))
            );
//        var_dump($data[$no]);
        $no++;

    }
}
echo json_encode($data, JSON_UNESCAPED_UNICODE);
