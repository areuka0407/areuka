<?php

    use src\App\Route;

    if(isset($_SESSION['user'])){
        Route::get("/", "MainController@index");
        Route::post("/", "MainController@index");
        Route::get("/logout", "MainController@logout");
        Route::post("/board/add", "MainController@board_write");
        Route::post("/board/delete", "MainController@board_delete");
        Route::post("/board/loadmore", "MainController@LoadMore");
        Route::post("/board/viewLoad", "MainController@ViewLoad");
        Route::post("/user/modify", "UserController@UserModify");
    } else {
        Route::get("/", "UserController@index");
        Route::post("/login", "UserController@login");
        Route::get("/register", "UserController@register");
        Route::post("/register/add", "UserController@register_ok");
        Route::post("/id_check", "UserController@id_check");
        Route::post("/category/add", "MainController@category_add");
    }