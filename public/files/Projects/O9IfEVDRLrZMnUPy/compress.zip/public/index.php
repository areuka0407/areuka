<?php
    session_start();
    use src\App\Route;

    ini_set('display_errors', '1');
    require("../autoload.php");
    require("../web.php");
    require("../src/lib.php");


    define("__SRC", dirname(__DIR__)."/src/");
    define("__ORIGIN", dirname(__DIR__));
    define("__PAGE", 5);

    Route::route();