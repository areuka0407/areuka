<?php
    function autoload($c){
        require __DIR__."/".$c.".php";
    }

    spl_autoload_register("autoload");