<?php

namespace src\App;

use src\Controller\MainController;

class Route
{
    public static $GET = [];
    public static $POST = [];
    public static function route(){
        $path = isset($_GET['url']) ? "/".$_GET['url'] : "/" ;

        foreach(self::${$_SERVER['REQUEST_METHOD']} as $req){
            if($req[0] === $path){
                $actions = explode("@", $req[1]);
                $controller = "src\\Controller\\" . $actions[0];
                $c = new $controller();
                $c->{$actions[1]}();
                return;
            }
        }

        $c = new MainController;
        $c->error();
    }
    public static function get($link, $action){
        array_push(self::$GET, [$link, $action]);
    }

    public static function post($link, $action){
        array_push(self::$POST, [$link, $action]);
    }
}