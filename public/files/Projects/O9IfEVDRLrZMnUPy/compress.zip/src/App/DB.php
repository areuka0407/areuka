<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2018-10-29
 * Time: 오후 7:01
 */

namespace src\App;


class DB
{
    private static $db = null;

    private static function getDB(){
        if(self::$db == null){
            self::$db = new \PDO("mysql:host=localhost; dbname=dinecto; charset=utf8mb4", "root", "");
        }
        return self::$db;
    }

    public static function fetch($sql, $data = []){
        $q = self::getDB()->prepare($sql);
        $q->execute($data);
        return $q->fetch(\PDO::FETCH_OBJ);
    }

    public static function fetchAll($sql, $data=[]){
        $q = self::getDB()->prepare($sql);
        $q->execute($data);
        return $q->fetchAll(\PDO::FETCH_OBJ);
    }

    public static function execute($sql, $data=[]){
        $q = self::getDB()->prepare($sql);
        $q->execute($data);
    }

    public static function lastId(){
        return self::getDB()->lastInsertId();
    }

    public static function rowCount($sql, $data = []){
        $q = self::getDB()->prepare($sql);
        $q->execute($data);
        return $q->rowCount();
    }
}