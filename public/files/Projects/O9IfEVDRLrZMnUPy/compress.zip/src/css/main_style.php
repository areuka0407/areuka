<style>
    body {
        background-color: #ffffff;
    }

    /*header*/


    #header {
        width: 100%;
        height: 60px;
        background-color: #fcfcfc;
        border-bottom : 1px solid #e7e7e7 ;
        display: flex;
        justify-content : center;
        align-items : center;
        position : fixed;
        left: 0;
        top: 0;
        z-index : 1000;
        box-shadow : 0 2px 5px #e7f0ef;
    }

    #header #logo {
        font-size : 30px;
        color : #2892a3;
        font-weight: bold;
        text-decoration: none;
    }


    /*message*/


    #message {
        width: 100%;
        height: 100px;
        position: fixed;
        top: 100px;
        left: 0;
        display: none;
    }

    #message_box {
        display: none;
        z-index: 999;
        color: #676767;
        font-size: 18px;
        max-width: 600px;
        min-width: 350px;
        height: 55px;
        background-color: #fcffff;
        text-align: center;
        line-height: 20px;
        padding: 15px 30px 15px 30px;
        margin : 0 auto;
        border: #f3f3f3 solid 2px;
        border-radius: 15px;
        position : relative;
        box-shadow : 0 2px 3px #e1e4e4;
    }



    /*side_content*/


    #side_content {
        width: 400px;
        height: 100%;
        position : fixed;
        top : 60px;
        left : 0;
        background-color: #f7f7f7;
    }

    #user_profile {
        position : relative;
        width: 100%;
        height: 600px;
    }

    #user_images {
        width: 100%;
        height : 250px;
        margin-bottom : 50px;
        position : relative;
        background-color: #fff;
    }
    
    #user_backImage {
        /*opacity: 0.5;*/
        width: 100%;
        height: 100%;
        display: flex;
        background-size : 100% 100%;
        justify-content : center;
        /*transition : 0.25s;*/
    }

    #user_profileImage {
        width: 200px;
        height: 200px;
        border : 5px #f7f7f7 solid ;
        border-radius : 100px;
        position: relative;
        top : 100px;
        background-color: #fff;
        z-index: 10;
    }

    #modify_close {
        display: none;
        position : absolute;
        left: 10px;
        top: 10px;
        color: #18635d;
        z-index: 100;
        font-size: 30px;
        cursor: pointer;
    }

    #modify_close:hover {
        opacity : 0.7;
    }

    #modify_list_btn {
        display: none;
        position : absolute;
        right : 15px;
        bottom: 15px;
        font-size: 35px;
        color : #18635d;
        cursor : pointer;
        text-shadow: 0 0 5px #a2b7b8;
        z-index: 100;
    }

    #modify_list_btn:hover {
        opacity: 0.7;
    }

    #modify_list {
        bottom: 20px;
        right: 60px;
        width: 200px;
        position : absolute;
        background-color: #fff;
        border-radius : 15px;
        z-index: 100;
        box-shadow : 1px 1px 5px #a2b7b8;
        display: none;
        text-align: center;
    }

    #modify_list label {
        display: block;
        height: 40px;
        line-height: 40px;
        border-bottom: #e1e1e1 solid 1px;
    }

    #modify_list label:first-child {
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }

    #header_modify {
        /*border-bottom: none;*/
        border-bottom-left-radius: 15px;
        border-bottom-right-radius: 15px;
    }

    #modify_list  label:hover {
        background-color: #2fa9a9;
        color: white;
    }

    #user_info {
        width: 100%;
        height: 300px;
        display: flex;
        flex-direction : column;
        padding : 0 50px 0 50px;
    }

    #user_name_wrap {
        margin : 0 auto;
        height: 40px;
        display: flex;
        justify-content : center;
    }

    #user_name {
        margin : 0 auto;
        font-size: 25px;
        color : #303030;
        position : absolute;
    }

    #user_name_input {
        display: none;
        position : absolute;
        /*display: none;*/
        width: 250px;
        height: 35px;
        font-size: 18px;
        text-align: center;
        padding: 3px 10px 3px 10px;
        color: #4d5551;
        border: #dadada 1px solid;
        box-shadow: 0 0 5px #dbd9d9;
        z-index: 11;
    }



    #user_id {
        margin : 0 auto;
        font-size : 16px;
        color : #9c9c9c;
    }

    #user_intro_wrap {
        display: flex;
        justify-content: center;
        padding: 10px;
        height: 200px;
    }

    #user_intro {
        width : 100%;
        height: 100px;
        line-height: 55px;
        text-align: center;
        padding: 10px;
        position : absolute;
    }

    #user_intro_input {
        display: none;
        margin-top: 25px;
        position :absolute;
        resize: none;
        width: 90%;
        min-height: 100px;
        padding: 10px;
        border: #dadada 1px solid;
        box-shadow: 0 0 5px #dbd9d9;
        z-index: 11;
    }

    #user_modify_btn {
        display: none;
        padding: 5px;
        box-shadow: 0 0 5px #dbd9d9;
        border: #dbd9d9 solid 1px;
        background-color: #f8f8f8;
        color: #1f5e68;
        font-size: 17px;
        text-align: center;
        border-radius: 20px;
        text-decoration: none;
        width: 150px;
        height: 50px;
        line-height: 35px;
        margin : 0 auto;
        transition : 0.3s;
        cursor : pointer;
        z-index: 11;
    }
    
    #user_modify_btn:hover {
        background-color: #39a69c;
        color: white;
    }

    #side_items {
        /*background-color: rgba(0, 0, 0, 0.4);*/
        width: 100%;
        height: 100%;
        position : absolute;
        z-index: 10;
        font-size: 26px;
        color : #239b91;
        text-shadow : 0 0 5px #2e2e2e;
        display: flex;
        flex-direction : row-reverse;
    }

    .side_item {
        cursor: pointer;
        margin : 20px;
        position : absolute;
        right: 0;
    }

    .side_item:hover {
        opacity : 0.7;
    }


    #open_side {
        font-size : 30px;
        display: none;
    }


    #side_popItems {
        width: 200px;
        position : absolute;
        right: 10px;
        top: 60px;
        background-color: #fff;
        border-radius : 15px;
        display: none;
        z-index: 100;
        box-shadow : 1px 1px 5px #a2b7b8;
    }

    .side_popItem:first-child {
        border-radius : 15px 15px 0 0;
    }

    .side_popItem {
        width: 100%;
        height: 40px;
        display : inline-block;
        border-bottom : #7e7e7e;
        text-align: center;
        line-height: 40px;
        cursor : pointer;
        color : black;
        text-decoration: none;
    }

    .side_popItem:last-child {
        border-radius : 0 0 15px 15px;
    }

    .side_popItem:hover {
        background-color: #2fa9a9;
        color: white;
    }


    /*main_content*/

    #main_content {
        margin-top : 60px;
        margin-left: 400px;
        /*min-height: 700px;*/
        min-height: 100%;
        display: flex;
        position : relative;
        overflow-x : hidden;
    }


    #content_wrap {
        background-color: #DFDFDF;
        width: 1400px;
    }


    #content_list {
        display: inline-block;
        box-sizing: content-box;
        width: 900px;
        min-height: 950px;
        margin-left: 100px;
        background-color: #f7f8f8;
        border-right: #d3e1e0 2px solid ;
    }


    /*category*/


    #category_wrap {
        width: 100px;
        height: 100%;
        background-color: #81b3ad;
        display : inline-flex;
        flex-direction: column;
        position : fixed;
        border-left: #58928b solid 1px;
        border-right: #58928b solid 1px;
        box-shadow: 10px 10px 10px #72a49e inset;
    }


    .category > button , .category > a {
        font-size: 15px;
        text-decoration: none;
        display: block;
        margin : 5px;
        width: 90px;
        height: 90px;
        padding: 10px;
        text-align: center;
        line-height: 70px;
        border-radius : 50px;
        cursor : pointer;
        box-shadow : 1px 1px 10px #5d8586;
    }

    .category > button:hover , .category > a:hover{
        opacity : 0.8;
    }




    /*form*/

    #form_box {
        background-color: #f7f8f8;
        width: 900px;
        min-height: 200px;
        padding : 10px 20px 30px 20px;
        display : flex;
        position: relative;
    }

    #form_black_box {
        display: none;
        width: 100%;
        height: 100%;
        position : absolute;
        top: 0;
        left: 0;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 10;
    }


        /*form > user*/

        .form_user {
            padding-top: 20px;
            width: 15%;
            height: 150px;
            display : inline-flex;
            flex-direction : column;
        }

        .form_userProfile {
            width: 100px;
            height: 100px;
            border-radius : 100px;
            border : 1px solid #cfcfcf;
            margin : 0 auto;
        }

        .form_user_name {
            margin :  0 auto;
            font-size: 18px;
            font-weight: lighter;
            color: #222e2b;
        }


        /*form > content */

        #form_content {
            width: 65%;
            display: inline-flex;
            flex-direction : column;
        }

        #form {
            width : 100%;
        }

        #comment {
            resize : none;
            padding: 5px 10px 5px 10px;
            width: 100%;
            margin: 10px 30px 0 30px;
            border : 1px solid #e6ecec;
        }

        #form_categories {
            width: 550px;
            margin: 10px 30px 0 30px;
            padding: 5px;
            display: flex;
            flex-wrap : wrap;
        }

        .form_category {
            display: inline-block;
            cursor : pointer;
            height: 40px;
            line-height: 25px;
            text-align: center;
            border : #a0a6ab solid 1px;
            padding: 5px 15px 5px 15px;
            border-radius: 15px;
            margin : 5px;
            font-size: 16px;
        }

        .form_category:hover {
            opacity: 0.8;
        }
        
        .cat_checked {
            background-color: #159088!important;
            color : white!important;
        }

        #preview_wrap {
            display: none;
            margin : 30px 0 10px 50px;
            padding: 5px;
            width: 550px;
            height: 120px;
            white-space:  nowrap;
            overflow-x : auto;
        }

        .preview_img:first-child {
            margin-left: 0;
        }

        .preview_img {
            margin: 0 21.6px 0 21.6px;
            width: 90px;
            height: 90px;
            border-radius : 20px;
            display: inline-flex;
            justify-content : center;
            align-items: center;
            position : relative;
        }


        .preview_img:last-child {
            margin-right: 0;
        }

        .preview_img > img {
            position : absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
            border-radius : 20px;
        }

        .preview_delete {
            position : absolute;
            font-size: 50px;
            color : #646464;
            display: none;
            pointer-events: none;
        }

        .preview_img:hover img{
            opacity : 0.5;
        }

        .preview_img:hover .preview_delete {
            display: block;
        }


        /*form > control*/


        #form_control {
            width : 20%;
            padding-left: 50px;
            height: 150px;
            display: flex;
            flex-direction : column;
        }

        #form_submit {
            margin : 20px 0 20px 0;
            padding: 15px;
            border-radius : 15px;
            font-size: 16px;
            border : 1px solid #e6ecec;
            background-color: #2fa9a9;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        #form_items {
            display: flex;
            justify-content: space-around;
        }

        .form_item {
            color: #2892a3;
            cursor: pointer;
            margin : 5px;
        }

        .form_item:hover {
            color : #1f5e68;
        }

        #form_label {
            font-size: 40px;
        }

        #form_poll {
            font-size: 35px;
            background-color: transparent;
            text-align : left;
        }


        /*board view*/

        .view_wrap {
            width: 900px;
            display: flex;
            padding: 10px 20px 30px 20px;
            background-color: #f7f8f8;
            border-top : 2px solid #DCDCDC;
            transition : 0.2s;
            cursor : pointer;
            position : relative;
        }

        .view_wrap:hover {
            background-color: #ffffff;
        }

        .view_content {
            padding: 30px 10px 10px 30px;
            width: 65%;
            height: 150px;
        }

        .view_images {
            margin-left: 30px;
            width: 15%;
            height: 150px;
            display: flex;
            justify-content :center;
            align-items: center;
            position : relative;
            top: 10px;
        }

        .view_images > img {
            background-color: #fff;
            width: 120px;
            height: 120px;
        }

        #view_images_cnt {
            position : absolute;
            font-size: 40px;
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            display: inline-flex;
            /*display : none;*/
            justify-content : center;
            align-items: center;
            width: 120px;
            height: 120px;
        }


        .view_listBtn {
            display: block;
            width: 30px;
            height: 30px;
            text-align: center;
            position : absolute;
            right: 30px;
            top: 3px;
            font-size: 25px;
            color: #358F79;
        }

        .view_list {
            display: none;
            position : absolute;
            right: 30px;
            top : 30px;
            z-index: 100;
            box-shadow : #9c9c9c 0 0 5px;
            border-radius: 15px;
            text-align: center;
        }

        .view_listItem:first-child {
            border-top-right-radius : 15px;
            border-top-left-radius : 15px;
        }

        .view_listItem {
            width: 100px;
            padding: 10px;
            border-bottom : 1px solid #cfcfcf;
            background-color: #f3f3f3;
        }
        
        .view_listItem:hover {
            background-color: #1d8885;
            color: white;
        }

        .view_listItem:last-child {
            border-bottom-right-radius : 15px;
            border-bottom-left-radius : 15px;
        }


    /*Content_View*/

    #content_view {
        position : fixed;
        left: 1400px;
        width: 852px;
        height: 100%;
        background-color: #eff2f5;
        padding: 30px 30px 100px 30px;
        overflow-y : auto;
    }




    .content_title {
        width :100%;
        height: 100px;
        display: flex;
    }

    .content_userProfile {
        width : 100px;
        height: 100px;
        margin-right: 30px;
    }

    .content_userProfile img {
        width: 100%;
        height: 100%;
        border-radius : 50px;
    }

    .content_userinfo {
        width: 600px;
        padding: 20px 10px 20px 10px;
    }

    .content_userName {
        display: block;
        font-size: 25px;
    }

    .content_userID , #content_wdate{
        color : #8c8c8c;
    }
    
    .content_wdate {
        margin-left: 10px;
    }
    .content_body {
        padding: 30px;
        font-size: 20px;
        min-height: 200px;
    }

    .content_imgs {
        width: 100%;
        display: flex;
        flex-wrap : wrap;
        padding-bottom : 100px;
    }

    .content_img {
        width: 45%;
        height: 400px;
        margin : 2.5%;
        -webkit-background-size: 100% 100%;
        background-size: 100% 100%;
    }

    .contentView_cnt {
        color: white;
        font-size : 50px;
        display: inline-block;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        text-align: center;
        line-height: 400px;
    }



</style>