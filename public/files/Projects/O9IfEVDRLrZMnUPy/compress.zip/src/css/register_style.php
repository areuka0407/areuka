<style>


    body {
        background-color: #eff6fa;
    }

    a {
        text-decoration: none;
    }

    #backImage {
        width: 100%;
        height: 100%;
        position : absolute;
        left: 0;
        top : 0;
        z-index : -10;
    }

    #container {
        background-color: rgba(0, 0, 0, 0.5);
        width: 100%;
        height: 100%;
        display: flex;
        justify-content : center;
        align-items : center;
    }

    #wrap {
        margin-top : 30px;
        width: 700px;
        height: 850px;
        background-color: #fff;
        border : 1px solid #e9e9e9;
        border-radius : 20px;
    }

    #header {
        width: 100%;
        text-align: center;
        z-index : 10;
    }

    #logo_wrap {
        padding-top: 20px;
        width: 100%;
        display: flex;
        justify-content : center;
        align-items : center;
    }

    #header #logo {
        text-align : center;
        display: inline-block;
        width: 400px;
        font-size : 30px;
        color : #2892a3;
        font-weight: bold;
        padding-bottom : 20px;
        border-bottom : 1px solid #e7e7e7;
    }

    #form_wrap {
        width: 100%;
        min-height: 600px;
        display: flex;
        justify-content: center     ;
    }

    .register-form {
        position: absolute;
        margin : 0 auto;
        width: 600px;
        height: 630px;
        padding : 0 50px 50px 50px;
    }

    .form-steps {
        width: 100%;
        height: 120px;
        display: block;
        text-align: center;
        margin-top : 10px;
    }

    .badge {
        /*width: 110px;*/
        /*height: 30px;*/
        padding: 10px 20px 10px 20px;
        text-align : center;
        background-color: #2892a3;
        border-radius : 20px;
        color : white;
        margin-right: 20px;
        display: block;
        font-size: 20px;
        line-height: 30px;
    }

    .step_comment {
        display: inline-flex;
        flex-direction : row;
        align-items : center;
        font-size : 25px;
        height: 60px;
        color: #2892a3;
        font-weight: 600;
    }

    .form-items {
        width: 100%;
        height: 100px;
    }

    .item {
        margin : 0 auto;
        position: relative;
        right: -20px;
        width: 400px;
    }

    .user_bd {
        width: 120px;
        display: inline-block;
        margin : 3px;
    }

    #user_bd_month {
        position: relative;
        top: 3px;
    }

    .comment {
        display: block;
    }

    #preview_comment {
        position: absolute;
    }

    #category_comment, #category_alert {
        display: block;
        margin-top : 10px;
        font-size: 14px;
        color : #7e7e7e;
    }

    #category_alert {
        position : absolute;
        right: 50px;
        top : 170px;
        margin : 0;
        padding : 0;
    }

    #user_category {
        width: 300px;
    }


    select {
        border : 1px #e5e5e5 solid;
        width: 355px;
        height: 30px;
        display: block;
        margin-top : 5px;
        background-color: #fbfbfb;
        font-size: 16px;
        padding-left: 10px;
    }

    input {
        display: block;
        width: 360px;
        height: 30px;
        border : 1px #e5e5e5 solid;
        margin-top : 5px;
        background-color: #fbfbfb;
        padding: 5px 5px 5px 15px
    }

    input:focus {
        border : 1px #b3b3b3 solid;
    }

    label {
        margin-left: 5px;
        font-size: 18px;
        display: block;
    }

    button {
        margin-top : 60px;
        width: 350px;
        height: 50px;
        background-color: #2892a3;
        border-radius : 15px;
        color: white;
        font-size : 18px;
    }

    .displayNone {
        display : none;
    }

    #category-wrap {
        width: 100%;
        height: 200px;
        display : flex;
        flex-direction : row;
        flex-wrap : wrap;
        overflow : auto;
        margin : 10px 0 10px 0;
        padding: 5px;
    }

    .category_item {
        display: inline-flex;
        align-items : center;
        position: relative;
        height: 45px;
        min-width: 50px;
        margin : 10px;
        border : 1px #d4d3d3 solid;
        border-radius : 15px;
    }

    .categories {
        border-radius : 15px;
        padding : 10px 15px 10px 15px;
        width: 100%;
        height: 100%;
        display: inline-block;
    }


    #sample_category {
        min-width : 50px;
        text-align: center;
        display: inline-block;
        height: 45px;
        font-size: 16px;
        margin : 10px;
        padding : 10px;
        border-radius : 15px;
        border : 1px #d4d3d3 solid;
        position : relative;
        cursor : pointer;
    }

    .category_checked {
        left : 0;
        top: 0;
        width: 100%;
        height: 100%;
        border-radius : 15px;
        background-color: rgba(0,0,0, 0.5);
        position : absolute;
        justify-content : center;
        align-items : center;
        cursor : pointer;
        display: none;
    }

    .category_checked i {
        color : #32d8d8;
        font-size : 25px;
    }

    #category_item {
        width: 100%;
        height: 50px;
        display: flex;
        align-items : center;
    }
    .category_input {
        margin : 10px;
        height: 40px;
        width: 110px;
        display: inline-block;
    }

    #category_bg_color , #category_font_color {
        width: 20px;
        height: 20px;
        padding: 0;
        position : relative;
        top: 4px;
        right: 5px;
        margin : 0 0 0 10px;
    }

    .category_colors {
        color: #494949;
        font-size : 16px;
        text-align: center;
        position : relative;
        left: 5px;
        border-radius : 15px;
        background-color: #fbfbfb;
        border : 1px solid #e5e5e5;
        margin-right: 10px;
        cursor : pointer;
        padding: 10px 5px 10px 5px;
    }

    #add_category_btn {
        width: 120px;
        font-size: 18px;
        height: 50px;
        color : #2892a3;
        background-color: white;
        border : 1px solid #d4d3d3;
        margin : 0 0 0 10px;
        cursor : pointer;
    }
</style>