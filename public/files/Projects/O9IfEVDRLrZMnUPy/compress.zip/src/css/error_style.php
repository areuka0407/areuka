<style>
    body {
        width: 100%;
        height: 100%;
        background : linear-gradient(to bottom,  #edfffd , #ffffff , #dbfffb );
    }
    
    #wrap {
        width: 900px;
        height: 600px;
        margin : 0 auto;
    }

    header {
        font-size: 25px;
        color: #28acac;
        font-weight: bold;
        margin-bottom : 20px;
    }

    header i {
        margin-right: 5px;
    }

    #error_text {
        font-size: 23px;
    }

    #error_text h1 {
        color: #ff4242;
    }

    #home_btn {
        padding: 10px;
        font-size: 20px;
        border-radius : 15px;
        text-decoration: none;
        color: white;
        display:block;
        text-align: center;
        margin-top : 30px;
        width: 220px;
        background-color: #28acac;
    }
</style>