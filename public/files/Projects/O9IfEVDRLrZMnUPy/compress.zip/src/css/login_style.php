<style>

    /*header*/

    #header {
        width: 100%;
        height: 60px;
        background-color: #fcfcfc;
        border-bottom : 1px solid #e7e7e7 ;
        display: flex;
        justify-content : center;
        align-items : center;
        position : fixed;
        left: 0;
        top: 0;
        z-index : 10;
    }

    #header #logo {
        font-size : 30px;
        color : #2892a3;
        font-weight: bold;
    }

    /*slide*/

    #slide_wrap {
        width: 100%;
        height: 100%;
        overflow : hidden;
        position: absolute;
        z-index : -10;
    }

    #slide {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .back_image {
        width: 100%;
        height: 100%;
        position: absolute;
        top : 0;
        left : 100%;
    }

    /*slide comment*/

    #comment_wrap {
        position: relative;
        width: 50%;
        word-break: break-word;
        text-align: center;
    }

    .back_comment {
        width: 450px;
        top : -150px;
        right: -20px;
        position : absolute;
        display : none;
        color: white;
        font-size : 20px;
        line-height: 40px;
    }

    .back_comment h1 {
        margin-bottom : 30px;
    }

    .back_comment:first-child {
        display: inline;
    }

    #slide_wrap .back_image:first-child {
        left : 0;
    }

    /*content*/

    #wrap {
        background-color: rgba(0, 0, 0, 0.5);
        width: 100%;
        height: 100%;
    }

    #main_content {
        width: 100%;
        height : 800px;
        display : flex;
        flex-direction : row;
        align-items: center;
    }

    #site_info {
        width: 50%;
        height: 300px;
        display : flex;
        justify-content : center;
        align-items : center;
    }

    #login_info {
        width: 50%;
        height: 700px;
        display: flex;
        justify-content : center;
        align-items : center;
    }

        #login_info form {
            text-align: center;
            width: 600px;
            height: 400px;
            background-color: #fbfdfd;
            padding : 20px;
            border-radius : 20px;
            display: flex;
            flex-direction : column;
            justify-content : center;
            border : 1px solid #f6f6f6;
        }

        #login_info #form_title {
            font-size : 45px;
            color: #2892a3;
            margin-top : -20px;
            margin-bottom : 30px;
        }

        #login_info #form_wrap {
            height: 200px;
            width: 400px;
            border-bottom : 1px solid #dadbdb;
            margin:  0 auto;
        }

        #form_wrap button {
            width: 300px;
            height: 50px;
            font-size : 18px;
            margin-top : 15px;
            border-radius : 15px;
            background-color: #28acac;
            color: white;
            transition : 0.3s;
        }

        #form_wrap button:hover {
            background-color: #227979;
        }

        #login_info form input {
            border : 1px #b6c6c9 solid;
            width: 400px;
            height: 40px;
            padding: 10px;
            margin : 10px;
            font-size : 17px;
            display: block;
        }

        #form_items {
            display: flex;
            justify-content : center;
        }

        #form-register {
            margin-top : 10px;
            color : #9c9c9c;
        }

        #form-register a {
            color : #9c9c9c;
            margin-left: 5px;
        }

    /*item-info*/

    #item_content {
        width: 100%;
        height: 120px;
        display: flex;
        justify-content: center;
    }

    #item_content svg {
        cursor : pointer;
    }

</style>