<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2018-10-29
 * Time: 오후 6:54
 */


namespace src\Controller;



class MasterController
{
    //추가시킬 템플릿들
    private $header = __SRC . "Views/template/head.php";

    public function view($page, $data = [])
    {
        require __SRC . "Views/template/head.php";
        if(is_file(__SRC . "css/" . $page . "_style.php" )) require __SRC . "css/" . $page . "_style.php";
        require __SRC . "Views/" . $page . ".php";
        if(is_file( __SRC . "script/" . $page . "_script.php" )) require __SRC . "script/" . $page . "_script.php";
        require __SRC. "script/autosize.php";
    }
}