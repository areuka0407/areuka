<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2018-10-29
 * Time: 오후 7:19
 */

namespace src\Controller;

use src\App\DB;

class UserController extends MasterController
{
    //추가할 유저 관련 페이지들
    public function index(){
        $this->view("login");
    }

    public function login(){
        //로그인 체크 로직들
        if(isset($_POST['user_id']) && isset($_POST['user_pass'])){
            $id = $_POST['user_id'];
            $pass = $_POST['user_pass'];
            $pass = hash('sha256', $pass);

            $sql = "SELECT * FROM users WHERE userID = ?";
            $user = DB::fetch($sql, [$id]);
            if(!$user){
                msgAndBack("해당 아이디의 유저가 존재하지 않습니다.");
                exit;
            }
            if($user->userPW != $pass){
                msgAndBack("비밀번호가 틀립니다.");
                exit;
            }
            $_SESSION['user'] = $user;
//            msgAndGo($_SESSION['user']->userName."님 안녕하세요!", "/");
            Go("/");
        }
    }

    public function register(){
        $sql = "SELECT * FROM category ORDER BY cat_name";
        $cat_list = DB::fetchAll($sql);
        $this->view("register", ['cat_list'=>$cat_list]);
    }

    public function id_check(){
        header("Content-Type:application/json");
        if(isset($_POST['user_id'])){
            $id = $_POST['user_id'];
            $sql = "SELECT * FROM users WHERE userID = ?";
            $data = DB::rowCount($sql, [$id]);

            if($data >= 1){
                echo json_encode(['result'=>false]);
                exit;
            }
            echo json_encode(['result'=>true]);
        }
    }

    public function register_ok(){
        $user_id = $_POST['user_id'];
        $user_pass = $_POST['user_pass'];
        $user_name = $_POST['user_name'];
        $user_gender = $_POST['user_gender'];
        $user_bd = $_POST['user_bd_year']."_".$_POST['user_bd_month']."_".$_POST['user_bd_day'];
        $categories = "";

        for($i=0; $i<$_POST['category_count']; $i++){
            $categories .= $_POST['categories'][$i];
            if($i!=$_POST['category_count']-1){
                $categories.=",";
            }
        }

        $user_pass = hash('sha256', $user_pass);

        $sql = "INSERT INTO users(userID, userName, userPW, gender, birthday, category) VALUES (?, ?, ?, ?, ?, ?)";
        $param = [$user_id, $user_name, $user_pass, $user_gender, $user_bd, $categories];
        DB::execute($sql, $param);
        msgAndGo("회원가입이 완료되었습니다.", "/");
    }

    function UserModify(){
        if(isset($_FILES['profile_modifyInput']) && isset($_FILES['header_modifyInput']) && isset($_POST['user_name_input']) && isset($_POST['user_intro_input'])){
            $userID = $_SESSION['user']->userID;
            $header = $_FILES['header_modifyInput'];
            $profile = $_FILES['profile_modifyInput'];
            $name = $_POST['user_name_input'];
            $intro = $_POST['user_intro_input'];

            $headerName = $_SESSION['user']->headerImage;
            if($header['name'] != "" && $header['name'] != $_SESSION['user']->headerImage){
                $headerName = hash('sha256',  mt_rand() . date( 'Y-m-d H:i:s', time()) ).$header['name'];
                move_uploaded_file($header['tmp_name'], __ORIGIN.'/public/img/user_header/'.$headerName);
            }

            $profileName = $_SESSION['user']->profileImage;
            if($profile['name'] != "" && $profile['name'] != $_SESSION['user']->profileImage){
                $profileName = hash('sha256',  mt_rand() . date( 'Y-m-d H:i:s', time()) ).$profile['name'];
                move_uploaded_file($profile['tmp_name'], __ORIGIN.'/public/img/user_profile/'.$profileName);
            }

            $sql = "UPDATE users SET userName = ?, intro = ?, profileImage = ?, headerImage = ? WHERE userID = ?";
            $cnt = DB::rowCount($sql, [$name, $intro, $profileName, $headerName, $userID]);

            if($cnt != 1){
                msgAndBack("프로필 수정 도중에 문제가 발생했습니다.");
                exit;
            } else {
                unset($_SESSION['user']);
                $sql = "SELECT * FROM users WHERE userID = ?";
                $_SESSION['user'] = DB::fetch($sql, [$userID]);
                Go('/');
            }
        }
    }
}