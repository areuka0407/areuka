<?php
/**
 * Created by PhpStorm.
 * User: School
 * Date: 2018-10-29
 * Time: 오후 6:58
 */

namespace src\Controller;

use src\App\DB;


class MainController extends MasterController
{
    function index(){

            $send_data = [];

            //로그인한 유저의 카테고리 데이터 불러오기
            $categories = $_SESSION['user']->category;
            $categories = explode(',', $categories);
            $cat_cnt = count($categories);
            $sql = "SELECT c.* FROM category AS c WHERE ";
            $params = [];
            for($i = 0; $cat_cnt > $i ; $i++){
                $sql.= "c.cat_name = ?";
                array_push($params, $categories[$i]);

                if(isset($categories[$i+1])){
                    $sql.=" OR ";
                }
            }
            $user_catArr = DB::fetchAll($sql, $params);
            $send_data['user_catArr'] = $user_catArr;


            //글 불러오기

            $board_sql = "b.writer = ?  ";
            $board_params = [$_SESSION['user']->userID];
            foreach($categories as $cat){
                array_push($board_params, "%".$cat."%");
                $board_sql .= "|| b.category LIKE ?";
            }

            $select_cat = '전체보기';
            if(isset($_POST['cat_name'])){
                $board_sql = "b.category LIKE ?";
                $board_params = ['%'.$_POST['cat_name'].'%'];
                $select_cat = $_POST['cat_name'];
            }
            $send_data['select_cat'] = $select_cat;


            $sql = "SELECT b.*, u.* FROM boards AS b 
                LEFT JOIN users AS u ON u.userID = b.writer
                WHERE  {$board_sql}
                ORDER BY idx DESC LIMIT 0, ".__PAGE;
            $board_data = DB::fetchAll($sql, $board_params);
            $send_data['board_data'] = $board_data;
//        var_dump($send_data);
            $this->view("main", $send_data);
    }

    function error(){
        $this->view("error");
    }


    function category_add(){
        header("Content-Type:application/json");

        if(isset($_POST['cat_name']) && isset($_POST['cat_color']) && isset($_POST['cat_bgc'])){
            $cat_name = $_POST['cat_name'];
            $cat_color = $_POST['cat_color'];
            $cat_bgc = $_POST['cat_bgc'];

            if(trim($cat_name) == "" || trim($cat_color) == "" || trim($cat_bgc) == ""){
                echo json_encode((Object)['result'=>false, 'msg'=>'카테고리를 입력해 주세요.']);
                exit;
            }

            $sql = "INSERT INTO category(cat_name, cat_color, cat_bgc) VALUES (?, ?, ?)";
            $data = [$cat_name, $cat_color, $cat_bgc];
            $result = DB::rowCount($sql, $data);
            
            if($result == 1){
                echo json_encode((Object)['result'=>true, 'msg'=>'카테고리가 추가되었습니다.']);
            }else{
                echo json_encode((Object)['result'=>false, 'msg'=>'해당 카테고리가 이미 존재합니다.']);
            }
            
        }
    }

    function board_write(){
        header('Content-Type: application/json');
        if(isset($_POST['form_type']) && isset($_POST['comment']) && isset($_POST['img_length']) && isset($_POST['select_cat']) && isset($_POST['existImg_length'])){
            $form_type = $_POST['form_type'];
            $comment = $_POST['comment'];
            $img_length = $_POST['img_length'];
            $existImg_length = $_POST['existImg_length'];
            $writer = $_SESSION['user']->userID;
            $select_cat = $_POST['select_cat'];


            $images = "";
            $img_col = "";
            $img_sql = "";
            $sql_param = [$comment, $writer];
            if($img_length != 0){
                $img_col = "images , ";
                $img_sql = "?,";
                for($i = 1; $i<=$img_length; $i++){
                    $img_name= strtoupper(hash('sha256', rand(1000,2000).date("Y-m-d H:i:s"))).$_FILES['image'.$i]['name'];
                    move_uploaded_file($_FILES['image'.$i]['tmp_name'], __ORIGIN."/public/img/board_files/".$img_name);
                    if($i != 1) $images .= "|";
                    $images .= $img_name;
                }
                array_push($sql_param, $images);
            }

            if($form_type == "modify" && $existImg_length != 0 && isset($_POST['form_id'])){
                $img_col = "images = ?";
                $sql_param = [];
                $exist_img = [];
                for($i = 1; $i<=$existImg_length; $i++){
                    array_push($exist_img, $_POST['exist_image'+$i]);
                    $images .= "|".$_POST['exist_image'+$i];
                }

                $form_id = $_POST['form_id'];
                $exist_board = DB::fetch("SELECT * FROM boards WHERE idx = ?", [$form_id]);
                $exist_boardImage = explode("|", $exist_board->images);
                $different_image = array_value(array_diff($exist_boardImage, $exist_img));
//                var_dump($different_image);
                // DB에서 삭제된 이미지들의 로컬 파일 삭제
                foreach($different_image as $img){
                    unlink(__ORIGIN."/public/img/board_files".$img);
                }

                //업데이트 된 이미지들과 기존 이미지들을 합침.

            }
            array_push($sql_param, $select_cat);

            if($form_type == "modify" && isset($_POST['form_id'])){
                $form_id = $_POST['form_id'];

                $sql = "UPDATE boards SET comment = ?, images = ?, category = ? WHERE idx = ?";
            }

            $sql = "INSERT INTO boards(comment, writer, wdate , {$img_col} category) VALUES (?, ?, NOW(), {$img_sql} ?)";
            $cnt = DB::rowCount($sql, $sql_param);

            if($cnt != 1){
                echo "오류가 발생했습니다.";
            } else {
                if(mb_substr_count($images , "|") > 0){
                    $imgArr = explode('|',$images);
                    $result_data['first_img'] = $imgArr[0];
                } else {
                    $result_data['first_img'] = $images;
                }

                $result_data['last_insert'] = DB::lastId();
                echo json_encode($result_data);
            }
        }
    }

    function board_delete(){
        header('ContentType: application/json');
        if(isset($_POST['idx'])){
            $idx = $_POST['idx'];
            $sql = "SELECT * FROM boards WHERE idx = ?";
            $board_data = DB::fetch($sql, [$idx]);
            if(!$board_data){
                msgAndBack("해당 글이 존재하지 않습니다.");
                exit;
            }

            if($_SESSION['user']->userID != $board_data->writer){
                msgAndBack("해당 글을 삭제할 권한이 없습니다.");
                exit;
            }

            $sql = "DELETE FROM boards WHERE idx = ?";
            DB::execute($sql, [$idx]);
        }
    }

    function LoadMore(){
        header('Content-Type:application/json');
        if(isset($_POST['page'])){
//            일정 페이지 수만큼 추가로 데이터를 불러오기
            $page = $_POST['page'];
            $limit_page = __PAGE;


            // 카테고리 가져오기
            $categories = $_SESSION['user']->category;
            $categories = explode(',', $categories);
            $board_sql = "";
            $board_params = [$_SESSION['user']->userID];
            foreach($categories as $cat){
                array_push($board_params, "%".$cat."%");
                $board_sql .= "|| u.category LIKE ?";
            }

            //전체 글 수 가져오기
            $sql = "SELECT COUNT(*) as cnt FROM boards AS b LEFT JOIN users AS u ON u.userID = b.writer WHERE b.writer = ? {$board_sql}";
            $post_cnt = DB::fetch($sql, $board_params);

            if($page + $limit_page > $post_cnt->cnt){
                $limit_page = $post_cnt->cnt - $page;
            }

            $page++;
            $sql = "SELECT b.*, u.* FROM boards AS b 
                LEFT JOIN users AS u ON u.userID = b.writer
                WHERE b.writer = ? {$board_sql}
                ORDER BY idx DESC LIMIT {$page}, ".$limit_page;
            $more_data = DB::fetchAll($sql, $board_params);


            echo json_encode($more_data);
        }
    }

    function ViewLoad(){
        header('Content-Type: application/json');
        if(isset($_POST['board_id'])){
            $idx = $_POST['board_id'];

            $sql = "SELECT b.*, u.* FROM boards AS b
                    LEFT JOIN users AS u ON u.userID = b.writer
                    WHERE b.idx = ?";
            $board_data = DB::fetch($sql, [$idx]);
            echo json_encode($board_data);
        }
    }

    function logout(){
        unset($_SESSION['user']);
        Go("/");
    }
}