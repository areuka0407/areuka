<?php
function msgAndBack($msg){
    echo "<script>";
    echo "alert('".$msg."');";
    echo "history.back();";
    echo "</script>";
}

function msgAndGo($msg, $url){
    echo "<script>";
    echo "alert('".$msg."');";
    echo "location.href='".$url."';";
    echo "</script>";
}

function Go($url){
    echo "<script>";
    echo "location.href='".$url."';";
    echo "</script>";
}