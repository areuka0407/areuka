<script>
    var register_check1 = false;
    var register_check2 = false;
    var register_check3 = false;

    function truely(box, comment = false, msg = ""){
        if(box) box.style.border = "#2892a3 solid 2px";
        if(comment){
            $(comment).empty();
            comment.style.color = "#2892a3";
            $(comment).text(msg);
        }
    }
    function falsly(box, comment = false, msg = ""){
        if(box) box.style.border = "#ff7474 solid 2px";
        if(comment){
            $(comment).empty();
            comment.style.color = "#ff7474";
            $(comment).text(msg);
        }
    }


    function id_check(){
        var target = document.querySelector("#user_id");
        var user_id = target.value;
        var comment = document.querySelector("#id_comment");
        if(user_id.trim()===""){
            falsly(target, comment, "아이디를 입력해 주세요!");
            register_check1 = false;
            return false;
        } else if (user_id.length > 15){
            falsly(target, comment, "아이디는 15자 이내로 입력해 주세요!");
            register_check1 = false;
            return false;
        } else if(/\W/.exec(user_id)){
            falsly(target, comment, "아이디는 영어 대·소문자와 숫자만 입력 가능합니다.")
            register_check1 = false;
        } else {
            $.ajax({
                data : {'user_id' : user_id},
                method : "POST",
                url : "/id_check",
                success : function(data) {
                    console.log(data);
                    if(data && data.result){
                        truely(target, comment, "멋진 아이디네요!");
                        register_check1 = true;
                        return false;
                    } else {
                        falsly("이미 존재하는 아이디에요...");
                        register_check1 = false;
                        return false;
                    }
                },
                error : function(data){
                    falsly(target, comment, "아이디에 오류를 발견했습니다.");
                    console.log(this);
                    console.log(data.result);
                }
            });




        }

        // var data = new FormData();
        // data.append("id", user_id);
        // var xhr = new XMLHttpRequest();
        // xhr.onload = function(){
        //     if( xhr.status === 200 || xhr.status === 201){
        //         console.log(xhr.responseText);
        //     } else {
        //         console.log(xhr.responseText);
        //     }
        // };
        //
        // xhr.open("POST", "/id_check");
        // xhr.send(data);
    }

    function pass_check(){
        var pass_target = document.querySelector("#user_pass");
        var repass_target = document.querySelector("#user_repass");
        var comment = document.querySelector("#pass_comment");
        var user_pass = pass_target.value;
        var user_repass = repass_target.value;

        if(user_pass.length < 6){
            falsly(pass_target, comment, "비밀번호를 6자 이상으로 설정해 주세요!");
            register_check1 = false;
            return false;
        }
        if (user_repass!=="" && user_pass !== user_repass){
            falsly(pass_target, comment, "비밀번호와 비밀번호 확인이 일치하지 않습니다.");
            falsly(repass_target);
            register_check1 = false;
            return false;
        }
        if(user_pass.trim()!=="" && user_repass.trim()!=="" && user_repass === user_pass){
            truely(pass_target, comment, "");
            truely(repass_target, comment, "");
            register_check1 = true;
            return false;
        }
    }




    function name_check(){
        var target = document.querySelector("#user_name");
        var name = document.querySelector("#user_name").value;
        var comment = document.querySelector("#name_comment");
        if(name.trim() === ""){
            falsly(target, comment, "이름을 입력해 주세요!");
            register_check2 = false;
            return false;
        } else if (name.length>20){
            falsly(target, comment, "이름은 20자 이내로 입력해 주세요!");
            register_check2 = false;
            return false;
        } else  {
            truely(target, comment, "멋진 이름이네요!");
            register_check2 = true;
        }
    }


    function bd_check(){
        var targets = document.querySelectorAll(".user_bd");
        var year = document.querySelector("#user_bd_year");
        var month = document.querySelector("#user_bd_month");
        var day = document.querySelector("#user_bd_day");
        var nowYear = new Date().getFullYear();
        var comment = document.querySelector("#bd_comment");
        let flag = true;
        targets.forEach(function(target){
            if(isNaN(target.value) || target.value.trim() === ""){
                let box = document.querySelector("#"+target.id);
                falsly(box, comment, "생년월일을 정확하게 입력해 주세요!");
                flag = false;
            }
        });
        if(year.value.length < 4){
            falsly(year, comment, "태어난 년도 4자리를 정확히 입력해 주세요!");
            register_check2 = false;
            flag = false;
        }
        if(year.value > nowYear){
            falsly(year, comment, "미래에서 오셨네요? *^^*");
            register_check2 = false;
            flag = false;
        }
        if(year.value < nowYear - 100){
            falsly(year, comment, "Dinecto는 100살까지만 가입이 가능해요 ^^");
            register_check2 = false;
            flag = false;
        }
        let temp_date = new Date(year.value, month.value-1, day.value);

        // console.log(temp_date.getDate() + " and " + day.value);
        if(temp_date.getDate()!=day.value){
            falsly(day, comment, "생년월일을 정확하게 입력해 주세요!");
            register_check2 = false;
            flag = false;
        }

        if(flag){
            register_check2 = true;
            truely(year, comment, "");
            truely(month, comment, "");
            truely(day, comment, "");
        }

        //
        // if(day.value > 31){
        //     falsly(day, comment, "존재하지 않는 날짜입니다.");
        //     return;
        // }
    }

    var category_add_check = false;
    var category_count = 0;
    let category_box = document.querySelector("#category-wrap");
    let comment = document.querySelector("#category_alert");

    function category_select(e){
        let target = e.target;

        console.log(target);
        if(category_count >= 5){
            falsly(category_box, comment, "카테고리는 5개까지만 선택할 수 있어요.");
            return false;
        } else {
            $(target).closest(".category_item").children(".category_checked").css({display : 'flex'});
            $(target.children[0]).attr({"checked" : "checked"});
            truely(category_box, comment, "멋진 카테고리네요!");
            category_count++;
            register_check3 = true;
        }
    }

    function category_unselect(e){
        category_count--;
        let target = e.target;
        let wrap = $(target).closest(".category_item");
        wrap.children(".category_checked").css({display : 'none'});
        console.log(wrap.children());
        wrap.children(".categories").children("input").removeAttr("checked");


    }

    function category_name_preview(){
        let sample_cat = document.querySelector("#sample_category");
        let cat_name = document.querySelector("#category_name");
        let comment = document.querySelector("#preview_comment");
        if(cat_name.value.trim()===""){
            falsly(cat_name, comment, "카테고리를 입력해 주세요." );
            category_add_check = false;
        } else if(cat_name.value.length > 15){
            falsly(cat_name, comment, "카테고리명은 15자 이하로 입력해 주세요.");
            category_add_check = false;
        } else {
            $(sample_cat).text(cat_name.value);
            truely(cat_name, comment, "멋진 카테고리네요!");
            category_add_check = true;
        }
    }

    function category_color_preview(){
        let sample_cat = document.querySelector("#sample_category");
        let bg_color = document.querySelector("#category_bg_color");
        let font_color = document.querySelector("#category_font_color");

        if(bg_color.value === sample_cat.style.backgroundColor || font_color.value === sample_cat.style.color){
            category_add_check = false;
            return false;
        } else {
            sample_cat.style.backgroundColor = bg_color.value;
            sample_cat.style.color = font_color.value;
            category_add_check = true;
        }
    }

    function add_category(){
        category_color_preview();
        category_name_preview();
        let sample_cat = document.querySelector("#sample_category");
        let comment = document.querySelector("#preview_comment");
        let cat_name = document.querySelector("#category_name");
        if(category_add_check ){
            console.log("!!!");
            $.ajax({
                type : 'POST',
                url : '/category/add',
                data : {'cat_name': cat_name.value, 'cat_color': sample_cat.style.color, 'cat_bgc' : sample_cat.style.backgroundColor},
                success : function (data) {
                    // console.log(data);
                    if(data){
                        if(data.result){
                            console.log(data.result);
                            let html = `<div class="category_item">
                                            <span class="categories" onclick="category_select(event)" style="background-color : ${sample_cat.style.backgroundColor} ; color : ${sample_cat.style.color}">${cat_name.value}<input type="checkbox" class="displayNone" value=${cat_name.value} name="categories[]"></span>
                                        <span class="category_checked" onclick="category_unselect(event)"><i class="fas fa-check-circle" onclick="category_unselect(event)"></i></span>
                            </div>`;
                            $("#category-wrap").append(html);
                            truely(cat_name, comment, data.msg);
                        } else {
                            category_add_check = false;
                            falsly(cat_name, comment, data.msg);
                        }
                    } else {
                        falsly(cat_name, comment, "카테고리를 불러오지 못했습니다.");
                        category_add_check = false;
                    }

                }
            });
        } else {
            falsly(cat_name, comment, "카테고리를 정확히 입력해 주세요!");
            category_add_check = false;
        }
    }

    window.onload = function(){
        var form = document.querySelectorAll(".register-form");
        var circle = document.querySelectorAll("circle");

        let input = document.getElementsByTagName("input");


        $("#next_btn1").click(function(){
            id_check();
            pass_check();
            if(register_check1){
                $(form[0]).fadeOut(1000);
                circle[0].style.fill = "#dadada";
                $(form[1]).fadeIn(1000);
                circle[1].style.fill = "#2892a3";
            }
        });

        $("#next_btn2").click(function(){
            name_check();
            bd_check();
            if(register_check1 && register_check2){
                $(form[1]).fadeOut(1000);
                circle[1].style.fill = "#dadada";
                $(form[2]).fadeIn(1000);
                circle[2].style.fill = "#2892a3";
            }
        });

        $("#form_wrap").on("submit",function(){
            if(category_count > 5){
                register_check3 = false;
            } else {
                $("#category_count").val(category_count);
                return register_check1 && register_check2 && register_check3;
            }
        });
    }
</script>