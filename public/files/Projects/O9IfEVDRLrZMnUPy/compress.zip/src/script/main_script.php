<script>
    //message
    function message(content, color = 'default', size = 'middle', closeOption = true){
        let box = document.getElementById("message_box");

        // design
        $(box).empty();
        $(box).append(content);
        $("#message").css({'display':'block'});
        if(color === 'success'){
            $(box).css({
                'backgroundColor':'#f0fff1',
                'color':'#39593b',
                'borderColor':'#eafaeb'
            });
        } else if(color === 'danger'){
            $(box).css({
                'backgroundColor':'#f5efef',
                'color':'#7e3737',
                'borderColor':'#f3e7e7'

            });
        }

        if(size === 'small') box.style.width = "350px";
        else if(size === 'big') box.style.width = "600px";
        else box.style.width = '500px';

        //output
        $(box).fadeIn(250);
        if(closeOption){
            $(box).click(function(){
                $(box).fadeOut(750);
                $("#message").css({'display':'none'});
            });

            setTimeout(()=>{
                $(box).fadeOut(1500);
                $("#message").css({'display':'none'});
            }, 3000)
        }

    }


    //submit

    let submit_check = true;
        function comment_check(e){
            let target = e.target;
            $(target).css({
                backgroundColor : 'white',
                color : 'black'
            });

            if(target.value.length > 10000){
                message("텍스트는 최대 10,000자까지 작성하실 수 있습니다.", 'danger');
                $(target).css({
                    backgroundColor : '#e0e0e0',
                    color : 'black'
                });
                submit_check = false;
                return false;
            }

            submit_check = true;
        }


        let img_arr = [];
        let existImg_arr = [];

        // preview
        function preview(e, drop=false) {
            e.preventDefault();

            let images;
            if (drop) {
                $("#form_black_box").hide();
                images = e.dataTransfer.files;
            } else {
                images = e.target.files;
            }

            // if(img_arr.length + images.length > 4){
            //     message("파일은 5개 이상 업로드 할 수 없습니다.", 'danger');
            //     submit_check = false;
            //     return false;
            // }

            let file_list = Array.prototype.slice.call(images);
            file_list.forEach(function(img){
                $("#form_black_box").hide();
                if(img.type.substr(0, 5) !== "image"){
                    message("이미지만 업로드 할 수 있습니다.", 'danger');
                    submit_check = false;
                    return false;
                }

                let Reader = new FileReader;
                Reader.readAsDataURL(img);
                Reader.onload = function(result){
                    let preview_area = $("#preview_wrap");
                    let html = `<div class="preview_img" onclick="img_delete(event)" id="${img.name} insert_image">
                                    <img class="ClickEventNone" src="${Reader.result}">
                                    <i class="fas fa-times preview_delete ClickEventNone"></i>
                                </div>`;
                    preview_area.slideDown('fast', function(){
                        preview_area.append(html);
                    });
                };

                img_arr.push(img);
            });
            submit_check = true;
        }

        function img_delete(e){
            let target = e.target;
            let image_id = target.id.split(" ");
            let image_name = image_id[0];
            let image_type = image_id[1];
            let image_item = $("#preview_wrap > div");
            let idx = 0;
            if(image_type === "insert_image"){
                img_arr.forEach(function(img){
                    if(img.name == image_name){
                        img_arr.splice(idx, 1);
                        target.remove();
                    }
                    idx++;
                });
            } else if(image_type === "modify_image"){
                existImg_arr.forEach(function(img){
                    if(img == image_name){
                        existImg_arr.splice(idx, 1);
                        target.remove();
                    }
                    idx++;
                });
                target.remove();
            }

            console.log(img_arr.length + existImg_arr.length );
            if(img_arr.length + existImg_arr.length === 0){
                $("#preview_wrap").slideUp();
            }



        }

        //category_select
        function cat_select(e){
            $(".form_category").removeClass("cat_checked");
            let target = e.target;
            let target_id = target.id.substr(target.id.length-1, 1);
            $($(target).siblings("#label"+target_id)[0]).addClass("cat_checked");
        }


        function form_submit(){
            let form_type = $("#form_type").val();
            let form_id = $("#form_id").val();
            if(submit_check){

                //Comment Check
                let comment = document.querySelector("#comment").value;
                if(comment.trim() === ""){
                    message("텍스트를 입력해 주세요.", 'danger');
                    return false;
                }

                if(comment.length > 10000){
                    message("텍스트는 최대 10,000자까지 작성하실 수 있습니다.", 'danger');
                    return false;
                }


                //Category Check
                let categories = $(".form_catInput");
                let select_cat = "";
                if(categories.length > 1){
                    for(let i = 0; i<categories.length; i++){
                        // console.log(categories[i].checked);
                        if(categories[i].checked){
                            select_cat = categories[i].value;
                            break;
                        }
                    }
                } else {
                    select_cat = categories[0].value;
                }


                let data_form = new FormData();
                let idx = 1;
                let name;
                img_arr.forEach(function(img){
                    name = "image"+idx;
                    data_form.append(name, img);
                    idx++;
                });

                idx = 1;
                existImg_arr.forEach((img)=>{
                    name = "exist_image"+idx;
                    data_form.append(name, img);
                    idx++;
                });

                data_form.append("comment", comment);
                data_form.append("img_length", img_arr.length);
                data_form.append("existImg_length", existImg_arr.length);
                data_form.append("select_cat", select_cat);
                data_form.append("form_type", form_type);
                if(form_id != 0) data_form.append("form_id", form_id);

                let xhr = new XMLHttpRequest();
                xhr.open("POST", "/board/add");
                xhr.onload = function (){
                    if (xhr.readyState === xhr.DONE) { // 요청이 완료되면
                        if (xhr.status === 200 || xhr.status === 201) {
                            console.log(xhr);
                            let result = JSON.parse(xhr.responseText);
                            $("#preview_wrap").empty();
                            $("#preview_wrap").slideUp();
                            document.querySelector("#comment").value = "";
                            message("글이 성공적으로 작성되었습니다.", "success");
                            let img_name = img_arr.length != 0 ? result.first_img : "";
                            let image = img_arr.length != 0 ? `<img src='img/board_files/${img_name}'>` : '';
                            let idx = result.last_insert;
                            let html = `<div class="view_wrap" id="${idx}" onclick="ContentView(event)">
                                            <div class="form_user ClickEventNone">
                                                <img src="img<?=$_SESSION['user']->profileImage != '' ? '/user_profile/'.$_SESSION['user']->profileImage:'/profile_xample_img/unknown.png'?>" alt="" class="form_userProfile ClickEventNone">
                                                <span class="form_user_name ClickEventNone">
                                                    <?=$_SESSION['user']->userName?>
                                                </span>
                                            </div>

                                            <div class="view_content ClickEventNone">
                                                ${comment.substr(0, 150)}
                                            </div>
                                            <div class="view_images ClickEventNone">
                                                ${image}
                                            </div>
                                        </div>`;
                            $("#form_box").after(html);
                        } else {
                            console.error(xhr.responseText);
                        }
                    }
                };
                xhr.send(data_form);

            }
        }


    // Side List
    let openlist = true;
    function openList(){
            if(openlist){
                $("#side_popItems").fadeIn(200);
                openlist = false;
            } else {
                $("#side_popItems").fadeOut(200);
                openlist = true;
            }

    }


    //Content View
    let viewNow = false;
    let nowidx;
    function ContentView(e){
        // console.log(viewNow);
        let board_id = e.target.id;
        if(!board_id) return false;
        if(board_id !== nowidx && !$("#content_wrapper").is(":animated")){
            nowidx = board_id;

            //사이드바 (비)활성화
            $("#side_popItems").fadeOut();
            $("#user_backImage").fadeOut(820);
            $("#open_list").fadeOut(1000);
            $("#open_side").fadeIn(1000);

            //콘텐츠의 이동
            $("#main_content").animate({
                marginLeft : '50px'
            }, 1000);

            $("#content_view").animate({
                left: '1052px'
            }, 1000);

            $("#side_content").animate({
                left: '-350px'
            }, 1000);


            //콘텐츠 재작성
            $("#content_wrapper").fadeOut(250, function() {
                $("#content_wrapper").empty();


                // $("#content_view").empty();


                $.ajax({
                    url : '/board/viewLoad',
                    data : {board_id : board_id},
                    method : "POST",
                    success : function(result){
                        if(result){
                            let userName = result.userName;
                            let userID = result.userID;
                            let wdate = result.wdate;
                            let user_header = result.headerImage;
                            let user_profile = result.profileImage !== "" ? "img/user_profile/"+result.profileImage : "img/profile_xample_img/unknown.png";
                            let content = result.comment;
                            let images = result.images;
                            let imageHTML = "";
                            if(images !== ""){
                                let image_cnt = 0;
                                images = images.split('|');
                                images.forEach(function(img){
                                    image_cnt++;
                                    if(image_cnt <= 4){
                                        imageHTML += `<div style="background-image:url('img/board_files/${img}');" class="content_img">`;
                                    }
                                    if(image_cnt < 4) imageHTML += "</div>";
                                });
                                if(image_cnt === 4) imageHTML += "</div>";
                                if(image_cnt >= 5){
                                    image_cnt -= 4;
                                    imageHTML += `<span class="contentView_cnt">+${image_cnt}</span></div>`;
                                }
                            }



                            let html = `

                                    <div class="content_title">
                                            <div class="content_userProfile">
                                                <img src="${user_profile}" alt="profile_img">
                                            </div>
                                            <div class="content_userinfo">
                                                <span class="content_userName">${userName}</span>
                                                <span class="content_userID">@${userID}</span>
                                                <span class="content_wdate">${wdate}</span>
                                            </div>
                                    </div>
                                    <div class="content_body">
                                        <div class="content">
                                          ${content}
                                        </div>
                                    </div>
                                    <div class="content_imgs">
                                        ${imageHTML}
                                    </div>
                                `;
                            $("#content_wrapper").append(html);
                            $("#content_wrapper").fadeIn(250);

                        }
                    },
                    error : function(error){
                        console.log(error);
                    }
                });
                viewNow = true;
            });
        }

    }

    function CloseView(){
        if(viewNow){
            $("#open_side").fadeOut(1000);
            $("#open_list").fadeIn(1000);

            $("#user_backImage").fadeIn(1000);

            //콘텐츠의 이동
            $("#main_content").animate({
                marginLeft : '400px'
            }, 1000);

            $("#content_view").animate({
                left: '1400px'
            }, 1000);

            $("#side_content").animate({
                left: 0
            }, 1000);

            $("#content_wrapper").fadeOut(1000, function(){
                $("#content_wrapper").empty();
            });
            viewNow = false;
            nowidx = 0;
        }
    }


    //유저 프로필 수정

    function User_Modify_Show(){
        //Show
        $("#modify_close").fadeIn(250);
        $("#user_name_input").fadeIn(250);
        $("#user_intro_input").fadeIn(250);
        $("#user_modify_btn").fadeIn(250);
        $("#modify_list_btn").fadeIn(250);
        //Hide
        $("#side_popItems").fadeOut(250);
        $("#user_name").fadeOut(250);
        $("#user_intro").fadeOut(250);
        $("#side_items").css({opacity : '0.5'});
        $("#user_backImage").css({opacity : '0.5'});
        $("#main_content").css({opacity: '0.5' , transition : '0.25s'});
        $(".category > button, .category > a").css({pointerEvents : 'none'});
        $(".view_wrap").css({pointerEvents : 'none'});
        $(".side_item").css({pointerEvents : 'none'});
    }

    function User_Modify_Close(){
        //Show
        $("#user_name").fadeIn(250);
        $("#user_intro").fadeIn(250);
        $(".view_wrap").css({pointerEvents : 'auto'});
        $(".side_item").css({pointerEvents : 'auto'});
        $("#side_items").css({opacity : '1'});
        $("#user_backImage").css({opacity : '1'});
        $("#main_content").css({opacity: '1', transition : 'none'});
        $(".category > button, .category > a").css({pointerEvents : 'auto'});

        //Hide
        $("#modify_list_btn").fadeOut(250);
        $("#side_popItems").fadeOut(250);
        $("#modify_close").fadeOut(250);
        $("#user_name_input").fadeOut(250);
        $("#user_intro_input").fadeOut(250);
        $("#user_modify_btn").fadeOut(250);
    }

    let modify_list = true;
    function Modify_List_Fade(){
        if(modify_list){
            $("#modify_list").fadeIn(250);
            modify_list = false;
        } else {
            $("#modify_list").fadeOut(250);
            modify_list = true;
        }
    }

    function User_Modify_Submit(e){
        let form = e.target;
        e.preventDefault();

        form.submit();
    }

    function User_Image_Preview(e){
        let input_id = e.target.id;
        let image = e.target.files;

        let reader = new FileReader();
        reader.readAsDataURL(image[0]);
        reader.onload = function(){
            let target;
            if(input_id === "header_modifyInput"){
                target = document.querySelector("#user_backImage");
                target.style.backgroundImage = `url(${reader.result})`;
            } else {
                target = document.querySelector("#user_profileImage");
                target.src = reader.result;
            }
        }
    }

    let ViewListNow;
    let ViewListFader = true;
    function ViewListFade(id){
        $(".view_list").fadeOut();
        if(ViewListFader){
            $("#view_list_"+id).fadeIn();
            ViewListNow = id;
            ViewListFader = false;
        } else if(ViewListNow != id){
                $("#view_list_"+id).fadeIn();
                ViewListNow = id;
                ViewListFader = false;
        } else {
            $("#view_list_"+id).fadeOut();
            ViewListFader = true;
        }
    }

    function Post_Modify(id){
        if(!id) return false;
        let idx = id;

        $.ajax({
            url:'/board/viewLoad',
            method : 'POST',
            data : {board_id : idx},
            success : function(res){
                console.log(res.category);
                $("#form_id").val(idx); //id
                $("#comment").val(res.comment); //comment
                $("#form_type").val("modify"); //post_type
                $(".form_category").removeClass("cat_checked"); // category_option
                $("#label"+res.category).addClass("cat_checked");
                $(".form_catInput").removeAttr("checked");
                $("#"+res.category).attr({checked : true});
                $("#preview_wrap").empty(); //img
                img_arr = [];
                existImg_arr = [];

                let preview_area = $("#preview_wrap");
                let html = ``;
                let images = res.images.split("|");
                if(images[0] !== ""){
                    images.forEach((img)=>{
                        existImg_arr.push(img);
                        html += `<div class="preview_img" onclick="img_delete(event)"  id="${img} modify_image">
                                    <img src="img/board_files/${img}" class="ClickEventNone">
                                    <i class="fas fa-times preview_delete ClickEventNone"></i>
                                </div>`;
                    });
                }
                $("html body").animate({
                    scrollTop: 0
                }, 500 , ()=>{
                    if(images[0] !== ""){
                        preview_area.slideDown(500, ()=>{
                            preview_area.append(html);
                        });
                    } else {
                        preview_area.slideUp();
                    }
                });
            },
            error : function (err){
                console.log(err);
            }
        });
    }

    function Post_Delete(id){
        if(!id) return false;
        $.ajax({
            url : '/board/delete',
            data : {'idx':id},
            method : 'POST',
            success : function(res){
                console.log(res);
                $("#"+id).fadeOut(1000, function(){
                    $("#"+id).remove();
                    message("글이 삭제되었습니다.", "success")
                });
            },
            error : function(res){
                console.log(res);
            }
        })
    }


    function preventE(e){
            e.preventDefault();
            e.stopPropagation();
    }

    function Tester(){
            console.log("함수 실행됨.");
    }

    window.onload = function(){



            //Form Text Area Resizing
            autosize(document.getElementsByTagName("textarea"));


            // Drop-Down Event
            $(window).on("dragover", function(){
                $("#form_black_box").show();

            });

            $("#form_box").on("drag dragover dragend", function(e){
                e.preventDefault();
                e.stopPropagation();
            });

            $(document).on("scroll", LoadMore);



        // Poster Loading
        let default_postCnt = <?=__PAGE?>;

        let window_height = window.innerHeight;
        $(window).on("resize", function(){
            window_height = window.innerHeight;
        });

        function LoadMore(){
            let scroll_top = $(window).scrollTop();
            let content_height = $("#content_list").offset().top + document.querySelector("#content_list").scrollHeight;

            if(scroll_top + window_height === content_height){
                $.ajax({
                    method : 'POST',
                    data : {page : default_postCnt},
                    url : '/board/loadmore',
                    success : function(result){
                            result.forEach(function(item){
                                let comment = item.comment.substr(0, 150) + item.comment.length > 150 ? '...' : '';
                                let image = "";
                                let imageHTML = "";
                                if(item.images !== ""){
                                    image = item.images.split("|");
                                    imageHTML = `<img src='img/board_files/${image[0]}'>`;
                                    let imgCnt = image.length-1;
                                    if(imgCnt != 0) imageHTML += `<span id="view_images_cnt">+${imgCnt}</span>`;
                                }

                                let html = `<div class="view_wrap" id="${item.idx}" onclick="ContentView(event)">
                                                <div class="form_user ClickEventNone">
                                                    <img src="img/${item.profileImage != '' ? 'user_profile/'+item.profileImage : 'profile_xample_img/unknown.png'}" alt="" class="form_userProfile">
                                                    <span class="form_user_name ClickEventNone">
                                                        ${item.userName}
                                                    </span>
                                                </div>
                                                <div class="view_content ClickEventNone">
                                                    ${item.comment.substr(0, 150)} ${item.comment.length > 150 ? '...' : ''}
                                                </div>
                                                <div class="view_images ClickEventNone">
                                                    ${imageHTML}
                                                </div>
                                            </div>`;
                                $("#content_list").append(html);
                            });
                            default_postCnt += <?= __PAGE ?>;

                    },
                    error : function(result){
                        console.log(result);
                    }
                })
            }
        }



        // \Poster Loding



    }

</script>