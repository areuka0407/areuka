<script>
    var back_image = document.querySelectorAll(".back_image");
    var back_comment = document.querySelectorAll(".back_comment");
    var slide_icon = document.querySelectorAll(".slide_icon");
    var now = 0;
    var max = back_image.length - 1;
    function slide(flag=false){
        if ($(back_image[now]).is(":animated")) return;
        $(back_comment[now]).fadeOut(1000);
        slide_icon[now].style.fill = "#ffffff";
        $(back_image[now]).animate({
            left: "-100%",
            opacity: "0.3"
        }, 2000, function () {
            $(this).css({left: "100%"});
        });
        now = now + 1 > max ? 0 : now + 1;
        if(flag!==false) now = flag;
        $(back_comment[now]).fadeIn(1000);
        slide_icon[now].style.fill = "#2da7af";
        $(back_image[now]).animate({
            left: 0,
            opacity: "1"
        }, 2000);
    }


    var timer = setInterval(slide, 4000);

    function reset_slide(e){
        var id = Number(e.target.id);
        console.log("ID : " +  id);
        clearInterval(timer);
        slide(id);
        timer = setInterval(slide, 4000);
    }

    window.onload = function(){
        $("svg").click(reset_slide);
    }

</script>