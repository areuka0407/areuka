<?php
    echo $name;