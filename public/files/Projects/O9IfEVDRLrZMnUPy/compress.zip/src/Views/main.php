
<!--Main Header-->

<div id="header">
    <a id="logo" href="/">
        Dinecto
    </a>
</div>


<!--사이드의 컨텐츠 ( 유저 프로필, 네비게이션 등 )-->

<div id="side_content">
    <div id="side_items">
        <span id="open_list" class="side_item" onclick="openList()"><i class="fas fa-list-ul ClickEventNone"></i></span>
        <span id="open_side" class="side_item" onclick="CloseView()"><i class="fas fa-caret-right ClickEventNone"></i></span>
    </div>
    <div id="side_popItems">
        <a id="userModify_btn" class="side_popItem" onclick="User_Modify_Show()">
            프로필 수정
        </a>
        <a id="logout_btn" class="side_popItem" href="/logout">
            로그아웃
        </a>
    </div>
    <i class="far fa-times-circle" id="modify_close" onclick="User_Modify_Close()"></i>
    <form id="user_profile" action="user/modify" method="POST" enctype="multipart/form-data" onsubmit="User_Modify_Submit(event)">
        <div id="user_images">
            <div id="user_backImage" style="background-image : url('img/<?=$_SESSION['user']->headerImage != '' ? 'user_header/'.$_SESSION['user']->headerImage : "/img/header_xample_img/2.jpeg" ?>')">
                <img src="img<?= $_SESSION['user']->profileImage != '' ? '/user_profile/'.$_SESSION['user']->profileImage  : '/profile_xample_img/big_unknown.png'  ?>" alt="" id="user_profileImage" width="200px" height="200px">
            </div>
            <i id="modify_list_btn" class="fas fa-camera-retro" onclick="Modify_List_Fade()"></i>
            <div id="modify_list">
                <label id="profile_modify" for="profile_modifyInput">프로필 사진 변경</label>
                <input type="file" id="profile_modifyInput" class="hidden" value="<?=$_SESSION['user']->profileImage ?>" accept="image/*" name="profile_modifyInput" onchange="Modify_List_Fade(); User_Image_Preview(event)">
                <label id="header_modify" for="header_modifyInput">헤더 사진 변경</label>
                <input type="file" id="header_modifyInput" class="hidden" value="<?= $_SESSION['user']->headerImage ?>" accept="image/*" name="header_modifyInput" onchange="Modify_List_Fade(); User_Image_Preview(event)">
            </div>
        </div>
        <div id="user_info">
            <span id="user_name_wrap">
                <span id="user_name"><?= $_SESSION['user']->userName ?></span>
                <input type="text" id="user_name_input" placeholder="닉네임" name="user_name_input" value="<?=$_SESSION['user']->userName?>" maxlength="20" required>
            </span>
            <span id="user_id">
                @<?= $_SESSION['user']->userID ?>
            </span>
            <div id="user_intro_wrap">
                <div id="user_intro">
                    <?= $_SESSION['user']->intro != "" ? $_SESSION['user']->intro : "인삿말이 아직 없습니다."?>
                </div>
                <textarea name="user_intro_input" id="user_intro_input" maxlength="150"><?=$_SESSION['user']->intro?></textarea>
            </div>
            <button type="submit" id="user_modify_btn">수정하기</button>
        </div>
    </form>
</div>


<!--중심 컨텐츠들-->

<div id="main_content">
    <!--카테고리가 삽입될 공간-->
    <div id="category_wrap">
        <div class="category">
            <button style=<?= $data['select_cat'] == '전체보기' ? '"background-color: #159088; color: white;"' : '"background-color: white; color: black"' ?> >전체보기</button>
        </div>
        <?php foreach($data['user_catArr'] as $cat){ ?>
            <div class="category">
                <button style="background-color: <?=$cat->cat_bgc?>; color: <?=$cat->cat_color?>" onclick="Category_Change('<?=$cat->cat_name?>')"><?=mb_substr(trim($cat->cat_name), 0, 4)?><?=mb_strlen($cat->cat_name)>=5 ? ".." : ""?></button>
            </div>
        <?php } ?>

    </div>
    <!--타임라인이 올라올 공간-->
    <div id="content_wrap">
        <div id="content_list">
            <div id="form_box" ondrop="preview(event, true)">
                <input type="hidden" value="write" id="form_type">
                <input type="hidden" value="0" id="form_id">
                <div id="form_black_box"></div>
                <div class="form_user">
                    <img src="img/<?= $_SESSION['user']->profileImage != '' ? 'user_profile/'.$_SESSION['user']->profileImage : 'profile_xample_img/unknown.png' ?>" alt="profile image" class="form_userProfile">
                    <span class="form_user_name"><?= $_SESSION['user']->userName ?></span>
                </div>
                <div id="form_content">
                    <div id="form">
                        <textarea name="comment" id="comment" rows="5" onkeydown="comment_check(event)" maxlength="10000"></textarea>
                    </div>
                    <?php if($data['select_cat'] == '전체보기'){?>
                    <div id="form_categories">
                        <?php
                        $cat_id = 1;
                        foreach($data['user_catArr'] as $cat){
                            ?>
                            <label for="<?="input".$cat_id?>" id="<?="label".$cat_id?>" class="form_category <?=$cat_id == 1 ? 'cat_checked' : ''?>" style="color : <?=$cat->cat_color?>; background-color: <?=$cat->cat_bgc?>;" ><?=$cat->cat_name?></label>
                            <input type="radio" id="<?="input".$cat_id?>" class="hidden form_catInput" value="<?=$cat->cat_name?>" name="form_category" onchange="cat_select(event)" <?=$cat_id == 1 ? 'checked' : '' ?>>
                        <?php
                        $cat_id++;
                        }?>
                    </div>
                    <?php } else {?>
                        <input type="hidden" class="form_catInput" value="<?=$data['select_cat']?>">
                    <?php }?>
                    <div id="preview_wrap">
                    </div>
                </div>
                <div id="form_control">
                    <button id="form_submit" onclick="form_submit()">작성하기</button>
                    <div id="form_items">
                        <label for="form_file" id="form_label" class="form_item"><i class="far fa-image"></i></label>
                        <input type="file" class="hidden" id="form_file" multiple onchange="preview(event)" accept="image/*">
<!--                        <button id="form_poll" class="form_item"><i class="fas fa-poll-h"></i></button>-->
                    </div>
                </div>
            </div>

            <!--Board List-->
            <?php
            if(count($data['board_data']) != 0){
                foreach($data['board_data'] as $item){ ?>

                <div class="view_wrap" id="<?=$item->idx?>" onclick="ContentView(event)">
                    <i class="view_listBtn fas fa-sort-down" onclick="ViewListFade(<?=$item->idx?>)"></i>
                        <div id="view_list_<?=$item->idx?>" class="view_list">
                            <?php if($_SESSION['user']->userID == $item->writer){ ?>
                                <div class="view_listItem" onclick="Post_Modify(<?=$item->idx?>)">수정하기</div>
                                <div class="view_listItem" onclick="Post_Delete(<?=$item->idx?>)">삭제하기</div>
                            <?php } else { ?>
                                <div class="view_listItem">친구등록</div>
                                <div class="view_listItem">친구삭제</div>
                            <?php }?>
                        </div>
                    <div class="form_user ClickEventNone">
                        <img src="img/<?= $item->profileImage != '' ? "user_profile/".$item->profileImage : 'profile_xample_img/unknown.png'?>" alt="" class="form_userProfile ClickEventNone">
                        <span class="form_user_name ClickEventNone">
                            <?= $item->userName ?>
                        </span>
                    </div>

                    <div class="view_content ClickEventNone">
                        <?= nl2br(htmlentities(mb_substr($item->comment , 0, 150))) ?> <?= mb_strlen($item->comment) > 150 ? "..." : "" ?>
                    </div>
                    <div class="view_images ClickEventNone">
                        <?php
                        if($item->images != ""){
                            $images = explode('|' , $item->images);
                            $image_cnt = count($images)-1;
                           echo "<img src='img/board_files/$images[0]'>";
                           echo $image_cnt != 0 ? "<span id=\"view_images_cnt\">+$image_cnt</span>" : "";
                        }
                        ?>
                    </div>
                </div>

                <?php }
            } ?>
        </div>
    </div>



    <!--타임라인의 뷰징-->

    <div id="content_view">
        <div id="content_wrapper">

        </div>
    </div>


</div>



<!--팝업 창-->
<div id="message">
    <div id="message_box">
    </div>
</div>