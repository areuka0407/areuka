<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dinecto | 세상 사람들의 일기</title>
    <!--Google Font-->
    <link href="https://fonts.googleapis.com/css?family=Lato|Noto+Sans+KR" rel="stylesheet">
    <!--FontAwesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <!--JQuery-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <style>
        * {
            margin : 0;
            padding : 0;
            border : 0;
            /*font-family: 'Lato', sans-serif;*/
            font-family: 'Noto Sans KR', sans-serif;
            box-sizing: border-box;
        }

        ol, ul {
            list-style : none;
        }

        a {
            /*text-decoration : none;*/
        }

        .hidden {
            display: none;
        }

        .ClickEventNone {
            pointer-events: none;
        }
    </style>
</head>