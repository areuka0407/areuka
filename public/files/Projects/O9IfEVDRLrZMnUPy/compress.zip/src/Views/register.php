<img src="img/slide_img/background-Image3.jpg" alt="" id="backImage">
<div id="container">
    <div id="wrap">
        <div id="header">
            <div id="logo_wrap">
            <a id="logo" href="/">
            <i class="fas fa-atlas"></i>
            Dinecto
            </a>
            </div>
            <div class="step_icon">
                <svg id="1" height="50" width="30">
                    <circle id="1" class="slide_icon" cx="15" cy="25" r="5"  fill="#2892a3" style="transition : 1s; border : #707070 solid 1px"/>
                </svg>
                <svg id="2" height="50" width="30">
                    <circle id="2" class="slide_icon" cx="15" cy="25" r="5"  fill="#dadada" style="transition : 1s; border : #707070 solid 1px""/>
                </svg>
                <svg id="3" height="50" width="30">
                    <circle id="3" class="slide_icon" cx="15" cy="25" r="5"  fill="#dadada" style="transition : 1s; border : #707070 solid 1px""/>
                </svg>
            </div>
        </div>
        <form id="form_wrap" action="/register/add" method="post">
            <div class="register-form" >
                <div class="form-steps">
                <span class="step_comment">
                    <span class="badge">STEP 1</span> 로그인 정보 작성하기
                </span>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_id">아이디</label>
                        <input type="text" name="user_id" id="user_id" onchange="id_check()" maxlength="15">
                        <span id="id_comment" class="comment"></span>
                    </div>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_pass">비밀번호</label>
                        <input type="password" name="user_pass" id="user_pass" onchange="pass_check()">
                        <span id="pass_comment" class="comment"></span>
                    </div>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_repass">비밀번호 확인</label>
                        <input type="password" name="user_repass" id="user_repass" onchange="pass_check()">
                        <span id="repass_comment" class="comment"></span>
                    </div>
                </div>
                <div class="form-items">
                    <div class="item">
                        <button id="next_btn1">다음으로</button>
                    </div>
                </div>
            </div>
            <div class="register-form" style="display: none;">
                <div class="form-steps">
                <span class="step_comment">
                    <span class="badge">STEP 2</span> 회원 정보 작성하기
                </span>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_name">이름</label>
                        <input type="text" name="user_name" id="user_name" onchange="name_check(event)" maxlength="20">
                        <span id="name_comment" class="comment"></span>
                    </div>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_gender">성별</label>
                        <select name="user_gender" id="useR_gender">
                            <option value="male">남자</option>
                            <option value="female">여자</option>
                            <option value="none">비공개</option>
                        </select>
                        <span id="repass_comment" class="comment"></span>
                    </div>
                </div>
                <br>
                <div class="form-items">
                    <div class="item">
                        <label for="user_repass">생년월일</label>
                        <input type="text" name="user_bd_year" id="user_bd_year" class="user_bd" maxlength="4"  onchange="bd_check(event)">
                        <select name="user_bd_month" id="user_bd_month" class="user_bd"  onchange="bd_check(event)">
                            <option value="1">1월</option>
                            <option value="2">2월</option>
                            <option value="3">3월</option>
                            <option value="4">4월</option>
                            <option value="5">5월</option>
                            <option value="6">6월</option>
                            <option value="7">7월</option>
                            <option value="8">8월</option>
                            <option value="9">9월</option>
                            <option value="10">10월</option>
                            <option value="11">11월</option>
                            <option value="12">12월</option>
                        </select>
                        <input type="text" name="user_bd_day" id="user_bd_day" class="user_bd" maxlength="2" onchange="bd_check(event)">
                        <span id="bd_comment" class="comment"></span>
                    </div>
                </div>
                <div class="form-items">
                    <div class="form-items">
                        <div class="item">
                            <button id="next_btn2">다음으로</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="register-form" style="display: none;">
                <input type="hidden" id="category_count" name="category_count">
                <div class="form-steps">
                <span class="step_comment">
                    <span class="badge">STEP 3</span> 카테고리 선택하기
                </span>
                </div>
                <div class="form-items">
                    <span id="category_comment">
                            카테고리는 당신과 다른이를 이어주는 연결고리가 됩니다. <br>당신이 좋아하는 분야를 선택해 주세요.
                    </span>
                    <span id="category_alert"></span>
                    <div id="category-wrap">
                        <?php foreach($data['cat_list'] as $cat){ ?>
                            <div class="category_item">
                                <span class="categories" onclick="category_select(event)" style="background-color : <?=$cat->cat_bgc?> ; color : <?=$cat->cat_color?>"><?=$cat->cat_name?><input type="checkbox" class="displayNone" value="<?=$cat->cat_name?>"  name="categories[]"></span>
                                <span class="category_checked" onclick="category_unselect(event)"><i class="fas fa-check-circle" onclick="category_unselect(event)"></i></span>
                            </div>
                        <?php }?>
                    </div>
                    <span id="category_comment">
                            카테고리는 1인당 최대 5개까지 선택 가능합니다.<br>마음에 드시는 카테고리가 없다면 추가할 수 있습니다.
                    </span>
                    <div id="category_form">
                        <span id="sample_category"></span><br>
                        <div id="category_item">
                            <input type="text" id="category_name" name="category_name" class="category_input" maxlength="15" placeholder="카테고리 입력" onchange="category_name_preview()">
                            <label for="category_bg_color" class="category_colors">배경색 : <input type="color" id="category_bg_color" name="category_bg_color" class="category_input" value="#ffffff" onchange="category_color_preview()"></label>
                            <label for="category_font_color" class="category_colors">글자색 : <input type="color" id="category_font_color" name="category_font_color" class="category_input" onchange="category_color_preview()"></label>
                            <button id="add_category_btn" onclick="add_category()">카테고리 추가</button>
                        </div>
                        <span id="preview_comment" class="comment"></span>
                    </div>
                    <div class="form-items">
                        <div class="item">
                            <button id="next_btn3" >가입하기</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
