<div id="wrap">
    <header><i class="fas fa-atlas"></i>Dinecto</header>
    <span id="error_text">
        <h1>ERROR!</h1>
        요청한 페이지를 찾을 수 없습니다. 요청하신 페이지의 주소가 잘못 되었거나,
        페이지의 주소가 변경 혹은 삭제되어 요청하신 페이지를 찾을 수 없습니다.<br><br>
        입력하신 주소가 정확한지 다시 한번 확인해 주시기 바랍니다.<br><br>
    </span>
    <a href="/" id="home_btn">홈페이지 바로가기</a>
</div>