<div id="header">
    <span id="logo">
        Dinecto
    </span>
</div>
<div id="slide_wrap">
    <div id="slide">
        <img class="back_image" src="/img/slide_img/background-image1.jpg" alt="BackGround-Image">
        <img class="back_image" src="/img/slide_img/background-image2.jpg" alt="BackGround-Image">
        <img class="back_image" src="/img/slide_img/background-image3.jpg" alt="BackGround-Image">
    </div>
</div>
<div id="wrap">
    <div id="main_content">
        <div id="site_info">
            <div id="comment_wrap">
                <span class="back_comment">
                    <h1>함께 하세요!</h1>
                    Dinecto는 유저들에게 자신과 비슷한 타입의 취미나 성향을 가지고 있는 사람과 그룹을 맺게 해줍니다! 자신에 맞는 그룹을 찾아 가입하고, 그룹원들과 함께 소식을<br> 주고 받거나 정보를 공유 해 보세요!
                </span>
                <span class="back_comment">
                    <h1>소통 하세요!</h1>
                    Dinecto는 자신이 속해 있는 그룹 외에도 다른 여러 그룹이 존재합니다! 관심 있는 분야의 그룹의 최신 소식에 책갈피를 꽂거나 최근에 인기 있는 포스트에 댓글을<br> 남겨 보세요!
                </span>
                <span class="back_comment">
                    <h1>언제나 즐기세요!</h1>
                    Dinecto는 타임라인(Time Line) 식의 커뮤니티로써, 현재 업로드된 포스트들을 한눈에 보여줍니다! 스크롤을 내리며, 간편하게 관심 분야에 대한 소식을 받아 읽거나 글을 직접 작성해 보세요!
                </span>
            </div>
        </div>
        <div id="login_info">
            <form action="/login" method="post">
                <span id="form_title">Sign In</span>
                <div id="form_wrap">
                    <input type="text" name="user_id" id="user_id" placeholder="아이디">
                    <input type="password" name="user_pass" id="user_pass" placeholder="비밀번호">
                    <button type="submit" class="form-btn">로그인</button>
                </div>
                <div id="form_items">
                    <div id="form-register">
                        <span>아직 가입을 하지 않으셨다면?</span>
                        <a href="/register">회원가입</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div id="item_content">
        <div id="slide_items">
            <svg id="0" height="50" width="50">
                <circle id="0" class="slide_icon" cx="25" cy="25" r="10"  fill="#2da7af" style="transition : 2s"/>
            </svg>
            <svg id="1" height="50" width="50">
                <circle id="1" class="slide_icon" cx="25" cy="25" r="10"  fill="#ffffff" style="transition : 2s"/>
            </svg>
            <svg id="2" height="50" width="50">
                <circle id="2" class="slide_icon" cx="25" cy="25" r="10"  fill="#ffffff" style="transition : 2s"/>
            </svg>
        </div>
    </div>
</div>